{% macro overwrite_consolidation(source_schema, source_table, target_schema, source_system) %}

{{ config(
    materialized = 'table',
    target_database = 'aw_dev',
    schema = target_schema,
) }}

WITH MAX_TIMESTAMP_CTE AS (
    -- Find the highest timestamp and corresponding landing path
    SELECT
        _audit_landing_file_path AS max_landing_path
    FROM {{ source(source_schema, source_table) }}
    WHERE _audit_system_timestamp = (
        SELECT MAX(_audit_system_timestamp)
        FROM {{ source(source_schema, source_table) }}
    )
    LIMIT 1
),

FILTERED_ROWS AS (
    -- Filter rows based on the landing path from the highest timestamp
    SELECT *
    FROM {{ source(source_schema, source_table) }}
    WHERE _audit_landing_file_path = (SELECT max_landing_path FROM MAX_TIMESTAMP_CTE)
)

SELECT
    *,
    CURRENT_TIMESTAMP() AS _audit_ingest_timestamp,
    HASH(_audit_unique_record_hash, _audit_system_timestamp) AS _audit_unique_record_with_ingest_hash
FROM FILTERED_ROWS
ORDER BY _audit_system_timestamp DESC;
{% endmacro %}
