{% macro merge_w_history_consolidation(source_schema, source_table, target_schema) %}

{{ config(
    materialized = 'incremental',
    target_database = 'aw_dev',
    schema = target_schema,
) }}

WITH SOURCE_CTE AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY _audit_tracked_changes_hash ORDER BY _audit_system_timestamp ASC) as row_num
    FROM {{ source(source_schema, source_table) }}
)

, DATA_TO_PROCESS AS (
    SELECT *
    FROM SOURCE_CTE
    WHERE row_num = 1
)

, CREATE_VALID_FROM_AND_TO AS (
select *
        , _audit_system_timestamp as DBT_Valid_from
        , LAG(_audit_system_timestamp) OVER (
        PARTITION BY _audit_unique_record_hash
        ORDER BY _audit_system_timestamp DESC
        ) AS DBT_Valid_to
from DATA_TO_PROCESS
order by _audit_system_timestamp DESC
)

SELECT
*,
CASE
    WHEN DBT_Valid_to IS NULL THEN 'Y'
    ELSE 'N'
END AS DBT_Active_flag
, CURRENT_TIMESTAMP() AS _audit_ingest_timestamp
, HASH(_audit_unique_record_hash, DBT_Valid_from) AS _audit_unique_record_with_valid_from_hash
FROM CREATE_VALID_FROM_AND_TO d
WHERE COALESCE(DBT_Valid_to, '1900-01-01') <> DBT_Valid_from
ORDER BY _audit_system_timestamp DESC;
{% endmacro %}