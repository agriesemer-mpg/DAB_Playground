{% macro merge_wo_history_consolidation(source_schema, source_table, target_schema) %}

{{ config(
    materialized = 'incremental',
    target_database = 'aw_dev',
    schema = target_schema,
) }}

WITH SOURCE_CTE AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY _audit_tracked_changes_hash ORDER BY _audit_system_timestamp ASC) AS track_row_num
    FROM {{ source(source_schema, source_table) }}
)

, ID_FILTER AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY _audit_unique_record_hash ORDER BY _audit_system_timestamp DESC) AS id_row_num
    FROM SOURCE_CTE
    WHERE track_row_num = 1
)

, DATA_TO_PROCESS AS (
    SELECT *
    FROM ID_FILTER
    WHERE id_row_num = 1
)

SELECT
    *,
    CURRENT_TIMESTAMP() AS _audit_ingest_timestamp
FROM DATA_TO_PROCESS;
{% endmacro %}