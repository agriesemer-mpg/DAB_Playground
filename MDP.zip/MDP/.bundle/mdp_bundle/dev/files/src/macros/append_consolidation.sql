{% macro append_consolidation(source_schema, source_table, target_schema) %}

{{ config(
    materialized = 'incremental',
    target_database = 'aw_dev',
    schema = target_schema,
) }}

WITH SOURCE_CTE AS (
    SELECT *
    from {{ source(source_schema, source_table)
 }}
    {% if is_incremental() %}
        -- Only process records that are new or updated since the last run
        WHERE _audit_system_timestamp > (
            SELECT MAX(_audit_system_timestamp)
            FROM {{ this }}
        )
    {% endif %}
)

SELECT
    *,
    CURRENT_TIMESTAMP() AS _audit_ingest_timestamp,
    HASH(_audit_unique_record_hash, _audit_system_timestamp) AS _audit_unique_record_with_ingest_hash
FROM SOURCE_CTE
ORDER BY _audit_system_timestamp DESC;
{% endmacro %}