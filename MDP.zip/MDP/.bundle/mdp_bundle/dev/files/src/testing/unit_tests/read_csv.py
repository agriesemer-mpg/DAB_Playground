# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestReadCSV(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher = patch('_globals.Globals.spark', create=True)  # Patch the class attribute
        self.addCleanup(patcher.stop)
        self.mock_spark = patcher.start()

        # Reset the mock before each test
        self.mock_spark.reset_mock()
        self.mock_spark.read.csv.side_effect = None

    def test_read_csv_success(self):
        """
        Test for successful CSV read operation.
        """
        # Mock spark.read.csv to return a mocked DataFrame
        mock_df = MagicMock()
        self.mock_spark.read.csv.return_value = mock_df

        # Define test parameters
        str_file_path = "path/to/csv_file.csv"
        dict_ingest_parameters = {"header": True, "inferSchema": True}

        # Call the function
        result_df = read_csv(str_file_path, dict_ingest_parameters)

        # Assert that spark.read.csv was called with the correct arguments
        self.mock_spark.read.csv.assert_called_once_with(
            str_file_path, 
            header=True, 
            inferSchema=True, 
            sep='|', 
            quote='"', 
            escape='"', 
            multiLine=True
        )

        # Assert that the function returned the mocked DataFrame
        self.assertEqual(result_df, mock_df)

    @patch("builtins.print")  # Mock the print function
    def test_read_csv_failure(self, mock_print):
        """
        Test for failure during CSV read operation.
        """
        # Simulate an exception during spark.read.csv
        self.mock_spark.read.csv.side_effect = Exception("Read operation failed")

        # Define test parameters
        str_file_path = "path/to/csv_file.csv"
        dict_ingest_parameters = {"header": True, "inferSchema": True}

        # Call the function
        result = read_csv(str_file_path, dict_ingest_parameters)

        # Assert that the function returned None
        self.assertEqual(result, None)

        # Assert that the correct error message was printed
        mock_print.assert_called_once_with(
            "An error occurred while reading the CSV file: Read operation failed"
        )

suite = unittest.TestLoader().loadTestsFromTestCase(TestReadCSV)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
