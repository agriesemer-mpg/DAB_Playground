# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestGetAuditRowByBatchId(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher_spark = patch('_globals.Globals.spark', create=True)  # Patch the Spark class attribute
        patcher_col = patch('pyspark.sql.functions.col', create=True)  # Patch the col function
        self.addCleanup(patcher_spark.stop)
        self.addCleanup(patcher_col.stop)
        self.mock_spark = patcher_spark.start()
        self.mock_col = patcher_col.start()

        # Mock the DataFrame returned by `spark.table`
        self.mock_df_audit_table = MagicMock()

        # Mock the `filter` method to return the same mocked DataFrame
        self.mock_df_audit_table.filter.return_value = self.mock_df_audit_table

        # Mock the `first` method to return a mocked row
        self.mock_row = {"batch_id": 12345, "job_status": "Complete", "modified_timestamp": "2023-05-10 12:34:56"}
        self.mock_df_audit_table.first.return_value = self.mock_row

        # Mock `spark.table` to return the mocked DataFrame
        self.mock_spark.table.return_value = self.mock_df_audit_table

        # Mock the behavior of `col` to return a mock that supports `==`
        self.mock_col_instance = MagicMock()
        self.mock_col.return_value = self.mock_col_instance

        # Mock the behavior of `==` on the `col` mock
        self.mock_col_instance.__eq__.return_value = "mocked_filter_expression"

    def test_get_audit_row_by_batch_id_default_path(self):
        """
        Test for retrieving a row by batch_id with the default path.
        """
        # Define test parameters
        batch_id = 12345
        str_path = ""

        # Call the function
        row = get_audit_row_by_batch_id(batch_id, str_path)

        # Assert the result
        self.assertEqual(row, self.mock_row)

        # Assert that `spark.table` was called with the default path
        self.mock_spark.table.assert_called_once()

        # Assert that `filter` was called with the correct condition
        self.mock_df_audit_table.filter.assert_called_once()

    @patch("builtins.print")  # Capture print statements
    def test_get_audit_row_by_batch_id_exception(self, mock_print):
        """
        Test for handling exceptions while retrieving a row by batch_id.
        """
        # Mock `spark.table` to raise an exception
        self.mock_spark.table.side_effect = Exception("Test exception")

        # Define test parameters
        batch_id = 12345
        str_path = "audit_table_path"

        # Call the function
        row = get_audit_row_by_batch_id(batch_id, str_path)

        # Assert the result is None
        self.assertIsNone(row)

        # Assert that the exception message was printed
        mock_print.assert_called_once_with("An error occurred while retrieving the row by batch_id: Test exception")


# Run the test suite
suite = unittest.TestLoader().loadTestsFromTestCase(TestGetAuditRowByBatchId)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
