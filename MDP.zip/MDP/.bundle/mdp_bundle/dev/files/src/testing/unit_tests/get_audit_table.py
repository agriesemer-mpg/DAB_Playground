# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------


# Test class
class TestGetAuditTable(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher_spark = patch('_globals.Globals.spark', create=True)  # Patch the Spark class attribute
        self.addCleanup(patcher_spark.stop)
        self.mock_spark = patcher_spark.start()

        # Mock the DataFrame returned by `spark.table`
        self.mock_df_audit_table = MagicMock()

        # Mock `spark.table` to return the mocked DataFrame
        self.mock_spark.table.return_value = self.mock_df_audit_table

    def test_get_audit_table_success(self):
        """
        Test for successfully retrieving the audit table with a specified path.
        """
        # Define test parameters
        str_path = "audit_table_path"

        # Call the function
        result = get_audit_table(str_path)

        # Assert the result
        self.assertEqual(result, self.mock_df_audit_table)

        # Assert that `spark.table` was called with the correct path
        self.mock_spark.table.assert_called_once_with(str_path)

    def test_get_audit_table_default_path(self):
        """
        Test for successfully retrieving the audit table with the default path.
        """
        # Define test parameters
        str_path = ""
        
        result = get_audit_table(str_path)

        # Assert the result
        self.assertEqual(result, self.mock_df_audit_table)

        # Assert that `spark.table` was called with the default path
        self.mock_spark.table.assert_called_once_with(C.PATH_TO_AUDIT_TABLE)

    def test_get_audit_table_failure(self):
        """
        Test for handling errors when retrieving the audit table.
        """
        # Mock `spark.table` to raise an exception for the failure scenario
        self.mock_spark.table.side_effect = Exception("Table not found")

        # Define test parameters
        str_path = "invalid_audit_table_path"

        # Call the function and assert that it raises a ValueError
        with self.assertRaises(ValueError) as cm:
            get_audit_table(str_path)

        # Assert the exception message
        self.assertEqual(
            str(cm.exception),
            f"Failed to retrieve the audit table from path '{str_path}': Table not found"
        )

        # Assert that `spark.table` was called with the correct path
        self.mock_spark.table.assert_called_once_with(str_path)


# Run the test suite
suite = unittest.TestLoader().loadTestsFromTestCase(TestGetAuditTable)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
