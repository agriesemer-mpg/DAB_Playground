# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

#custom import
import pytz

# COMMAND ----------

# Test class
class TestInsertAuditEntry(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher = patch('_globals.Globals.spark', create=True)  # Patch the class attribute
        self.addCleanup(patcher.stop)
        self.mock_spark = patcher.start()

        # Reset the mock before each test
        self.mock_spark.reset_mock()

    @patch("builtins.print")  # Mock the print function
    @patch("datetime.datetime")  # Mock datetime for timezone-related logic
    def test_insert_audit_entry_success(self, mock_datetime, mock_print):
        """
        Test for successful audit entry insertion.
        """
        # Mock current datetime
        tz_timezone = pytz.timezone("UTC")
        mock_datetime.now.return_value = tz_timezone.localize(datetime(2023, 10, 1, 12, 0, 0))

        # Simulate successful write operation
        self.mock_spark.createDataFrame.return_value.write.format.return_value.mode.return_value.save.return_value = None

        # Define test parameters
        dict_batch_parameters = {"batch_id": "12345", "source_system_name": "salesforce", "target_table_name": "testTable"}
        str_acquisition_ready_datetime = "2023-10-01 11:00:00"

        # Call the function
        insert_audit_entry(dict_batch_parameters, str_acquisition_ready_datetime)

        # Assert that createDataFrame was called with the correct data and schema
        expected_data = [{
            "batch_id": "12345",
            "batch_status": "SUCCESS",
            "job_status": "Ready",
            "acquisition_ready_datetime": tz_timezone.localize(datetime(2023, 10, 1, 11, 0, 0))
        }]
        self.mock_spark.createDataFrame.assert_called()

        # Assert that the correct success message was printed
        mock_print.assert_called_once_with(
            "Successfully added audit entry for table testTable."
        )

suite = unittest.TestLoader().loadTestsFromTestCase(TestInsertAuditEntry)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
