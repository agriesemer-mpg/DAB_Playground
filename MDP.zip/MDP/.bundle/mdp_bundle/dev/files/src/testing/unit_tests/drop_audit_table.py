# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestDropAuditTable(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher = patch('_globals.Globals.spark', create=True)
        self.addCleanup(patcher.stop)
        self.mock_spark = patcher.start()

        # Reset the mock before each test
        self.mock_spark.reset_mock()
        self.mock_spark.sql.side_effect = None

    def test_drop_audit_table_success(self):
        # Simulate successful SQL execution
        self.mock_spark.sql.return_value = None

        # Call the function
        drop_audit_table("audit_table_test")

        # Assert that spark.sql was called once with the correct query
        self.mock_spark.sql.assert_called_once_with("DROP TABLE IF EXISTS audit_table_test")

    @patch("builtins.print")  # Mock the print function
    def test_drop_audit_table_sql_failure(self, mock_print):
        # Simulate SQL execution failure with a specific message
        self.mock_spark.sql.side_effect = Exception("SQL execution error while dropping the table")

        # Call the function
        drop_audit_table("audit_table_test")
        
        mock_print.assert_called_once_with("An error occurred while dropping the table 'audit_table_test': SQL execution error while dropping the table")


suite = unittest.TestLoader().loadTestsFromTestCase(TestDropAuditTable)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))