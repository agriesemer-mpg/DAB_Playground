# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestGetSourceTablesListFromConfig(unittest.TestCase):

    @patch("builtins.open", new_callable=mock_open, read_data="""
        - source_table: "table1"
          source_system: "system1"
        - source_table: "table2"
          source_system: "system2"
    """)
    def test_valid_file_path(self, mock_file):
        """
        Test for valid file path scenario.
        """
        result = get_source_tables_list_from_config("/mock/path/")
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['source_table'], "table1")
        self.assertEqual(result[1]['source_table'], "table2")

        # Assert that `open` was called with the correct file path
        mock_file.assert_called_once_with("/mock/path/source_tables.yml", 'r')

    @patch("builtins.open", new_callable=mock_open, read_data="""
        - source_table: "table1"
          source_system: "system1"
        - source_table: "table2"
          source_system: "system2"
    """)
    def test_empty_path(self, mock_file):
        """
        Test for empty path scenario.
        """
        result = get_source_tables_list_from_config()
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['source_table'], "table1")
        self.assertEqual(result[1]['source_table'], "table2")

        # Assert that `open` was called with the default path
        mock_file.assert_called_once_with(C.PATH_TO_CONFIGS + 'source_tables.yml', 'r')

    @patch("builtins.open", side_effect=FileNotFoundError)
    def test_invalid_file_path(self, mock_file):
        """
        Test for invalid file path scenario.
        """
        result = get_source_tables_list_from_config('/invalid/path/')
        self.assertEqual(result, [])

        # Assert that `open` was called with the invalid file path
        mock_file.assert_called_once_with('/invalid/path/source_tables.yml', 'r')

    @patch("builtins.open", new_callable=mock_open, read_data="""
        - source_table: "table1"
          source_system
    """)
    def test_corrupted_yaml_file(self, mock_file):
        """
        Test for corrupted YAML file scenario.
        """
        result = get_source_tables_list_from_config("/mock/path/")
        self.assertEqual(result, [])

        # Assert that `open` was called with the correct file path
        mock_file.assert_called_once_with("/mock/path/source_tables.yml", 'r')

    @patch("builtins.open", new_callable=mock_open, read_data="""
        - source_system: "system1"
    """)
    def test_missing_key_in_yaml(self, mock_file):
        """
        Test for missing keys in YAML file.
        """
        result = get_source_tables_list_from_config("/mock/path/")
        self.assertEqual(len(result), 1)
        self.assertIn("source_system", result[0])
        self.assertNotIn("source_table", result[0])

        # Assert that `open` was called with the correct file path
        mock_file.assert_called_once_with("/mock/path/source_tables.yml", 'r')

    @patch("builtins.open", side_effect=FileNotFoundError)
    def test_file_not_found(self, mock_file):
        """
        Test for file not found scenario.
        """
        result = get_source_tables_list_from_config("/mock/path/")
        self.assertEqual(result, [])

        # Assert that `open` was called with the correct file path
        mock_file.assert_called_once_with("/mock/path/source_tables.yml", 'r')


# Run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestGetSourceTablesListFromConfig)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
