# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestGetTablesInValidatedSchemas(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher = patch('_globals.Globals.spark', create=True)  # Patch the class attribute
        self.addCleanup(patcher.stop)
        self.mock_spark = patcher.start()

        # Mock the spark methods
        self.mock_spark.sql = MagicMock()
        self.mock_spark.catalog.listDatabases = MagicMock()
        self.mock_spark.catalog.listTables = MagicMock()

    def test_get_tables_in_validated_schemas_success(self):
        # Mock the return values for listDatabases
        schema1 = MagicMock()
        schema1.name = f'{C.SCHEMA_USERNAME_PREFIX}validated_schema1'
        schema2 = MagicMock()
        schema2.name = f'{C.SCHEMA_USERNAME_PREFIX}validated_schema2'
        schema3 = MagicMock()
        schema3.name = f'{C.SCHEMA_USERNAME_PREFIX}validated_schema3'

        # Return mocked schemas when listDatabases is called
        self.mock_spark.catalog.listDatabases.return_value = [schema1, schema2, schema3]

        # Mock the return values for listTables
        table1 = MagicMock()
        table1.name = 'table1'
        table2 = MagicMock()
        table2.name = 'table2'
        table3 = MagicMock()
        table3.name = 'table3'
        table4 = MagicMock()
        table4.name = 'table4'
        table5 = MagicMock()
        table5.name = 'table5'

        def list_tables_side_effect(schema):
            if schema == f'{C.SCHEMA_USERNAME_PREFIX}validated_schema1':
                return [table1, table2]
            elif schema == f'{C.SCHEMA_USERNAME_PREFIX}validated_schema2':
                return [table3]
            elif schema == f'{C.SCHEMA_USERNAME_PREFIX}validated_schema3':
                return [table4, table5]
            else:
                return []

        self.mock_spark.catalog.listTables.side_effect = list_tables_side_effect

        result = get_tables_in_validated_schemas()

        # Assertions
        self.mock_spark.sql.assert_called_with(f'USE CATALOG {C.CATALOG}')
        self.mock_spark.catalog.listDatabases.assert_called()
        self.assertEqual(self.mock_spark.catalog.listTables.call_count, 3)
        self.assertListEqual(result, ['table1', 'table2', 'table3', 'table4', 'table5'])

    def test_get_tables_in_validated_schemas_no_matching_schemas(self):
        # Mock the return values for listDatabases
        schema1 = MagicMock()
        schema1.name = 'other_schema1'
        schema2 = MagicMock()
        schema2.name = 'other_schema2'
        schema3 = MagicMock()
        schema3.name = 'other_schema3'

        # Return mocked schemas when listDatabases is called
        self.mock_spark.catalog.listDatabases.return_value = [schema1, schema2, schema3]

        result = get_tables_in_validated_schemas()

        # Assertions
        self.mock_spark.sql.assert_called_with(f'USE CATALOG {C.CATALOG}')
        self.mock_spark.catalog.listDatabases.assert_called()
        self.assertListEqual(result, [])  # Result should be an empty list

    def test_get_tables_in_validated_schemas_with_custom_prefix_and_catalog(self):
        # Mock the return values for listDatabases
        self.mock_spark.catalog.listDatabases.return_value = [
            MagicMock(name='custom_validated_schema1'),
            MagicMock(name='custom_validated_schema2'),
            MagicMock(name='other_schema'),
        ]

        # Mock the return values for listDatabases
        schema1 = MagicMock()
        schema1.name = f'custom_validated_schema1'
        schema2 = MagicMock()
        schema2.name = f'custom_validated_schema2'
        schema3 = MagicMock()
        schema3.name = f'other_schema'

        # Return mocked schemas when listDatabases is called
        self.mock_spark.catalog.listDatabases.return_value = [schema1, schema2, schema3]

        # Mock the return values for listTables
        table1 = MagicMock()
        table1.name = 'table1'
        table2 = MagicMock()
        table2.name = 'table2'

        def list_tables_side_effect(schema):
            if schema == "custom_validated_schema1":
                return [table1]
            elif schema == "custom_validated_schema2":
                return [table2]
            else:
                return []

        self.mock_spark.catalog.listTables.side_effect = list_tables_side_effect

        result = get_tables_in_validated_schemas(validated_schema_prefix='custom_', catalog_name='custom_catalog')

        # Assertions
        self.mock_spark.sql.assert_called_with('USE CATALOG custom_catalog')
        self.mock_spark.catalog.listDatabases.assert_called()
        self.assertEqual(self.mock_spark.catalog.listTables.call_count, 2)  # Only two schemas match the prefix
        self.assertListEqual(result, ['table1', 'table2'])

    def test_get_tables_in_validated_schemas_no_tables_in_schemas(self):
        # Mock the return values for listDatabases
        schema1 = MagicMock()
        schema1.name = f'{C.SCHEMA_USERNAME_PREFIX}validated_schema1'
        schema2 = MagicMock()
        schema2.name = f'{C.SCHEMA_USERNAME_PREFIX}validated_schema2'

        # Return mocked schemas when listDatabases is called
        self.mock_spark.catalog.listDatabases.return_value = [schema1, schema2]

        def list_tables_side_effect(schema):
            if schema == f'{C.SCHEMA_USERNAME_PREFIX}validated_schema1':
                return []
            elif schema == f'{C.SCHEMA_USERNAME_PREFIX}validated_schema2':
                return []
            else:
                return []

        self.mock_spark.catalog.listTables.side_effect = list_tables_side_effect

        # Call the function
        result = get_tables_in_validated_schemas()

        # Assertions
        self.mock_spark.sql.assert_called_with(f'USE CATALOG {C.CATALOG}')
        self.mock_spark.catalog.listDatabases.assert_called()
        self.assertEqual(self.mock_spark.catalog.listTables.call_count, 2)  # Two schemas processed
        self.assertListEqual(result, [])  # Result should be an empty list

    def test_get_tables_in_validated_schemas_single_matching_schema(self):
        # Mock the return values for listDatabases
        schema1 = MagicMock()
        schema1.name = f'{C.SCHEMA_USERNAME_PREFIX}validated_schema1'
        schema2 = MagicMock()
        schema2.name = 'other_schema'

        # Return mocked schemas when listDatabases is called
        self.mock_spark.catalog.listDatabases.return_value = [schema1, schema2]

        # Mock the return values for listTables
        table1 = MagicMock()
        table1.name = 'table1'
        table2 = MagicMock()
        table2.name = 'table2'

        def list_tables_side_effect(schema):
            if schema == f'{C.SCHEMA_USERNAME_PREFIX}validated_schema1':
                return [table1, table2]
            else:
                return []

        self.mock_spark.catalog.listTables.side_effect = list_tables_side_effect

        # Call the function
        result = get_tables_in_validated_schemas()

        # Assertions
        self.mock_spark.sql.assert_called_with(f'USE CATALOG {C.CATALOG}')
        self.mock_spark.catalog.listDatabases.assert_called()
        self.assertEqual(self.mock_spark.catalog.listTables.call_count, 1)  # Only one schema processed
        self.assertListEqual(result, ['table1', 'table2'])


# Run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestGetTablesInValidatedSchemas)
unittest.TextTestRunner().run(suite)
