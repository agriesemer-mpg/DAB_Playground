# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

import unittest

class TestNormalizeVolumePath(unittest.TestCase):
    def test_forward_slash_and_capitalization(self):
        self.assertEqual(normalize_volume_path(r"\Volumes\cat\sch\vol"), "/Volumes/cat/sch/vol")
        self.assertEqual(normalize_volume_path("/volumes/cat/sch/vol"), "/Volumes/cat/sch/vol")
        self.assertEqual(normalize_volume_path("/Volumes/cat/sch/vol"), "/Volumes/cat/sch/vol")
        self.assertEqual(normalize_volume_path(r"/Volumes\cat\sch\vol"), "/Volumes/cat/sch/vol")

    def test_non_volume_path(self):
        self.assertEqual(normalize_volume_path(r"/foo/bar"), "/foo/bar")

    def test_empty_path(self):
        with self.assertRaises(ValueError):
            normalize_volume_path("")

    def test_non_string(self):
        with self.assertRaises(ValueError):
            normalize_volume_path(None)

# To run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestNormalizeVolumePath)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
