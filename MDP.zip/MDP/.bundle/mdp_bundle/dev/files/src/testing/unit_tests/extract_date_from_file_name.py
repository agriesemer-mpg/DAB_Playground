# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

class TestExtractDateFromFileName(unittest.TestCase):
    @patch("os.path.splitext")  # Mock `os.path.splitext`
    @patch("re.match")  # Mock `re.match`
    def test_extract_date_success(self, mock_re_match, mock_os_splitext):
        # Mock `os.path.splitext` to simulate file mask manipulation
        mock_os_splitext.side_effect = lambda path: (path.split('.')[0], path.split('.')[1])

        # Simulate a successful match
        mock_match = MagicMock()
        mock_match.group.return_value = "20230510"
        mock_re_match.return_value = mock_match

        # Define test parameters
        landing_file_path = "/path/to/file_batch_20230510.txt"
        acquisition_file_mask = "*.txt"

        # Call the function
        result = extract_date_from_file_name(landing_file_path, acquisition_file_mask)

        # Assert the result
        self.assertEqual(result, "20230510")

        # Assert that `os.path.splitext` was called correctly
        mock_os_splitext.assert_called()

        # Assert that `re.match` was called with the correct pattern
        expected_pattern = r"(.*?)_batch_(.*?)txt"
        mock_re_match.assert_called_once_with(expected_pattern, "file_batch_20230510.txt")

    @patch("os.path.splitext")  # Mock `os.path.splitext`
    @patch("re.match")  # Mock `re.match`
    def test_extract_date_no_match(self, mock_re_match, mock_os_splitext):
        # Mock `os.path.splitext` to simulate file mask manipulation
        mock_os_splitext.side_effect = lambda path: (path.split('.')[0], path.split('.')[1])

        # Simulate a successful match
        mock_match = MagicMock()
        mock_match.group.return_value = None
        mock_re_match.return_value = mock_match

        # Define test parameters
        landing_file_path = "/path/to/file_batch_12.txt"
        acquisition_file_mask = "*.txt"

        # Call the function
        result = extract_date_from_file_name(landing_file_path, acquisition_file_mask)

        # Assert the result
        self.assertIsNone(result)

        # Assert that `os.path.splitext` was called correctly
        mock_os_splitext.assert_called()

suite = unittest.TestLoader().loadTestsFromTestCase(TestExtractDateFromFileName)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))