# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

class TestEnsureVolumeAndDirectory(unittest.TestCase):

    def setUp(self):
        # Patch the external dependencies directly
        patcher_normalize = patch('_functions.normalize_volume_path', create=True)
        patcher_parse = patch('_functions.parse_volume_path', create=True)
        patcher_exists = patch('_functions.volume_exists', create=True)
        patcher_create = patch('_functions.create_volume', create=True)
        patcher_makedirs = patch('os.makedirs', create=True)

        self.addCleanup(patcher_normalize.stop)
        self.addCleanup(patcher_parse.stop)
        self.addCleanup(patcher_exists.stop)
        self.addCleanup(patcher_create.stop)
        self.addCleanup(patcher_makedirs.stop)

        self.mock_normalize_volume_path = patcher_normalize.start()
        self.mock_parse_volume_path = patcher_parse.start()
        self.mock_volume_exists = patcher_exists.start()
        self.mock_create_volume = patcher_create.start()
        self.mock_makedirs = patcher_makedirs.start()

    def test_ensure_volume_and_directory_success(self):
        """
        Test for successful volume and directory creation when the volume already exists.
        """
        # Mock behavior
        self.mock_normalize_volume_path.return_value = "/Volumes/catalog.schema.volume/path/to/directory"
        self.mock_parse_volume_path.return_value = ("catalog", "schema", "volume")
        self.mock_volume_exists.return_value = True

        # Call the function
        ensure_volume_and_directory("/Volumes/catalog.schema.volume/path/to/directory")

        # Assertions
        self.mock_normalize_volume_path.assert_called_once_with("/Volumes/catalog.schema.volume/path/to/directory")
        self.mock_parse_volume_path.assert_called_once_with("/Volumes/catalog.schema.volume/path/to/directory")
        self.mock_volume_exists.assert_called_once_with("catalog", "schema", "volume")
        self.mock_makedirs.assert_called_once_with("/Volumes/catalog.schema.volume/path/to", exist_ok=True)

    def test_invalid_path(self):
        """
        Test for invalid destination paths.
        """
        # Test empty path
        with self.assertRaises(ValueError) as context:
            ensure_volume_and_directory("")
        self.assertEqual(str(context.exception), "Destination path must be a non-empty string.")

        # Test non-string path
        with self.assertRaises(ValueError) as context:
            ensure_volume_and_directory(None)
        self.assertEqual(str(context.exception), "Destination path must be a non-empty string.")

    def test_volume_creation(self):
        """
        Test for volume creation when the volume does not exist.
        """
        # Mock behavior
        self.mock_normalize_volume_path.return_value = "/Volumes/catalog.schema.volume/path/to/directory"
        self.mock_parse_volume_path.return_value = ("catalog", "schema", "volume")
        self.mock_volume_exists.return_value = False

        # Call the function
        ensure_volume_and_directory("/Volumes/catalog.schema.volume/path/to/directory")

        # Assertions
        self.mock_normalize_volume_path.assert_called_once_with("/Volumes/catalog.schema.volume/path/to/directory")
        self.mock_parse_volume_path.assert_called_once_with("/Volumes/catalog.schema.volume/path/to/directory")
        self.mock_volume_exists.assert_called_once_with("catalog", "schema", "volume")
        self.mock_create_volume.assert_called_once_with("catalog", "schema", "volume")
        self.mock_makedirs.assert_called_once_with("/Volumes/catalog.schema.volume/path/to", exist_ok=True)

    def test_directory_creation_failure(self):
        """
        Test for failure during directory creation.
        """
        # Mock behavior
        self.mock_normalize_volume_path.return_value = "/Volumes/catalog.schema.volume/path/to/directory"
        self.mock_parse_volume_path.return_value = ("catalog", "schema", "volume")
        self.mock_volume_exists.return_value = True
        self.mock_makedirs.side_effect = Exception("Permission denied")

        # Call the function and expect a RuntimeError
        with self.assertRaises(RuntimeError) as context:
            ensure_volume_and_directory("/Volumes/catalog.schema.volume/path/to/directory")

        # Assertions
        self.assertIn("Failed to create directory '/Volumes/catalog.schema.volume/path/to'", str(context.exception))
        self.assertIn("Permission denied", str(context.exception))

    def test_volume_creation_failure(self):
        """
        Test for failure during volume creation.
        """
        # Mock behavior
        self.mock_normalize_volume_path.return_value = "/Volumes/catalog.schema.volume/path/to/directory"
        self.mock_parse_volume_path.return_value = ("catalog", "schema", "volume")
        self.mock_volume_exists.return_value = False
        self.mock_create_volume.side_effect = Exception("Volume creation failed")

        # Call the function and expect a RuntimeError
        with self.assertRaises(RuntimeError) as context:
            ensure_volume_and_directory("/Volumes/catalog.schema.volume/path/to/directory")

        # Assertions
        self.assertIn("Error ensuring volume existence.", str(context.exception))


# Run the test suite
suite = unittest.TestLoader().loadTestsFromTestCase(TestEnsureVolumeAndDirectory)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))