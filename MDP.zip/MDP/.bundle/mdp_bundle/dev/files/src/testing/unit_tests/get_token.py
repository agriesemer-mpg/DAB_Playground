# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

dbutils = MagicMock()
dbutils.secrets.get.side_effect = lambda scope, key: f"mocked_{key}"

# COMMAND ----------

# Test class
class TestGetToken(unittest.TestCase):

    def setUp(self):
        # Patch `G.dbutils.secrets.get`
        patcher_dbutils = patch('_globals.Globals.dbutils', create=True)  # Patch dbutils desde _globals
        self.addCleanup(patcher_dbutils.stop)

        self.mock_dbutils = patcher_dbutils.start()
        self.mock_dbutils.secrets.get.side_effect = lambda scope, key: f"mocked_{key}"

    @patch("requests.post")
    def test_salesforce_success(self, mock_post):
        """
        Test for successfully retrieving a token from Salesforce.
        """
        # Mock the response from `requests.post`
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = '{"access_token": "mocked_token"}'
        mock_post.return_value = mock_response

        # Define test parameters
        str_system = "salesforce"
        dict_auth_params = {
            "instance_url": "https://mock.salesforce.com",
            "client_id": "mock_client_id",
            "client_secret": "mock_client_secret"
        }

        # Call the function
        result = get_token(str_system, dict_auth_params)

        # Assert the result contains the access token
        self.assertIn("access_token", result)
        self.assertEqual(result["access_token"], "mocked_token")

        # Assert that `requests.post` was called with the correct parameters
        mock_post.assert_called_once_with(
            "https://mock.salesforce.com/services/oauth2/token",
            params={
                "grant_type": "client_credentials",
                "client_id": "mocked_mock_client_id",
                "client_secret": "mocked_mock_client_secret"
            },
            headers={}
        )

    @patch("requests.post")
    def test_salesforce_http_error(self, mock_post):
        """
        Test for HTTP error when retrieving a token from Salesforce.
        """
        # Mock the response from `requests.post`
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.raise_for_status.side_effect = requests.exceptions.HTTPError("Unauthorized")
        mock_post.return_value = mock_response

        # Define test parameters
        str_system = "salesforce"
        dict_auth_params = {
            "instance_url": "https://mock.salesforce.com",
            "client_id": "mock_client_id",
            "client_secret": "mock_client_secret"
        }

        # Call the function
        result = get_token(str_system, dict_auth_params)

        # Assert the result contains an error
        self.assertIn("error", result)
        self.assertEqual(result["error"], "Failed to retrieve token")

    def test_unsupported_system(self):
        """
        Test for unsupported system when retrieving a token.
        """
        # Define test parameters
        str_system = "unsupported_system"
        dict_auth_params = {}

        # Call the function
        result = get_token(str_system, dict_auth_params)

        # Assert the result contains an error
        self.assertIn("error", result)
        self.assertEqual(result["error"], "Unsupported system")

    def test_missing_key(self):
        """
        Test for missing keys in auth parameters.
        """
        # Define test parameters
        str_system = "salesforce"
        dict_auth_params = {
            "instance_url": "https://mock.salesforce.com"
            # Missing "client_id" and "client_secret"
        }

        # Call the function
        result = get_token(str_system, dict_auth_params)

        # Assert the result contains an error
        self.assertIn("error", result)
        self.assertEqual(result["error"], "Failed to retrieve token")

    @patch("requests.post")
    def test_json_decode_error(self, mock_post):
        """
        Test for JSON decode error when retrieving a token.
        """
        # Mock the response from `requests.post`
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = "Invalid JSON"
        mock_post.return_value = mock_response

        # Define test parameters
        str_system = "salesforce"
        dict_auth_params = {
            "instance_url": "https://mock.salesforce.com",
            "client_id": "mock_client_id",
            "client_secret": "mock_client_secret"
        }

        # Call the function
        result = get_token(str_system, dict_auth_params)

        # Assert the result contains an error
        self.assertIn("error", result)
        self.assertEqual(result["error"], "Failed to retrieve token")


# Run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestGetToken)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
