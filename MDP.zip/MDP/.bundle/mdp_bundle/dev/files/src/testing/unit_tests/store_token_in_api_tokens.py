# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------


# Path to the blank original file
TEST_FILE_PATH = C.PATH_TO_CONFIGS + 'test_api_token.yml'


# Test class
class TestStoreTokenInApiTokens(unittest.TestCase):
    def setUp(self):
        """
        Reset the test file to a blank state before each test.
        """
        # Ensure the file exists and is blank
        with open(TEST_FILE_PATH, "w") as file:
            yaml.safe_dump({}, file)

    def test_store_token_success(self):
        """
        Test case for successfully storing a token in the YAML file.
        """
        # Define inputs
        str_path = C.PATH_TO_CONFIGS
        file_name = 'test_api_token.yml'
        str_env = "dev"
        str_system_name = "salesforce"
        token_data = {
            "instance_url": "https://example.salesforce.com",
            "access_token": "mocked_access_token"
        }
        token_lifetime_seconds = 3600

        # Call the function
        store_token_in_api_tokens(
            str_path=str_path,
            file_name=file_name,  # Specify the test file
            str_env=str_env,
            str_system_name=str_system_name,
            token_data=token_data,
            token_lifetime_seconds=token_lifetime_seconds
        )

        # Verify the contents of the file
        with open(TEST_FILE_PATH, "r") as file:
            data = yaml.safe_load(file)

        # Compare only the `access_token` field
        print(data)
        access_token = data.get(str_env, {}).get(str_system_name, {}).get("access_token")
        self.assertEqual(access_token, "mocked_access_token")
        print("Test passed: Access token successfully stored.")

    def test_store_token_update_existing(self):
        """
        Test case for updating an existing token in the YAML file.
        """
        # Prepopulate the file with existing data
        existing_data = {
            "dev": {
                "salesforce": {
                    "instance_url": "https://old.example.salesforce.com",
                    "access_token": "old_mocked_access_token",
                    "expiration_date": "2025-01-01 00:00:00"
                }
            }
        }
        with open(TEST_FILE_PATH, "w") as file:
            yaml.safe_dump(existing_data, file)

        # Define inputs
        str_path = C.PATH_TO_CONFIGS
        file_name = 'test_api_token.yml'
        str_env = "dev"
        str_system_name = "salesforce"
        token_data = {
            "instance_url": "https://example.salesforce.com",
            "access_token": "mocked_access_token"
        }
        token_lifetime_seconds = 3600

        # Call the function
        store_token_in_api_tokens(
            str_path=str_path,
            file_name=file_name,  # Specify the test file
            str_env=str_env,
            str_system_name=str_system_name,
            token_data=token_data,
            token_lifetime_seconds=token_lifetime_seconds
        )

        # Verify the contents of the file
        with open(TEST_FILE_PATH, "r") as file:
            data = yaml.safe_load(file)

        # Compare only the `access_token` field
        access_token = data.get(str_env, {}).get(str_system_name, {}).get("access_token")
        self.assertEqual(access_token, "mocked_access_token")
        print("Test passed: Access token successfully updated.")


# Run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestStoreTokenInApiTokens)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
