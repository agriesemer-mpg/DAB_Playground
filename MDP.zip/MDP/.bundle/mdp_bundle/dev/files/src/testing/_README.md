### overview
1. create unit tests for new functions
1. test end to end
1. pr

### 1. unit tests
1. create unit test using nigel (see prompt below)
1. review/update nigel's code to be good
1. add unit test to notebook running all tests (for now)
1. run all unit tests

### 2. test end to end
1. validate configs are correct for testing:
    - source_systems.yml:
      - file_test_system, is_active: true
      - salesforce, is_active: true
    - source_tables.yml:
      - file_watcher_merge_w_history_table, is_active: true
      - file_watcher_merge_w_history_table, schedule_or_file_watch: file_watch
      - file_watcher_merge_wo_history_table, is_active: true
      - file_watcher_merge_wo_history_table, schedule_or_file_watch: file_watch
      - file_watcher_append_table, is_active: true
      - file_watcher_append_table, schedule_or_file_watch: file_watch
      - file_watcher_overwrite_table, is_active: true
      - file_watcher_overwrite_table, schedule_or_file_watch: file_watch
      - (TODO: find a salesforce table that has data and can be used for testing)
      - salesforce_table, schedules: - now
      - salesforce_table, is_active: true
1. run end to end testing notebook
1. validate tables are created/accurate in validated schema

### 3. pr
1. name branch: dev_username_ticketnumber (ex: dev_jfrolick_172)
1. push branch
1. send link to pr in chat for code review
1. someone will respond if they are looking into it
1. that person pushes to master

### nigel prompt:
> For the purpose of unit testing, analyze the python function and list all edge cases, generate test data set, and finally generate testing scripts using unittest framework. Please note that the scripts generated will be run as a Databricks notebook. Please do NOT use mockMagic, instead, you should generate a dataframe with Test set, create the test table following Databricks three dot format during the setup and drop this table in the teardown. All tables created or dropped should be in aw_dev.default schema
> 
> Please use 
> suite = unittest.TestLoader().loadTestsFromTestCase(TestClass)
> unittest.TextTestRunner().run(suite)
> 
> to run the tests instead of
> if __name__ == '__main__':
>     unittest.main(argv=['first-arg-is-ignored'], exit=False) :
> 
> (PASTE FUNCTION TO TEST HERE)
