# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

class TestDeleteFilesAtPath(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.dbutils attribute directly
        patcher = patch('_globals.Globals.dbutils', create=True)  # Patch the class attribute
        self.addCleanup(patcher.stop)
        self.mock_dbutils = patcher.start()
        self.mock_dbutils.fs = MagicMock()

    def test_delete_files_at_path_folder_exists_with_files(self):
        file1 = MagicMock()
        file1.path = 'folder/file1.txt'
        file2 = MagicMock()
        file2.path = 'folder/file2.txt'

        self.mock_dbutils.fs.ls.return_value = [file1, file2]

        delete_files_at_path('folder')

        self.mock_dbutils.fs.ls.assert_called_once_with('folder')
        self.mock_dbutils.fs.rm.assert_any_call('folder/file1.txt', True)
        self.mock_dbutils.fs.rm.assert_any_call('folder/file2.txt', True)
        self.assertEqual(self.mock_dbutils.fs.rm.call_count, 2)

    def test_delete_files_at_path_folder_does_not_exist(self):
        self.mock_dbutils.fs.ls.side_effect = Exception("java.io.FileNotFoundException: Folder does not exist")

        delete_files_at_path('nonexistent_folder')

        self.mock_dbutils.fs.ls.assert_called_once_with('nonexistent_folder')
        self.mock_dbutils.fs.rm.assert_not_called()

    def test_delete_files_at_path_folder_exists_but_empty(self):
        self.mock_dbutils.fs.ls.return_value = []

        delete_files_at_path('empty_folder')

        self.mock_dbutils.fs.ls.assert_called_once_with('empty_folder')
        self.mock_dbutils.fs.rm.assert_not_called()

    def test_delete_files_at_path_folder_contains_subdirectories(self):
        file1 = MagicMock()
        file1.path = 'folder/file1.txt'
        subdir = MagicMock()
        subdir.path = 'folder/subdir/'

        self.mock_dbutils.fs.ls.return_value = [file1, subdir]

        delete_files_at_path('folder')

        self.mock_dbutils.fs.ls.assert_called_once_with('folder')
        self.mock_dbutils.fs.rm.assert_any_call('folder/file1.txt', True)
        self.mock_dbutils.fs.rm.assert_any_call('folder/subdir/', True)
        self.assertEqual(self.mock_dbutils.fs.rm.call_count, 2)

    def test_delete_files_at_path_unexpected_error(self):
        self.mock_dbutils.fs.ls.side_effect = Exception("Unexpected error")

        with self.assertRaises(Exception) as context:
            delete_files_at_path('folder')

        self.mock_dbutils.fs.ls.assert_called_once_with('folder')
        self.assertIn("cannot access local variable 'files' where it is not associated with a value", str(context.exception))
        self.mock_dbutils.fs.rm.assert_not_called()

# Run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestDeleteFilesAtPath)
unittest.TextTestRunner().run(suite)