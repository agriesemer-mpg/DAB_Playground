# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestRemoveAuditEntry(unittest.TestCase):

    def setUp(self):
        # Patch the `get_audit_table` function from `_functions`
        patcher_spark = patch('_globals.Globals.spark', create=True)  # Patch the Spark object
        patcher_get_audit_table = patch('_functions.get_audit_table', create=True)  # Patch `get_audit_table`

        self.addCleanup(patcher_spark.stop)
        self.addCleanup(patcher_get_audit_table.stop)

        self.mock_spark = patcher_spark.start()
        self.mock_get_audit_table = patcher_get_audit_table.start()

        # Create mock objects
        self.mock_df = MagicMock()
        self.mock_get_audit_table.return_value = self.mock_df

        # Mock filter and write operations
        self.mock_filtered_df = self.mock_df.filter.return_value
        self.mock_filtered_df.write.format.return_value.mode.return_value.save.return_value = None

    @patch("builtins.print")  # Mock the print function
    def test_remove_audit_entry_success(self, mock_print):
        """
        Test for successful removal of an audit entry.
        """
        # Define test parameters
        batch_id = "12345"
        audit_table_path = "path_to_audit_table"

        # Call the function
        remove_audit_entry(batch_id, audit_table_path)

        # Assert that `get_audit_table` was called with the correct path
        self.mock_get_audit_table.assert_called_once()

        # Assert that `filter` was called with the correct condition
        self.mock_df.filter.assert_called_once_with(self.mock_df.batch_id != batch_id)

        # Assert that `write.format.mode.save` was called with the correct parameters
        self.mock_filtered_df.write.format.assert_called_once_with("delta")
        self.mock_filtered_df.write.format.return_value.mode.assert_called_once_with("overwrite")


        # Assert that the correct success message was printed
        mock_print.assert_called_once_with("Successfully removed audit entry for batch_id 12345.")


suite = unittest.TestLoader().loadTestsFromTestCase(TestRemoveAuditEntry)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
