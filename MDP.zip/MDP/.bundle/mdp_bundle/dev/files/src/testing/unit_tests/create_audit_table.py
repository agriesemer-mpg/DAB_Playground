# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestCreateAuditTable(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher = patch('_globals.Globals.spark', create=True)
        self.addCleanup(patcher.stop)
        self.mock_spark = patcher.start()

        # Reset the mock before each test
        self.mock_spark.reset_mock()
        self.mock_spark.sql.side_effect = None

    def test_create_audit_table_success(self):
        """
        Test for successful audit table creation.
        """
        self.mock_spark.sql.return_value = None  # Simulate successful execution
        create_audit_table()
        self.mock_spark.sql.assert_called_once()

    @patch("builtins.print")  # Mock the print function
    def test_create_audit_table_sql_failure(self, mock_print):
        """
        Test for SQL execution failure during audit table creation.
        """
        # Simulate SQL execution failure with a specific message
        self.mock_spark.sql.side_effect = Exception("SQL execution error v2")

        # Call the function and expect the original Exception to be re-raised
        with self.assertRaises(Exception) as context:
            create_audit_table()

        # Capture the exception message
        exception_message = str(context.exception)

        # Assert the exception message contains "SQL execution error v2"
        self.assertIn("SQL execution error v2", exception_message)

        # Assert the print statement was executed with the correct error message
        mock_print.assert_called_once_with(f"An error occurred while creating the table: {exception_message}")


suite = unittest.TestLoader().loadTestsFromTestCase(TestCreateAuditTable)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
