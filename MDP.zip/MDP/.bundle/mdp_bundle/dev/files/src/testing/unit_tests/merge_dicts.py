# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

class TestMergeDicts(unittest.TestCase):
    def test_merge_dicts_success(self):
        # Define test input
        dict_system = {"key1": "value1", "key2": "value2", "key3": "value3"}
        dict_table = {"key2": "new_value2", "key4": "value4"}

        # Call the function
        result = merge_dicts(dict_table, dict_system)

        # Define expected output
        expected_result = {
            "key1": "value1",
            "key2": "new_value2",  # Overridden value
            "key3": "value3",
            "key4": "value4"       # New key-value pair
        }

        # Assert the result
        self.assertEqual(result, expected_result)

    def test_merge_dicts_empty_table(self):
        # Define test input
        dict_system = {"key1": "value1", "key2": "value2"}
        dict_table = {}  # Empty dictionary

        # Call the function
        result = merge_dicts(dict_table, dict_system)

        # Assert the result is the same as dict_system
        self.assertEqual(result, dict_system)

    def test_merge_dicts_empty_system(self):
        # Define test input
        dict_system = {}  # Empty dictionary
        dict_table = {"key1": "value1", "key2": "value2"}

        # Call the function
        result = merge_dicts(dict_table, dict_system)

        # Assert the result is the same as dict_table
        self.assertEqual(result, dict_table)

    def test_merge_dicts_no_overlap(self):
        # Define test input
        dict_system = {"key1": "value1"}
        dict_table = {"key2": "value2"}  # No overlapping keys

        # Call the function
        result = merge_dicts(dict_table, dict_system)

        # Define expected output
        expected_result = {
            "key1": "value1",
            "key2": "value2"  # New key-value pair
        }

        # Assert the result
        self.assertEqual(result, expected_result)

    def test_merge_dicts_override_all_keys(self):
        # Define test input
        dict_system = {"key1": "value1", "key2": "value2"}
        dict_table = {"key1": "new_value1", "key2": "new_value2"}  # Overriding all keys

        # Call the function
        result = merge_dicts(dict_table, dict_system)

        # Define expected output
        expected_result = {
            "key1": "new_value1",  # Overridden value
            "key2": "new_value2"   # Overridden value
        }

        # Assert the result
        self.assertEqual(result, expected_result)


suite = unittest.TestLoader().loadTestsFromTestCase(TestMergeDicts)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))