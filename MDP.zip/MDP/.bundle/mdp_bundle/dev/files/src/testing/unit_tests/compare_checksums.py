# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

class TestCompareChecksums(unittest.TestCase):
    def test_checksums_match(self):
        """
        Test when the source and destination checksums match.
        """
        source_checksum = "abc123"
        destination_checksum = "abc123"
        result = compare_checksums(source_checksum, destination_checksum)
        self.assertTrue(result)

    def test_checksums_do_not_match(self):
        """
        Test when the source and destination checksums do not match.
        """
        source_checksum = "abc123"
        destination_checksum = "def456"
        result = compare_checksums(source_checksum, destination_checksum)
        self.assertFalse(result)

    def test_source_checksum_is_none(self):
        """
        Test when the source checksum is None.
        """
        source_checksum = None
        destination_checksum = "abc123"
        with self.assertRaises(ValueError) as context:
            compare_checksums(source_checksum, destination_checksum)
        self.assertIn("Both source_checksum and destination_checksum must be provided and non-empty", str(context.exception))

    def test_destination_checksum_is_none(self):
        """
        Test when the destination checksum is None.
        """
        source_checksum = "abc123"
        destination_checksum = None
        with self.assertRaises(ValueError) as context:
            compare_checksums(source_checksum, destination_checksum)
        self.assertIn("Both source_checksum and destination_checksum must be provided and non-empty", str(context.exception))

    def test_both_checksums_are_none(self):
        """
        Test when both the source and destination checksums are None.
        """
        source_checksum = None
        destination_checksum = None
        with self.assertRaises(ValueError) as context:
            compare_checksums(source_checksum, destination_checksum)
        self.assertIn("Both source_checksum and destination_checksum must be provided and non-empty", str(context.exception))

    def test_source_checksum_is_empty(self):
        """
        Test when the source checksum is an empty string.
        """
        source_checksum = ""
        destination_checksum = "abc123"
        with self.assertRaises(ValueError) as context:
            compare_checksums(source_checksum, destination_checksum)
        self.assertIn("Both source_checksum and destination_checksum must be provided and non-empty", str(context.exception))

    def test_destination_checksum_is_empty(self):
        """
        Test when the destination checksum is an empty string.
        """
        source_checksum = "abc123"
        destination_checksum = ""
        with self.assertRaises(ValueError) as context:
            compare_checksums(source_checksum, destination_checksum)
        self.assertIn("Both source_checksum and destination_checksum must be provided and non-empty", str(context.exception))

    def test_both_checksums_are_empty(self):
        """
        Test when both the source and destination checksums are empty strings.
        """
        source_checksum = ""
        destination_checksum = ""
        with self.assertRaises(ValueError) as context:
            compare_checksums(source_checksum, destination_checksum)
        self.assertIn("Both source_checksum and destination_checksum must be provided and non-empty", str(context.exception))

suite = unittest.TestLoader().loadTestsFromTestCase(TestCompareChecksums)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))