# Databricks notebook source
# MAGIC %run ../notebooks/_shared

# COMMAND ----------

update_yaml_property(
    str_path='',  # Leave empty to use the default path (C.PATH_TO_CONFIGS)
    file_name='source_systems.yml',  # Specify the file name
    property_path=['is_active'],  # Path to the property
    property_value=True,  # Value for exceptions
    exceptions=[
        "file_test_system",  # Exception: file_test_system should have is_active=True
        "salesforce"         # Exception: salesforce should have is_active=True
    ],
    default_value=False  # Default value for the rest of the items
)


# COMMAND ----------

update_yaml_property(
    str_path='',  # Leave empty to use the default path (C.PATH_TO_CONFIGS)
    file_name='source_tables.yml',  # Specify the file name
    property_path=['is_active'],  # Path to the property
    property_value=True,  # Value for exceptions
    exceptions=[
        "file_watcher_merge_w_history_table",
        "file_watcher_merge_wo_history_table",
        "file_watcher_append_table",
        "file_watcher_overwrite_table",
        "AccountContactRelation"
    ],
    default_value=False  # Default value for the rest
)


# COMMAND ----------

update_yaml_property(
    str_path='',  # Leave empty to use the default path (C.PATH_TO_CONFIGS)
    file_name='source_tables.yml',  # Specify the file name
    property_path=['file_acquisition_parameters', 'schedule_or_file_watch'],  # Path to the nested property
    property_value='file_watch',  # Value for exceptions
    exceptions=[
        "file_watcher_merge_w_history_table",
        "file_watcher_merge_wo_history_table",
        "file_watcher_append_table",
        "file_watcher_overwrite_table"
    ]
    # No default_value provided for non-'is_active' properties
)


# COMMAND ----------

update_yaml_property(
    str_path='',  # Leave empty to use the default path (C.PATH_TO_CONFIGS)
    file_name='source_tables.yml',  # Specify the file name
    property_path=['schedule_names'],  # Path to the property
    property_value=['now'],  # Value for exceptions
    exceptions=[
        "AccountContactRelation"  # Exception for AccountContactRelation
    ]
    # No default_value provided for non-'is_active' properties
)


# COMMAND ----------

drop_testing_batches()

# COMMAND ----------

# Helper function to safely remove a file or directory
def safe_remove(path, recurse=True):
    try:
        # Check if the path exists
        dbutils.fs.ls(path)  # If this succeeds, the path exists
        dbutils.fs.rm(path, recurse=recurse)  # Remove the path
        print(f"Successfully removed: {path}")
    except Exception as e:
        if "java.io.FileNotFoundException" in str(e):
            print(f"Path does not exist, skipping removal: {path}")
        else:
            raise e  # Raise other exceptions

# Remove test files
safe_remove(f'{C.LANDING_VOLUME_NAME}file_test_system/file_watcher_merge_w_history_table')
safe_remove(f'{C.LANDING_VOLUME_NAME}file_test_system/file_watcher_append_table')
safe_remove(f'{C.LANDING_VOLUME_NAME}file_test_system/file_watcher_merge_wo_history_table')
safe_remove(f'{C.LANDING_VOLUME_NAME}file_test_system/file_watcher_overwrite_table')
safe_remove(f'{C.LANDING_VOLUME_NAME}salesforce/AccountContactRelation')


# COMMAND ----------

#drop tables
spark.sql(f"DROP TABLE IF EXISTS {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_merge_w_history_table")
spark.sql(f"DROP TABLE IF EXISTS {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_merge_wo_history_table")
spark.sql(f"DROP TABLE IF EXISTS {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_append_table")
spark.sql(f"DROP TABLE IF EXISTS {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_overwrite_table")
spark.sql(f"DROP TABLE IF EXISTS {C.STAGING_SCHEMA_NAME}_salesforce.accountcontactrelation")

spark.sql(f"DROP TABLE IF EXISTS {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_merge_w_history_table")
spark.sql(f"DROP TABLE IF EXISTS {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_merge_wo_history_table")
spark.sql(f"DROP TABLE IF EXISTS {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_append_table")
spark.sql(f"DROP TABLE IF EXISTS {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_overwrite_table")
spark.sql(f"DROP TABLE IF EXISTS {C.VALIDATED_SCHEMA_NAME}_salesforce.accountcontactrelation")

print(f"dropped: {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_merge_w_history_table")
print(f"dropped: {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_merge_w_history_table")