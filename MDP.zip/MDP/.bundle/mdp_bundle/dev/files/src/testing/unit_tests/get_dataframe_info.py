# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestGetDataFrameInfo(unittest.TestCase):

    def setUp(self):
        # Create a mocked DataFrame
        self.mock_df = MagicMock()

        # Mock the schema
        self.mock_schema = MagicMock()
        self.mock_schema.simpleString.return_value = "struct<field1:string,field2:int>"
        self.mock_schema.__str__.return_value = "StructType([StructField('field1', StringType(), True), StructField('field2', IntegerType(), True)])"
        self.mock_df.schema = self.mock_schema

        # Mock the fields in the schema
        mock_field1 = MagicMock()
        mock_field1.name = "field1"
        mock_field1.dataType = "string"
        mock_field1.nullable = True

        mock_field2 = MagicMock()
        mock_field2.name = "field2"
        mock_field2.dataType = "int"
        mock_field2.nullable = True

        self.mock_df.schema.fields = [mock_field1, mock_field2]

        # Mock the record count
        self.mock_df.count.return_value = 100

        # Mock the column count
        self.mock_df.columns = ["field1", "field2"]

    def test_get_dataframe_info_success(self):
        """
        Test for successfully retrieving DataFrame information.
        """
        # Call the function
        result = get_dataframe_info(self.mock_df)

        print(result)

        # Assert the result
        expected_result = {
            "str_schema": "struct<field1:string,field2:int>",
            "str_readable_schema": "field1: string, field2: int",
            "int_record_count": 100,
            "int_column_count": 2
        }

        # Assert that the schema methods were called
        self.mock_schema.simpleString.assert_called_once()

        # Assert that the count method was called
        self.mock_df.count.assert_called_once()

        # Assert the expected results
        self.assertEqual(result["str_schema"], expected_result["str_schema"])
        self.assertEqual(result["str_readable_schema"], expected_result["str_readable_schema"])
        self.assertEqual(result["int_record_count"], expected_result["int_record_count"])
        self.assertEqual(result["int_column_count"], expected_result["int_column_count"])


# Run the test suite
suite = unittest.TestLoader().loadTestsFromTestCase(TestGetDataFrameInfo)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
