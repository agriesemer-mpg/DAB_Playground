# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestDropTestingBatches(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher_spark = patch('_globals.Globals.spark', create=True)  # Patch the Spark class attribute
        self.addCleanup(patcher_spark.stop)
        self.mock_spark = patcher_spark.start()

        # Patch get_audit_table in the correct namespace
        patcher_get_audit_table = patch('__main__.get_audit_table', create=True)  # Replace '__main__' with your module name if needed
        self.addCleanup(patcher_get_audit_table.stop)
        self.mock_get_audit_table = patcher_get_audit_table.start()

        # Patch constants (e.g., C.PATH_TO_AUDIT_TABLE)
        patcher_constants = patch('__main__.C', create=True)  # Replace '__main__' with your module name if needed
        self.addCleanup(patcher_constants.stop)
        self.mock_constants = patcher_constants.start()

        # Reset the mocks before each test
        self.mock_spark.reset_mock()
        self.mock_get_audit_table.reset_mock()

        # Mock DataFrame
        self.mock_df = MagicMock()
        self.mock_get_audit_table.return_value = self.mock_df

        # Mock filter and write operations
        self.mock_filtered_df = self.mock_df.filter.return_value
        self.mock_filtered_df.write.format.return_value.mode.return_value.saveAsTable.return_value = None

        # Mock default path constant
        self.mock_constants.PATH_TO_AUDIT_TABLE = "default_path_to_audit_table"

    @patch("builtins.print")  # Mock the print function
    def test_drop_testing_batches_success(self, mock_print):
        """
        Test for successful removal of testing batches with a specified path.
        """
        # Define test parameters
        str_path = "path_to_audit_table"

        # Call the function
        drop_testing_batches(str_path)
        
        # Assert that the correct success message was printed
        mock_print.assert_called_once_with("Successfully removed testing batches.")

    @patch("builtins.print")  # Mock the print function
    def test_drop_testing_batches_default_path(self, mock_print):
        """
        Test for successful removal of testing batches with the default path.
        """
        # Call the function without specifying a path
        drop_testing_batches()

        # Assert that the correct success message was printed
        mock_print.assert_called_once_with("Successfully removed testing batches.")


suite = unittest.TestLoader().loadTestsFromTestCase(TestDropTestingBatches)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
