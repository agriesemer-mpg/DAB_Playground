# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

import unittest

class TestVolumeExists(unittest.TestCase):
    def test_valid_volume(self):
        self.assertEqual(volume_exists('aw_dev', 'inbound', 'dna'), True)

    def test_invalid_volume(self):
        self.assertEqual(volume_exists('aw_dev', 'inbound', 'fake_volume'), False)

    def test_invalid_catalog(self):
        self.assertEqual(volume_exists('fake_catalog', 'inbound', 'dna'), False)

    def test_invalid_schema(self):
        self.assertEqual(volume_exists('aw_dev', 'fake_schema', 'dna'), False)

# To run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestVolumeExists)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
