# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

class TestCreateVolume(unittest.TestCase):


    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher = patch('_globals.Globals.spark', create=True)
        self.addCleanup(patcher.stop)
        self.mock_spark = patcher.start()

        # Reset the mock before each test
        self.mock_spark.reset_mock()
        self.mock_spark.sql.side_effect = None
    
    def test_create_volume_success(self):
        self.mock_spark.sql.return_value = None
        create_volume("test_catalog", "test_schema", "test_volume")
        self.mock_spark.sql.assert_called_once_with("CREATE VOLUME IF NOT EXISTS test_catalog.test_schema.test_volume")

    def test_create_volume_missing_arguments(self):
        with self.assertRaises(ValueError) as context:
            create_volume(None, "test_schema", "test_volume")
        self.assertEqual(str(context.exception), "Catalog, schema, and volume must all be provided.")

        with self.assertRaises(ValueError) as context:
            create_volume("test_catalog", None, "test_volume")
        self.assertEqual(str(context.exception), "Catalog, schema, and volume must all be provided.")

        with self.assertRaises(ValueError) as context:
            create_volume("test_catalog", "test_schema", None)
        self.assertEqual(str(context.exception), "Catalog, schema, and volume must all be provided.")

suite = unittest.TestLoader().loadTestsFromTestCase(TestCreateVolume)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))