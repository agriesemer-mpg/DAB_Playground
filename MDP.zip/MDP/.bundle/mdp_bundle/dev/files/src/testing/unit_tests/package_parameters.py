# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

class TestPackageParameters(unittest.TestCase):
    def test_package_parameters_success(self):
        # Define test input
        list_source_tables = [
            {
                "source_system_name": "system1",
                "schedule_names": ["schedule1"],
                "file_acquisition_parameters": {"param1": "value1"},
                "ingest_parameters": {"ingest_param1": "ingest_value1"}
            },
            {
                "source_system_name": "system2",
                "schedule_names": ["schedule2"],
                "salesforce_acquisition_parameters": {"sf_param1": "sf_value1"},
                "ingest_parameters": {"ingest_param2": "ingest_value2"}
            }
        ]

        list_source_systems = [
            {
                "source_system_name": "system1",
                "source_system_type": "file",  # Ensure this key exists
                "schedule_names": ["schedule1", "schedule3"],
                "file_acquisition_parameters": {"param2": "value2"},
                "ingest_parameters": {"ingest_param1": "system_ingest_value1"}
            },
            {
                "source_system_name": "system2",
                "source_system_type": "salesforce",  # Ensure this key exists
                "schedule_names": ["schedule2"],
                "salesforce_acquisition_parameters": {"sf_param2": "sf_value2"},
                "ingest_parameters": {"ingest_param2": "system_ingest_value2"}
            }
        ]

        list_schedules = [
            {"schedule_name": "schedule1", "schedule_detail": "detail1"},
            {"schedule_name": "schedule2", "schedule_detail": "detail2"},
            {"schedule_name": "schedule3", "schedule_detail": "detail3"}
        ]

        dict_targets = {
            "landing_volume": "landing_volume",
            "staging_schema": "staging_schema",
            "bronze_schema": "bronze_schema"
        }

        # Call the function
        result = package_parameters(
            list_source_tables, list_source_systems, list_schedules, dict_targets
        )

        # Define expected output based on the current function behavior
        expected_result = [
            {
                "source_system_name": "system1",
                "schedule_names": ["schedule1"],
                "source_system": {
                    "source_system_name": "system1",
                    "source_system_type": "file",  # Ensure this key exists
                    "schedule_names": ["schedule1", "schedule3"]
                },
                "targets": dict_targets,
                "schedules": [
                    {"schedule_name": "schedule1", "schedule_detail": "detail1"},
                    {"schedule_name": "schedule3", "schedule_detail": "detail3"}
                ],
                "file_acquisition_parameters": {"param1": "value1", "param2": "value2"},
                "ingest_parameters": {"ingest_param1": "ingest_value1"}
            },
            {
                "source_system_name": "system2",
                "schedule_names": ["schedule2"],
                "source_system": {
                    "source_system_name": "system2",
                    "source_system_type": "salesforce",  # Ensure this key exists
                    "schedule_names": ["schedule2"]
                },
                "targets": dict_targets,
                "schedules": [
                    {"schedule_name": "schedule2", "schedule_detail": "detail2"}
                ],
                "salesforce_acquisition_parameters": {
                    "sf_param1": "sf_value1",
                    "sf_param2": "sf_value2"
                },
                "ingest_parameters": {"ingest_param2": "ingest_value2"}
            }
        ]

        # Assert the result
        self.assertEqual(result[0], expected_result[0])


suite = unittest.TestLoader().loadTestsFromTestCase(TestPackageParameters)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))