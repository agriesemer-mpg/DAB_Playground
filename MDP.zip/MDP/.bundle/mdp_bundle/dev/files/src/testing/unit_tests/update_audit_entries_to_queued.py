# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestUpdateAuditEntriesToQueued(unittest.TestCase):

    def setUp(self):
        # Patch global mocks
        patcher_get_audit_table = patch('_functions.get_audit_table', create=True)  # Patch `get_audit_table`
        patcher_col = patch('pyspark.sql.functions.col', create=True)  # Patch PySpark's `col`
        patcher_lit = patch('pyspark.sql.functions.lit', create=True)  # Patch PySpark's `lit`
        patcher_when = patch('pyspark.sql.functions.when', create=True)  # Patch PySpark's `when`

        self.addCleanup(patcher_get_audit_table.stop)
        self.addCleanup(patcher_col.stop)
        self.addCleanup(patcher_lit.stop)
        self.addCleanup(patcher_when.stop)

        self.mock_get_audit_table = patcher_get_audit_table.start()
        self.mock_col = patcher_col.start()
        self.mock_lit = patcher_lit.start()
        self.mock_when = patcher_when.start()

        # Mock the DataFrame returned by `get_audit_table`
        self.mock_df_audit_table = MagicMock()
        self.mock_get_audit_table.return_value = self.mock_df_audit_table

        # Mock the `withColumn` method to return the same mocked DataFrame
        self.mock_updated_df = MagicMock()
        self.mock_df_audit_table.withColumn.return_value = self.mock_updated_df

        # Mock the `write` method and its chaining
        self.mock_write = MagicMock()
        self.mock_updated_df.write = self.mock_write
        self.mock_write.mode.return_value = self.mock_write
        self.mock_write.saveAsTable = MagicMock()

    def test_update_audit_entries_to_queued_success(self):
        """
        Test for successfully updating audit entries to 'Queued'.
        """
        # Define test input
        list_batch_ids = [1, 2]

        # Call the function
        update_audit_entries_to_queued(list_batch_ids)

        # Assert that `get_audit_table` was called
        self.mock_get_audit_table.assert_called_once()

        # Assert that `withColumn` was called
        self.mock_df_audit_table.withColumn.assert_called_once()

        # Assert that `mode` was called with 'overwrite'
        self.mock_write.mode.assert_called_once_with("overwrite")

        # Assert that `saveAsTable` was called with the correct table name
        self.mock_write.saveAsTable.assert_called_once_with(C.PATH_TO_AUDIT_TABLE)


suite = unittest.TestLoader().loadTestsFromTestCase(TestUpdateAuditEntriesToQueued)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
