# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test Suite
class TestGetMinMaxTimestamp(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Use the real Spark session provided by Databricks
        cls.spark = SparkSession.builder.getOrCreate()

        # Create a temporary DataFrame for testing
        cls.test_data = [
            ("2023-01-01 00:00:00",),
            ("2023-12-31 23:59:59",)
        ]
        cls.schema = ["system_date_field"]
        cls.df = cls.spark.createDataFrame(cls.test_data, cls.schema)

    def test_get_min_max_timestamp_success(self):
        # Call the function
        result = get_min_max_timestamp(self.df, "system_date_field")

        # Verify the result
        self.assertEqual(result, (datetime(2023, 1, 1, 0, 0), datetime(2023, 12, 31, 23, 59, 59)))

    def test_get_min_max_timestamp_missing_column(self):
        # Create a DataFrame with dummy data but without the required column
        df_missing_column = self.spark.createDataFrame([("dummy_data",)], ["another_field"])

        # Call the function
        result = get_min_max_timestamp(df_missing_column, "system_date_field")

        # Verify the result is (None, None)
        self.assertEqual(result, (None, None))

    def test_get_min_max_timestamp_error(self):
        # Simulate an error by passing an invalid column name
        result = get_min_max_timestamp(self.df, "non_existent_column")

        # Verify the result is (None, None)
        self.assertEqual(result, (None, None))


# Run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestGetMinMaxTimestamp)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))