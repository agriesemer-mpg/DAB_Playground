# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestUpdateAuditEntryJobAfterIngestion(unittest.TestCase):

    def setUp(self):
        # Patch global mocks
        patcher_spark = patch('_globals.Globals.spark', create=True)  # Patch SparkSession
        patcher_delta_table = patch('_functions.DeltaTable', create=True)  # Patch DeltaTable desde _functions
        patcher_get_min_max_timestamp = patch('_functions.get_min_max_timestamp', create=True)  # Patch get_min_max_timestamp
        patcher_get_dataframe_info = patch('_functions.get_dataframe_info', create=True)  # Patch get_dataframe_info

        self.addCleanup(patcher_spark.stop)
        self.addCleanup(patcher_delta_table.stop)
        self.addCleanup(patcher_get_min_max_timestamp.stop)
        self.addCleanup(patcher_get_dataframe_info.stop)

        self.mock_spark = patcher_spark.start()
        self.mock_delta_table = patcher_delta_table.start()
        self.mock_get_min_max_timestamp = patcher_get_min_max_timestamp.start()
        self.mock_get_dataframe_info = patcher_get_dataframe_info.start()

        # Mock the DataFrame returned by `spark.table`
        self.mock_df_staging = MagicMock()
        self.mock_spark.table.return_value = self.mock_df_staging

        # Mock DeltaTable.forName
        self.mock_delta_table_instance = MagicMock()
        self.mock_delta_table.forName.return_value = self.mock_delta_table_instance

        # Configure mocks for `get_min_max_timestamp` and `get_dataframe_info`
        self.mock_get_min_max_timestamp.return_value = ("2023-01-01 00:00:00", "2023-12-31 23:59:59")
        self.mock_get_dataframe_info.return_value = {"int_record_count": 100, "int_column_count": 10}

    @patch("builtins.print")  # Mock the print function
    def test_update_audit_entry_job_after_ingestion_success(self, mock_print):
        """
        Test for successfully updating audit entry job after ingestion.
        """
        # Test parameters
        batch_id = 123
        str_staging_catalog_path = "mock_staging_catalog_path"
        str_system_date_field = "mock_system_date_field"
        str_task_step = "IngestionComplete"
        str_job_status = "Complete"

        # Call the function
        update_audit_entry_job_after_ingestion(
            batch_id,
            str_staging_catalog_path,
            str_system_date_field,
            str_task_step,
            str_job_status
        )

        # Verify that `spark.table` was called with the correct path
        self.mock_spark.table.assert_called_once_with(str_staging_catalog_path)

        # Verify that `get_min_max_timestamp` was called with the correct arguments
        self.mock_get_min_max_timestamp.assert_called_once_with(self.mock_df_staging, str_system_date_field)

        # Verify that `get_dataframe_info` was called with the correct DataFrame
        self.mock_get_dataframe_info.assert_called_once_with(self.mock_df_staging)

        # Verify that DeltaTable.forName was called with the correct table path
        self.mock_delta_table.forName.assert_called_once_with(self.mock_spark, C.PATH_TO_AUDIT_TABLE)

        # Verify that the merge operation was executed
        self.mock_delta_table_instance.alias.assert_called_once_with("tgt")
        self.mock_delta_table_instance.alias.return_value.merge.assert_called_once()
        self.mock_delta_table_instance.alias.return_value.merge.return_value.whenMatchedUpdate.assert_called_once()
        self.mock_delta_table_instance.alias.return_value.merge.return_value.whenMatchedUpdate.return_value.execute.assert_called_once()

    def test_update_audit_entry_job_after_ingestion_failure(self):
        """
        Test for failure during the merge operation.
        """
        # Simulate an exception during the merge operation
        self.mock_delta_table_instance.alias.return_value.merge.return_value.whenMatchedUpdate.return_value.execute.side_effect = Exception("Merge operation failed")

        # Test parameters
        batch_id = 123
        str_staging_catalog_path = "mock_staging_catalog_path"
        str_system_date_field = "mock_system_date_field"
        str_task_step = "IngestionComplete"
        str_job_status = "Complete"

        # Call the function and expect a ValueError
        with self.assertRaises(ValueError) as context:
            update_audit_entry_job_after_ingestion(
                batch_id,
                str_staging_catalog_path,
                str_system_date_field,
                str_task_step,
                str_job_status
            )

        # Verify that the exception message is correct
        self.assertIn(f"Failed to update audit entry for batch_id {batch_id}", str(context.exception))
        self.assertIn("Merge operation failed", str(context.exception))


# Load the test suite and run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestUpdateAuditEntryJobAfterIngestion)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
