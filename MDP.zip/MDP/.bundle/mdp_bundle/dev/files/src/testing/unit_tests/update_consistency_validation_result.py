# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestUpdateConsistencyValidationResult(unittest.TestCase):

    def setUp(self):
        # Patch global mocks
        patcher_spark = patch('_globals.Globals.spark', create=True)  # Patch SparkSession desde _globals
        patcher_delta_table = patch('_functions.DeltaTable', create=True)  # Patch DeltaTable desde _functions

        self.addCleanup(patcher_spark.stop)
        self.addCleanup(patcher_delta_table.stop)

        self.mock_spark = patcher_spark.start()
        self.mock_delta_table = patcher_delta_table.start()

        # Mock spark.createDataFrame to return a mocked DataFrame
        self.mock_updates_df = MagicMock()
        self.mock_spark.createDataFrame.return_value = self.mock_updates_df

        # Mock DeltaTable.forName to return a mocked Delta table
        self.mock_delta_table_instance = MagicMock()
        self.mock_delta_table.forName.return_value = self.mock_delta_table_instance

    @patch("builtins.print")  # Mock the print function
    def test_update_success(self, mock_print):
        """
        Test a successful update of the consistency validation result.
        """
        # Define test parameters
        batch_id = 123
        validation_result = True

        # Call the function
        update_consistency_validation_result(batch_id, validation_result)

        # Assert that spark.createDataFrame was called with the correct parameters
        self.mock_spark.createDataFrame.assert_called_once_with(
            [{"batch_id": batch_id, "source_landing_consistency_validation_result": validation_result}],
            schema=StructType([
                StructField("batch_id", IntegerType(), False),
                StructField("source_landing_consistency_validation_result", StringType(), True)
            ])
        )

        # Assert that DeltaTable.forName was called with the correct table name
        self.mock_delta_table.forName.assert_called_once_with(self.mock_spark, C.PATH_TO_AUDIT_TABLE)

        # Assert that the merge operation was performed
        self.mock_delta_table_instance.alias.assert_called_once_with("tgt")
        self.mock_delta_table_instance.alias.return_value.merge.assert_called_once_with(
            self.mock_updates_df.alias.return_value,
            "tgt.batch_id = src.batch_id"
        )

        self.mock_delta_table_instance.alias.return_value.merge.return_value.whenMatchedUpdate.return_value.execute.assert_called_once()

        # Assert that the print function was called with the correct message
        mock_print.assert_called_once_with(
            f"Updated source_landing_consistency_validation_result for batch_id {batch_id} to {validation_result}"
        )

    def test_update_failure(self):
        """
        Test a failure during the update operation.
        """
        # Simulate an exception during the merge operation
        self.mock_delta_table_instance.alias.return_value.merge.side_effect = Exception("Merge operation failed")

        # Define test parameters
        batch_id = 123
        validation_result = False

        # Call the function and expect a ValueError
        with self.assertRaises(ValueError) as context:
            update_consistency_validation_result(batch_id, validation_result)

        # Assert the exception message is correct
        self.assertIn(f"Failed to update consistency validation result for batch_id {batch_id}", str(context.exception))
        self.assertIn("Merge operation failed", str(context.exception))


# Run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestUpdateConsistencyValidationResult)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
