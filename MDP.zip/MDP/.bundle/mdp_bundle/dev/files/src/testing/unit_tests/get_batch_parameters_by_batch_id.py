# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestGetBatchParametersByBatchId(unittest.TestCase):

    def setUp(self):
        # Patch the Globals.spark attribute directly
        patcher_spark = patch('_globals.Globals.spark', create=True)  # Patch the Spark class attribute
        patcher_col = patch('pyspark.sql.functions.col', create=True)  # Patch the col function
        self.addCleanup(patcher_spark.stop)
        self.addCleanup(patcher_col.stop)
        self.mock_spark = patcher_spark.start()
        self.mock_col = patcher_col.start()

        # Mock the DataFrame returned by `spark.table`
        self.mock_df_audit_table = MagicMock()

        # Mock the `filter` method to return the same mocked DataFrame
        self.mock_df_audit_table.filter.return_value = self.mock_df_audit_table

        # Mock the `select` method to return the same mocked DataFrame
        self.mock_df_audit_table.select.return_value = self.mock_df_audit_table

        # Mock the `collect` method to return a mocked row
        self.mock_row = [{"batch_parameters": '{"param1": "value1", "param2": "value2"}'}]
        self.mock_df_audit_table.collect.return_value = self.mock_row

        # Mock `spark.table` to return the mocked DataFrame
        self.mock_spark.table.return_value = self.mock_df_audit_table

        # Mock the behavior of `col`
        self.mock_col_instance = MagicMock()
        self.mock_col.return_value = self.mock_col_instance

    @patch("json.loads")  # Mock `json.loads`
    def test_get_batch_parameters_by_batch_id_success(self, mock_json_loads):
        """
        Test for successfully retrieving batch parameters by batch ID.
        """
        # Mock `json.loads` to return a dictionary
        mock_json_loads.return_value = {"param1": "value1", "param2": "value2"}

        # Define test parameters
        batch_id = 12345

        # Call the function
        result = get_batch_parameters_by_batch_id(batch_id)

        # Assert the result
        self.assertEqual(result, {"param1": "value1", "param2": "value2"})

        # Assert that `spark.table` was called with the correct path
        self.mock_spark.table.assert_called_once_with(C.PATH_TO_AUDIT_TABLE) 

        # Assert that `filter` was called with the correct arguments
        self.mock_df_audit_table.filter.assert_called_once_with(self.mock_col.return_value == batch_id)

        # Assert that `select` was called with the correct column
        self.mock_df_audit_table.select.assert_called_once_with("batch_parameters")

        # Assert that `collect` was called
        self.mock_df_audit_table.collect.assert_called_once()

        # Assert that `json.loads` was called with the correct batch_parameters
        mock_json_loads.assert_called_once_with('{"param1": "value1", "param2": "value2"}')

    def test_get_batch_parameters_by_batch_id_failure(self):
        """
        Test for handling errors when retrieving batch parameters by batch ID.
        """
        # Mock `spark.table` to raise an exception
        self.mock_spark.table.side_effect = Exception("Table not found")

        # Define test parameters
        batch_id = 12345

        # Call the function and assert that it raises a ValueError
        with self.assertRaises(ValueError) as cm:
            get_batch_parameters_by_batch_id(batch_id)

        # Assert the exception message
        self.assertEqual(
            str(cm.exception),
            f"Failed to retrieve batch parameters for batch_id {batch_id}: Table not found"
        )

        # Assert that `spark.table` was called with the correct path
        self.mock_spark.table.assert_called_once_with(C.PATH_TO_AUDIT_TABLE)


# Run the test suite
suite = unittest.TestLoader().loadTestsFromTestCase(TestGetBatchParametersByBatchId)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
