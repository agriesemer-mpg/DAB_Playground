# Databricks notebook source
# MAGIC %run ../notebooks/_shared

# COMMAND ----------

# MAGIC %md
# MAGIC ## Consistency validation between source and landing

# COMMAND ----------

# Query the Delta table to retrieve records with source_system_name = 'file_test_system'
df_validation_result = spark.sql(f"""
    SELECT batch_id, source_landing_consistency_validation_result
    FROM {C.PATH_TO_AUDIT_TABLE}
    WHERE source_system_name = 'file_test_system'
""")

# Collect the results
validation_results = df_validation_result.collect()

# Iterate through the results and validate that all records are True
for row in validation_results:
    batch_id = row["batch_id"]
    validation_result = row["source_landing_consistency_validation_result"]

    # Assert that the validation result is True
    assert validation_result == True, (
        f"Validation failed for batch_id {batch_id}: "
        f"source_landing_consistency_validation_result = {validation_result}"
    )

    print(f"Validation passed for batch_id {batch_id}: source_landing_consistency_validation_result = {validation_result}")

# If all records are True, print a success message
print(f"All records with source_system_name 'file_test_system' have source_landing_consistency_validation_result = True.")


# COMMAND ----------

# Query the Delta table to retrieve checksums for records with source_system_name = 'file_test_system'
df_checksums = spark.sql(f"""
    SELECT batch_id, source_checksum, landing_checksum
    FROM {C.PATH_TO_AUDIT_TABLE}
    WHERE source_system_name = 'file_test_system'
""")

# Collect the results
checksums = df_checksums.collect()

# Iterate through the results and compare checksums
for row in checksums:
    batch_id = row["batch_id"]
    source_checksum = row["source_checksum"]
    landing_checksum = row["landing_checksum"]

    # Assert that the checksums match
    assert source_checksum == landing_checksum, (
        f"Checksums do not match for batch_id {batch_id}: "
        f"source_checksum = {source_checksum}, landing_checksum = {landing_checksum}"
    )

    print(f"Checksums match for batch_id {batch_id}: {source_checksum} == {landing_checksum}")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Staging metrics

# COMMAND ----------

df_staging_merge_w_history = spark.sql(f"SELECT COUNT(*) AS row_count FROM {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_merge_w_history_table")
int_staging_merge_w_history_row_count = df_staging_merge_w_history.collect()[0]["row_count"]

df_staging_merge_wo_history = spark.sql(f"SELECT COUNT(*) AS row_count FROM {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_merge_wo_history_table")
int_staging_merge_wo_history_row_count = df_staging_merge_wo_history.collect()[0]["row_count"]

df_staging_append_table = spark.sql(f"SELECT COUNT(*) AS row_count FROM {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_append_table")
int_staging_append_table_row_count = df_staging_append_table.collect()[0]["row_count"]

df_staging_overwrite_table = spark.sql(f"SELECT COUNT(*) AS row_count FROM {C.STAGING_SCHEMA_NAME}_file_test_system.file_watcher_overwrite_table")
int_staging_overwrite_table_row_count = df_staging_overwrite_table.collect()[0]["row_count"]

# Assert the row count
assert int_staging_merge_w_history_row_count == 8, f"Expected 8 rows, but found {int_staging_merge_w_history_row_count} rows."
assert int_staging_merge_wo_history_row_count == 8, f"Expected 8 rows, but found {int_staging_merge_wo_history_row_count} rows."
assert int_staging_append_table_row_count == 8, f"Expected 8 rows, but found {int_staging_append_table_row_count} rows."
assert int_staging_overwrite_table_row_count == 8, f"Expected 8 rows, but found {int_staging_overwrite_table_row_count} rows."

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validated table metrics

# COMMAND ----------

df_validated_merge_w_history = spark.sql(f"SELECT COUNT(*) AS row_count FROM {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_merge_w_history_table")
int_validated_merge_w_history_row_count = df_validated_merge_w_history.collect()[0]["row_count"]

df_validated_merge_wo_history = spark.sql(f"SELECT COUNT(*) AS row_count FROM {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_merge_wo_history_table")
int_validated_merge_wo_history_row_count = df_validated_merge_wo_history.collect()[0]["row_count"]

df_validated_append_table = spark.sql(f"SELECT COUNT(*) AS row_count FROM {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_append_table")
int_validated_append_table_row_count = df_validated_append_table.collect()[0]["row_count"]

df_validated_overwrite_table = spark.sql(f"SELECT COUNT(*) AS row_count FROM {C.VALIDATED_SCHEMA_NAME}_file_test_system.file_watcher_overwrite_table")
int_validated_overwrite_table_row_count = df_validated_overwrite_table.collect()[0]["row_count"]

# Assert the row count
assert int_validated_merge_w_history_row_count == 6, f"Expected 6 rows, but found {int_validated_merge_w_history_row_count} rows."
assert int_validated_merge_wo_history_row_count == 5, f"Expected 5 rows, but found {int_validated_merge_wo_history_row_count} rows."
assert int_validated_append_table_row_count == 8, f"Expected 8 rows, but found {int_validated_append_table_row_count} rows."
assert int_validated_overwrite_table_row_count == 3, f"Expected 3 rows, but found {int_validated_overwrite_table_row_count} rows."