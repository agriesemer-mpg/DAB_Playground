# Databricks notebook source
# MAGIC %run ../../notebooks/_shared

# COMMAND ----------

# Test class
class TestUpdateChecksumProperty(unittest.TestCase):

    def setUp(self):
        # Patch global mocks
        patcher_spark = patch('_globals.Globals.spark', create=True)  # Patch SparkSession desde _globals
        patcher_delta_table = patch('_functions.DeltaTable', create=True)  # Patch DeltaTable desde _functions

        self.addCleanup(patcher_spark.stop)
        self.addCleanup(patcher_delta_table.stop)

        self.mock_spark = patcher_spark.start()
        self.mock_delta_table = patcher_delta_table.start()

        # Mock spark.createDataFrame to return a mocked DataFrame
        self.mock_updates_df = MagicMock()
        self.mock_spark.createDataFrame.return_value = self.mock_updates_df

        # Mock DeltaTable.forName to return a mocked Delta table
        self.mock_delta_table_instance = MagicMock()
        self.mock_delta_table.forName.return_value = self.mock_delta_table_instance

    @patch("builtins.print")  # Mock the print function (if needed)
    def test_valid_update(self, mock_print):
        """
        Test a valid checksum update.
        """
        # Define test parameters
        batch_id = 123
        column_name = "source_checksum"
        checksum_value = "mocked_checksum"

        # Call the function
        update_checksum_property(batch_id, column_name, checksum_value)

        # Assert that spark.createDataFrame was called with the correct parameters
        self.mock_spark.createDataFrame.assert_called_once_with(
            [{"batch_id": batch_id, column_name: checksum_value}],
            schema=StructType([
                StructField("batch_id", IntegerType(), False),
                StructField(column_name, StringType(), True)
            ])
        )

        # Assert that DeltaTable.forName was called with the correct table name
        self.mock_delta_table.forName.assert_called_once_with(self.mock_spark, C.PATH_TO_AUDIT_TABLE)

        # Assert that the merge operation was performed
        self.mock_delta_table_instance.alias.assert_called_once_with("tgt")
        self.mock_delta_table_instance.alias.return_value.merge.assert_called_once_with(
            self.mock_updates_df.alias.return_value,
            "tgt.batch_id = src.batch_id"
        )

        self.mock_delta_table_instance.alias.return_value.merge.return_value.whenMatchedUpdate.return_value.execute.assert_called_once()

    def test_invalid_column_name(self):
        """
        Test an invalid column name.
        """
        # Define test parameters
        batch_id = 123
        column_name = "invalid_column"
        checksum_value = "mocked_checksum"

        # Call the function and expect a ValueError
        with self.assertRaises(ValueError) as context:
            update_checksum_property(batch_id, column_name, checksum_value)

        # Assert the exception message is correct
        self.assertIn("Invalid column", str(context.exception))

    def test_update_failure(self):
        """
        Test a failure during the update operation.
        """
        # Simulate an exception during the merge operation
        self.mock_delta_table_instance.alias.return_value.merge.side_effect = Exception("Merge operation failed")

        # Define test parameters
        batch_id = 123
        column_name = "source_checksum"
        checksum_value = "mocked_checksum"

        # Call the function and expect a ValueError
        with self.assertRaises(ValueError) as context:
            update_checksum_property(batch_id, column_name, checksum_value)

        # Assert the exception message is correct
        self.assertIn(f"Failed to update {column_name} for batch_id {batch_id}", str(context.exception))
        self.assertIn("Merge operation failed", str(context.exception))


# Run the tests
suite = unittest.TestLoader().loadTestsFromTestCase(TestUpdateChecksumProperty)
result = unittest.TextTestRunner().run(suite)

# Check if there were any failures or errors
if not result.wasSuccessful():
    raise Exception("Test suite failed. Failures: {}, Errors: {}".format(
        len(result.failures), len(result.errors)
    ))
