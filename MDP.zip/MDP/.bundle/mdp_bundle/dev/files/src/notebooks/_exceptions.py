class ConstantLockedError(Exception):
    """Raised when trying to modify a locked constant."""
    def __init__(self, message=None):
        super().__init__(message)