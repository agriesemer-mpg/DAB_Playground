# Databricks notebook source
# Purpose: Pull batch parameters and pass to subsequent processes
# Called by: run_batch
# 1. Pull batch parameters for batch_id passed in
# 2. Update audit table to indicate RunBack workflow has started
# 3. Pass parameters to taskValues to be used in if/else loops in workflow

# COMMAND ----------

# MAGIC %run ./_shared

# COMMAND ----------

# DBTITLE 1,Get parameters from workflow
# batch_id maps to batch passed from forEach
batch_id = (dbutils.widgets.get("batch_id"))

# batch_parameters is pulled from audit table by batch_id
batch_parameters = get_batch_parameters_by_batch_id(batch_id)

# dict_targets is subset of targets from config yaml filtered to only active environment
dict_targets = batch_parameters["targets"]

#dict_source_systems is full dict of source systems from config yaml
dict_source_system = batch_parameters["source_system"]

# COMMAND ----------

update_audit_entry_job_start(batch_id)

# COMMAND ----------

# Write parameters to task values
dbutils.jobs.taskValues.set(key = "batch_id", value = batch_id)
dbutils.jobs.taskValues.set(key = "batch_parameters", value = batch_parameters)
dbutils.jobs.taskValues.set(key = "source_system_name", value = batch_parameters["source_system_name"])
dbutils.jobs.taskValues.set(key = "source_system_type", value = batch_parameters["source_system"]["source_system_type"])