# Databricks notebook source
# Purpose: Schedule batches based on configs
# Called By: orchestration
# 1. Pull config from yml files
# 2. Remove all future scheduled batches from audit table
# 3. Insert batches for any files with file watch enabled
# 4. Insert batches for any sources with schedules
# 5. Update batches to ready based on acquisition ready start time

# COMMAND ----------

# MAGIC %run ./_shared

# COMMAND ----------

def create_schedule(schedule_dict, days_to_add=7):
    """
    Using the schedule dictionary creates a list of dates that represent when the schedule will be created.
 
    Parameters:
        schedule_dict (dict): Dictionary with all of the schedule information for a specific schedule.
        days_to_add (int): Number of days in advance to create batches. For example, if you put 14 here,
                           it creates batches for the next 2 weeks.
 
    Returns:
        list_of_schedules (list): List of datetime objects for each future batch date.
 
    Works for: hourly, daily, weekly.
    Not tested: quarterly, day of the month, calendar day of the month.
    """
    # Safely retrieve the value of "hours_of_day" with a default if not present or None
    hours_of_day = schedule_dict.get("hours_of_day")
    if not hours_of_day:
        schedule_dict["hours"] = "00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23"
    else:
        schedule_dict["hours"] = hours_of_day
 
    # Safely retrieve the value of "days_of_week" with a default if not present or None
    days_of_week = schedule_dict.get("days_of_week")
    if not days_of_week:
        schedule_dict["days"] = "0,1,2,3,4,5,6"
    else:
        schedule_dict["days"] = days_of_week
 
    # Safely retrieve the value of "days_of_month" with a default if not present or None
    days_of_month = schedule_dict.get("days_of_month")
    if not days_of_month:
        schedule_dict["month"] = "0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31"
    else:
        schedule_dict["month"] = days_of_month
 
    # Empty list that will hold the datetimes for when batches should be created
    list_of_schedules = []
 
    # Make the baseline time for when to create new batches
    current_datetime = datetime.now(C.TZ_TIMEZONE)
    baseline_datetime = datetime.now(C.TZ_TIMEZONE)
 
    # Check if minutes_of_hour exists, otherwise default to "0"
    if "minutes_of_hour" not in schedule_dict or not schedule_dict.get("minutes_of_hour"):
        schedule_dict["minutes_of_hour"] = "0"
 
    # Looks at the days where batches need to be created
    s_days = schedule_dict["days"].split(",")
    for day in s_days:
        # Finds the date in the schedule in respect to the current day
        relative_day_of_week_num = int(day) - baseline_datetime.weekday()
 
        # Loop to account for the number of days the user wants to create batches for
        while relative_day_of_week_num < days_to_add:
            # If the relative day is before the current day then reset the number to make it correlate to the next week
            if relative_day_of_week_num < 0:
                relative_day_of_week_num += 7
            s_hours = schedule_dict["hours"].split(",")
            # *** HOURS
            for h in s_hours:
                s_minutes = schedule_dict["minutes_of_hour"].split(",")
                # *** MINUTES
                for m in s_minutes:
                    # Build schedules
                    next_schedule_datetime = baseline_datetime.replace(
                        day=(baseline_datetime.day),
                        hour=int(h),
                        minute=int(m),
                        second=0,
                        microsecond=0,
                    ) + timedelta(days=relative_day_of_week_num)
                    # Only adds the schedule to the list if the schedule day is in the future
                    if (
                        next_schedule_datetime > current_datetime
                        and next_schedule_datetime.strftime("%Y-%m-%d %H:%M:%S") not in list_of_schedules
                    ):
                        list_of_schedules.append(next_schedule_datetime.strftime("%Y-%m-%d %H:%M:%S"))
            # Shift the time by a week and then check if it is still in the right time frame
            relative_day_of_week_num += 7
 
    # It is not required to have the schedule run on a specific day of the month so this accounts for this
    if schedule_dict.get("month") and schedule_dict["month"] != "":
        month_days = schedule_dict["month"].split(",")
        for day in month_days:
            # Since the number of days in a month is not constant have to continuously shift the baseline date
            current_datetime = datetime.now(C.TZ_TIMEZONE)
            baseline_datetime = datetime.now(C.TZ_TIMEZONE)
            # Counter to see how many days we have progressed
            total_days = 0
            # Using a while true because do-while loops do not exist in python
            while True:
                # Finds how far away relatively the given day in the month from the current day
                relative_day_of_month_num = int(day) - int(
                    baseline_datetime.strftime("%d")
                )
                if relative_day_of_month_num < 0:
                    relative_day_of_month_num += calendar.monthrange(
                        baseline_datetime.year, baseline_datetime.month
                    )[1]
                total_days += calendar.monthrange(
                    baseline_datetime.year, baseline_datetime.month
                )[1]
                # If we are already over the number of days we want to create batches then break out of loop
                if total_days < days_to_add:
                    s_hours = schedule_dict["hours"].split(",")
                    # *** HOURS
                    for h in s_hours:
                        s_minutes = schedule_dict["minutes_of_hour"].split(",")
                        # *** MINUTES
                        for m in s_minutes:
                            # Build schedules
                            next_schedule_datetime = baseline_datetime.replace(
                                day=(baseline_datetime.day),
                                hour=int(h),
                                minute=int(m),
                                second=0,
                                microsecond=0,
                            ) + timedelta(days=relative_day_of_month_num)
                            # Only adds the schedule to the list if the schedule day is in the future
                            if (
                                next_schedule_datetime > current_datetime
                                and next_schedule_datetime.strftime("%Y-%m-%d %H:%M:%S") not in list_of_schedules
                            ):
                                list_of_schedules.append(next_schedule_datetime.strftime("%Y-%m-%d %H:%M:%S"))
                    # Increment the baseline date so we are at the same day and time in the next month
                    baseline_datetime = baseline_datetime + relativedelta(months=+1)
                else:
                    break
    return list_of_schedules

# COMMAND ----------

def insert_scheduled_batches(list_batch_parameters, days_to_add=7):
    """
    Inserts multiple audit entries into the 'audit_table' table at once,
    dynamically generating schedules based on each batch's schedule information.
 
    Parameters:
    list_batch_parameters (list): A list of dictionaries containing batch parameters.
                                  Each batch should contain a 'schedules' key with a list of schedule dictionaries.
    days_to_add (int): Number of days in advance to create batches. Default is 7 days.
 
    Returns:
    None
    """
    try:       
        # Define schema once
        schema = StructType([
            StructField("job_id", StringType(), True),
            StructField("source_system_name", StringType(), True),
            StructField("target_table_name", StringType(), True),
            StructField("job_status", StringType(), True),
            StructField("acquisition_ready_datetime", TimestampType(), True),
            StructField("job_start_time", TimestampType(), True),
            StructField("job_end_time", TimestampType(), True),
            StructField("job_duration", StringType(), True),
            StructField("flat_file_source_paths", ArrayType(StringType()), True),  # Array of strings
            StructField("landing_file_paths", ArrayType(StringType()), True),     # Array of strings
            StructField("data_schema", ArrayType(MapType(StringType(), StringType())), True),  # Array of string-to-string maps
            StructField("task_step", StringType(), True),
            StructField("transaction_date_min", TimestampType(), True),
            StructField("transaction_date_max", TimestampType(), True),
            StructField("landing_record_count", ArrayType(MapType(StringType(), IntegerType())), True),  # Array of string-to-int maps
            StructField("staging_record_count", LongType(), True),
            StructField("silver_record_count", LongType(), True),
            StructField("landing_column_count", ArrayType(MapType(StringType(), IntegerType())), True),  # Array of string-to-int maps
            StructField("staging_column_count", IntegerType(), True),
            StructField("silver_column_count", IntegerType(), True),
            StructField("schema_difference", ArrayType(MapType(StringType(), BooleanType())), True),  # Array of string-to-boolean maps
            StructField("validation_record_count", StringType(), True),
            StructField("changed_record_count", StringType(), True),
            StructField("attempt_number", IntegerType(), True),
            StructField("workflow_job_run_url", StringType(), True),
            StructField("modified_timestamp", TimestampType(), False),
            StructField("incremental_load_type", StringType(), True),
            StructField("batch_parameters", StringType(), True)
        ])
        
        # Current time
        current_time = datetime.now(C.TZ_TIMEZONE)
        
        # Create a list to collect all rows
        all_data = []
        
        # Process each batch parameters
        for batch_parameters in list_batch_parameters:
            
            # Create a list to hold all schedule dates
            all_schedule_dates = []
    
            # Get list of schedule dictionaries
            schedule_dicts = batch_parameters.get('schedules', [])

            # If schedule_names list contains now, add current datetime to list
            list_schedule_names = batch_parameters.get('schedule_names', [])
            if list_schedule_names and 'now' in list_schedule_names:
                all_schedule_dates.append(current_time.strftime("%Y-%m-%d %H:%M:%S"))

            # Process each schedule dictionary
            for schedule_dict in schedule_dicts:
                # Generate schedule dates from this schedule dictionary
                print('source: ', batch_parameters['target_table_name'])
                print('schedule_dict: ', schedule_dict)
                schedule_dates = create_schedule(schedule_dict, days_to_add) or []
                
                # Only add dates that aren't already in all_schedule_dates
                for date in schedule_dates:
                    if date not in all_schedule_dates:
                        all_schedule_dates.append(date)

            # If no schedule dates were created from any schedule, add a default entry
            if not all_schedule_dates:
                all_schedule_dates = []
                
            # Create a row for each scheduled datetime
            for str_acquisition_ready_datetime in all_schedule_dates:
                if str_acquisition_ready_datetime:
                    dt_acquisition_ready_datetime = datetime.strptime(str_acquisition_ready_datetime, "%Y-%m-%d %H:%M:%S")
                    dt_acquisition_ready_datetime = C.TZ_TIMEZONE.localize(dt_acquisition_ready_datetime)
                    str_job_status = 'Ready' if dt_acquisition_ready_datetime < current_time else 'Scheduled'
                else:
                    break
                    
                # Create a row at this datetime
                row = Row(
                    job_id                      = None,
                    source_system_name          = str(batch_parameters['source_system_name']),
                    target_table_name           = str(batch_parameters['target_table_name']),
                    job_status                  = str_job_status,
                    acquisition_ready_datetime  = dt_acquisition_ready_datetime,
                    job_start_time              = None,
                    job_end_time                = None,
                    job_duration                = None,
                    flat_file_source_paths      = None,
                    landing_file_paths          = None,
                    data_schema                 = None,
                    task_step                   = str_job_status,
                    transaction_date_min        = None,
                    transaction_date_max        = None,
                    landing_record_count        = None,
                    staging_record_count        = None,
                    silver_record_count         = None,
                    landing_column_count        = None,
                    staging_column_count        = None,
                    silver_column_count         = None,
                    schema_difference           = None,
                    validation_record_count     = None,
                    changed_record_count        = None,
                    attempt_number              = None,
                    workflow_job_run_url        = None,
                    modified_timestamp          = current_time,
                    incremental_load_type       = None,
                    batch_parameters            = json.dumps(batch_parameters)
                )
                
                all_data.append(row)
        
        # Create a single DataFrame with all rows
        df = spark.createDataFrame(all_data, schema=schema)
        
        # Write all rows at once to the audit table
        df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(C.PATH_TO_AUDIT_TABLE)
        
        print(f"Successfully added {len(all_data)} audit entries.")
   
    except Exception as e:
        print(f"An unexpected error occurred during the batch audit entry process: {e}")
        print(f"Traceback: {traceback.format_exc()}")

# COMMAND ----------

def remove_all_future_batches():
    """
    Removes all future batches from the audit table
    """

    # Load the table as a PySpark DataFrame
    df_audit_table = get_audit_table()

    # Filter the DataFrame to get rows where acquisition_ready_datetime is greater than the current timestamp
    df_filtered = df_audit_table.filter(
        (col("acquisition_ready_datetime") < current_timestamp())
    )

    # Check if table exists
    try:
        spark.sql(f"DESCRIBE TABLE {C.PATH_TO_AUDIT_TABLE}")
    except:
        print(f"Table {C.PATH_TO_AUDIT_TABLE} does not exist. Will create it.")
        create_audit_table()
    
    df_filtered.write.format("delta").mode("overwrite").saveAsTable(C.PATH_TO_AUDIT_TABLE)

# COMMAND ----------

def update_scheduled_jobs_to_ready():
    """
    Updates jobs in the 'Scheduled' state to 'Ready' if their acquisition_ready_datetime has passed.
    Only updates relevant rows without overwriting the entire table.

    The function performs the following steps:
    1. Loads the Delta table using its path.
    2. Defines the condition for rows to update:
       - Rows where `job_status` is 'Scheduled' AND `acquisition_ready_datetime` is less than the current timestamp.
    3. Executes a MERGE operation to update only matching rows in the Delta table.

    Raises:
        ValueError: If the update operation fails, an error message is raised.
    """
    try:
        # Load the Delta table
        delta_table = DeltaTable.forName(spark, C.PATH_TO_AUDIT_TABLE)

        # Define the condition for rows to update:
        # Rows where job_status = 'Scheduled' AND acquisition_ready_datetime < current time
        update_condition = (
            (col("job_status") == "Scheduled") &
            (col("acquisition_ready_datetime") < current_timestamp())
        )

        # Perform the MERGE operation to update only matching rows
        delta_table.alias("tgt").merge(
            delta_table.toDF().filter(update_condition).alias("src"),  # Filtered rows as source
            "tgt.batch_id = src.batch_id"  # Match rows by batch_id (or another unique identifier)
        ).whenMatchedUpdate(
            set={
                "job_status": lit("Ready")
            }
        ).execute()

        print("Successfully updated 'Scheduled' jobs to 'Ready' for eligible records.")

    except Exception as e:
        raise ValueError(f"Failed to update scheduled jobs: {e}")

# COMMAND ----------

def run_source_now(list_batch_parameters, str_source):
    """
    Makes a batch at the current time mostly for testing
    inputs:
      str_source: str - name of source system . name of the target table that you want to create a batch for (ex. salesforce.Account)
    """
    current_time = datetime.now(C.TZ_TIMEZONE).strftime("%Y-%m-%d %H:%M:%S")
    
    # Split the source string into source_system_name and target_table_name
    str_source_system_name, str_target_table_name = str_source.split(".")

    # Filter the dictionaries based on source_system_name and target_table_name
    list_active_batch_parameters = []
    for params in list_batch_parameters:
      if params['source_system_name'] == str_source_system_name and params['target_table_name'] == str_target_table_name:
        list_active_batch_parameters.append(params)

    for batch_parameters in list_active_batch_parameters:
        # Insert record into audit table
        insert_audit_entry(batch_parameters, current_time)
    
    update_scheduled_jobs_to_ready()
    return

# COMMAND ----------

def insert_file_watch_batches(list_batch_parameters):
    """
    Process and schedule file watch batches for data acquisition.

    Parameters:
        list_batch_parameters (list): A list of batch parameter dictionaries 
                                      containing file acquisition details.

    Returns:
        None: Executes source processing for active file watch batches.
    """
    # Filter batches to only include file watch sources
    list_file_watch_batches = filter_file_watch_batches(list_batch_parameters)
    
    # Iterate through each file watch batch
    for batch_parameters in list_file_watch_batches:
        # Safely retrieve file acquisition parameters
        # Use get() to provide an empty dict if parameters are missing
        dict_file_acquisition_parameters = batch_parameters.get("file_acquisition_parameters", {})

        str_source_system_name = batch_parameters.get("source_system_name", '')
        str_target_table_name = batch_parameters.get("target_table_name", '')
        
        # Retrieve list of files to process
        # Assuming get_file_list returns file paths and filenames
        list_file_paths, list_filenames = get_file_list(dict_file_acquisition_parameters)
        
        # Remove files that have already been processed
        # This prevents reprocessing of completed batches
        list_active_file_paths = remove_finished_batches_from_file_list(list_file_paths)
        
        # Check if there are any active files to process
        if list_active_file_paths or list_active_file_paths != []:
            # Construct a unique identifier for the source
            # Combines source system name and target table name
            str_source = f"{str_source_system_name}.{str_target_table_name}"
            
            # Run the source processing for the current batch
            # Passes the entire batch parameters list and the source identifier
            run_source_now(list_batch_parameters, str_source)

# COMMAND ----------

def get_filtered_source_tables_list_from_config(str_path=''):
    """
    Retrieves a filtered list of source tables from configuration YAML files, applying inclusion and exclusion criteria.

    Parameters:
    str_path (str): The path to the directory containing the configuration YAML files.
                    If not provided, defaults to a global variable 'C.PATH_TO_CONFIGS'.

    Returns:
    list: A list of dictionaries containing source table configurations after applying filters.
    """
    # Populate constant
    if not str_path:
        str_path = C.PATH_TO_CONFIGS

    try:
        # Load YAML files
        with open(str_path + 'source_tables.yml', 'r') as file:
            list_source_tables = yaml.safe_load(file)

        # Apply filter on is_active flag for source tables
        for table in list(list_source_tables):
            if not table['is_active']:
                list_source_tables.remove(table)

        return list_source_tables
    
    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")
    except KeyError as e:
        print(f"Missing expected key in configuration: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")
    return []

# COMMAND ----------

def get_filtered_targets_dict_from_config(str_path="", str_env=""):
    """
    Retrieves a dictionary of target configurations for a specified environment from a YAML file.

    Parameters:
    str_path (str): The path to the directory containing the 'targets.yml' file.
                    If not provided, defaults to a global variable 'C.PATH_TO_CONFIGS'.
    str_env (str): The environment key to extract target configurations for (e.g., 'dev', 'qa', 'prod').
                   If not provided, defaults to a global variable 'C.ENVIRONMENT'.

    Returns:
    dict: A dictionary containing the target configurations for the specified environment.
    """
    # Populate constants
    if not str_path:
        str_path = C.PATH_TO_CONFIGS

    if not str_env:
        str_env = C.ENVIRONMENT

    try:
        # Load YAML files
        with open(C.PATH_TO_CONFIGS + "targets.yml", "r") as file:
            targets = yaml.safe_load(file)

        return targets.get(str_env, [])

    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")
    except KeyError as e:
        print(f"Missing expected key in configuration: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")
    return {}

# COMMAND ----------

def get_schedules_list_from_config(str_path=""):
    """
    Retrieves a dictionary of target configurations for a specified environment from a YAML file.

    Parameters:
    str_path (str): The path to the directory containing the 'targets.yml' file.
                    If not provided, defaults to a global variable 'C.PATH_TO_CONFIGS'.
    str_env (str): The environment key to extract target configurations for (e.g., 'dev', 'qa', 'prod').
                   If not provided, defaults to a global variable 'C.ENVIRONMENT'.

    Returns:
    list of dicts: A list of dictionaries containing the target configurations for the specified environment.
    """
    # Populate constants
    if not str_path:
        str_path = C.PATH_TO_CONFIGS

    try:
        # Load YAML files
        with open(C.PATH_TO_CONFIGS + "schedules.yml", "r") as file:
            schedules = yaml.safe_load(file)

        return schedules

    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")
    except KeyError as e:
        print(f"Missing expected key in configuration: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")
    return {}

# COMMAND ----------

# Generate list of source systems from config YAML files
list_source_systems = get_source_systems_list_from_config()

# Generate list of source tables for ingestion by filtering source_tables.yml through ingestion_source_inclusions.yml and ingestion_source_exclusions.yml
list_source_tables = get_filtered_source_tables_list_from_config()

# Generate dict of targets from config YAML files
# dict_targets = get_filtered_targets_dict_from_config()

# Generate list of schedules from config YAML files
list_schedules = get_schedules_list_from_config()

# COMMAND ----------

# Update source_tables.yml to include new sources from Salesforce
for system in list_source_systems:
    if system['source_system_name'] == 'salesforce':
        dict_salesforce_auth_params = system['auth_parameters']

load_salesforce_objects_to_source_table_config(dict_salesforce_auth_params)

# COMMAND ----------

# Package parameters into one list
list_batch_parameters = package_parameters(list_source_tables, list_source_systems, list_schedules)
print(list_batch_parameters)

# COMMAND ----------

remove_all_future_batches()
insert_file_watch_batches(list_batch_parameters)
insert_scheduled_batches(list_batch_parameters)
update_scheduled_jobs_to_ready()