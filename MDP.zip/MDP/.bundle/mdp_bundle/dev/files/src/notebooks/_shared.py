# Databricks notebook source
# MAGIC %run ./_imports

# COMMAND ----------

validate_not_serverless_cluster()