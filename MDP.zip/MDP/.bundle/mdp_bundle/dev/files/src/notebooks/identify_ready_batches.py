# Databricks notebook source
# Purpose: Identify batches that a ready to be kicked off
# Called By: orchestration
# 1. Pull all ready jobs from audit table
# 2. Update jobs from Ready to Queued status
# 3. Update sources.yml based on Queued jobs
# 4. Pass list of batch_ids to the run_batch for each workflow

# COMMAND ----------

# MAGIC %run ./_shared

# COMMAND ----------

def batch_update_sources_yml(list_batch_parameters, str_sources_yml_path=''):
    """
    Updates the sources.yml file to include multiple tables from a batch of parameters,
    making only one file update at the end.
    
    Parameters:
        list_batch_parameters (list): List of dictionaries containing data pipeline configuration
        str_sources_yml_path (str, optional): Path to the sources.yml file
        
    Returns:
        bool: True if the file was modified, False otherwise
    """
    # Track if any changes were made
    bool_file_modified = False
    
    # Set default str_sources_yml_path
    if str_sources_yml_path == '':
        str_sources_yml_path = C.DBT_SOURCES_YML_PATH
    
    # Default structure for a new sources.yml file
    dict_sources_data = {
        'version': 2,
        'sources': []
    }
    
    # Read existing file if it exists
    if os.path.exists(str_sources_yml_path):
        with open(str_sources_yml_path, 'r') as f:
            try:
                dict_sources_data = yaml.safe_load(f)
                if not dict_sources_data:  # Handle empty file case
                    dict_sources_data = {'version': 2, 'sources': []}
            except yaml.YAMLError as e:
                print(f"Error parsing sources.yml: {e}")
                return False
    
    # Process each set of parameters in the batch
    for params in list_batch_parameters:
        # Extract parameters from the dictionary
        str_source_system_name = params.get('source_system_name')
        str_target_table_name = params.get('target_table_name')
        
        # Skip if essential parameters are missing
        if not str_source_system_name or not str_target_table_name:
            print("Skipping entry with missing source system name or target table name")
            continue
        
        # Check if entry is active
        if not params.get('is_active', True):
            print(f"Skipping inactive entry for {str_target_table_name}")
            continue
        
        # Set default str_staging_schema
        str_staging_schema = C.SCHEMA_USERNAME_PREFIX + 'staging_' + str_source_system_name
        
        # Find the right source or create it
        bool_source_found = False
        for source in dict_sources_data.get('sources', []):
            if source.get('name') == str_staging_schema:
                bool_source_found = True
                
                # Check if table already exists in this source
                bool_table_exists = False
                for table in source.get('tables', []):
                    if table.get('name') == str_target_table_name:
                        bool_table_exists = True
                        break
                
                # Add table if it doesn't exist
                if not bool_table_exists:
                    if 'tables' not in source:
                        source['tables'] = []
                    source['tables'].append({'name': str_target_table_name})
                    print(f"Added table {str_target_table_name} to existing source {str_staging_schema}")
                    bool_file_modified = True
                    break
                else:
                    print(f"Table {str_target_table_name} already exists in source {str_staging_schema}")
                    # Continue processing other tables even if this one exists
        
        # If source doesn't exist, create it
        if not bool_source_found:
            new_source = {
                'name': str_staging_schema,
                'database': C.CATALOG,
                'schema': str_staging_schema,
                'tables': [{'name': str_target_table_name}]
            }
            dict_sources_data['sources'].append(new_source)
            print(f"Created new source {str_staging_schema} with table {str_target_table_name}")
            bool_file_modified = True
    
    # Write back to file only if modifications were made
    if bool_file_modified:
        with open(str_sources_yml_path, 'w') as f:
            yaml.dump(dict_sources_data, f, default_flow_style=False, sort_keys=False)
        
    return bool_file_modified

# COMMAND ----------

# Pull all ready jobs from audit table
df_audit_table = get_audit_table()
df_ready_batches = df_audit_table.filter(
    (col('job_status') == lit('Ready')) | (col('job_status') == lit('Queued'))
)

# Get batch_ids from ready jobs
list_batch_ids = [row['batch_id'] for row in df_ready_batches.select('batch_id').collect()]

# Update jobs from Ready to Queued status
update_audit_entries_to_queued(list_batch_ids)

# Pass batch_ids to the run_batch workflow
dbutils.jobs.taskValues.set(key = "list_batch_ids", value = list_batch_ids)
dbutils.jobs.taskValues.set(key = "SCHEMA_USERNAME_PREFIX", value = C.SCHEMA_USERNAME_PREFIX)
dbutils.jobs.taskValues.set(key = "PATH_TO_PROFILES", value = C.PATH_TO_PROFILES)

# COMMAND ----------

# Get batch_params from ready jobs and parse JSON strings to dictionaries
list_batch_parameters = []
for row in df_ready_batches.select('batch_parameters').collect():
    batch_param_str = row['batch_parameters']
    try:
        # Parse the JSON string into a Python dictionary
        batch_param_dict = json.loads(batch_param_str)
        list_batch_parameters.append(batch_param_dict)
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON: {e}")
        print(f"Problematic string: {batch_param_str}")
        # Skip this row or handle the error as needed

# Log the number of parameters found
print(f"Found {len(list_batch_parameters)} batch parameters to process")