from pytz import timezone
from _exceptions import ConstantLockedError

def setup_constants(dbutils):
    """Setup constants in this function
    
    Any constants that require references to APIs must have API passed in as a variable
    Example: NOTEBOOK_PATH requires dbutils API to be passed in

    Changing any constants requires the state of the notebook to be cleared because Python imports are cached
    """
    C = Constants
    C.unlock()  # Always unlock before setting values
    # Update to pull from key-vault
    C.ENVIRONMENT = 'dev'
    C.CATALOG = 'aw_dev'

    # Get the current notebook path
    C.NOTEBOOK_PATH = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()

    # Check if the notebook is in a user folder
    if "/Users/" in C.NOTEBOOK_PATH:
        C.CURRENT_USER_EMAIL = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
        C.CURRENT_USERNAME = C.CURRENT_USER_EMAIL.split('@')[0]
        C.CURRENT_USERNAME = (''.join(c if c.isalnum() else '_' for c in C.CURRENT_USERNAME))
        C.SCHEMA_USERNAME_PREFIX = f"{C.ENVIRONMENT}_{C.CURRENT_USERNAME}_"
        C.AUDIT_TABLE_NAME = f"{C.CURRENT_USERNAME}_audit_table"
        C.PATH_TO_CONFIGS = f'/Workspace/Users/{C.CURRENT_USER_EMAIL}/MDP/.bundle/mdp_bundle/dev/files/src/configs/'
        C.PATH_TO_PROFILES = f'{C.PATH_TO_CONFIGS}dbt_profiles'
        C.PATH_TO_NOTEBOOK_TESTS = f'/Workspace/Users/{C.CURRENT_USER_EMAIL}/MDP/.bundle/mdp_bundle/dev/files/src/testing/unit_tests/'
        C.DBT_DIR = f"/Workspace/Users/{C.CURRENT_USER_EMAIL}/MDP/.bundle/mdp_bundle/dev/files/src/"
        C.DBT_MODELS_DIR = f"/Workspace/Users/{C.CURRENT_USER_EMAIL}/MDP/.bundle/mdp_bundle/dev/files/src/models/"
        C.DBT_SOURCES_YML_PATH = f"/Workspace/Users/{C.CURRENT_USER_EMAIL}/MDP/.bundle/mdp_bundle/dev/files/src/models/staging/sources.yml"
        C.LANDING_SCHEMA_NAME = f'{C.CATALOG}.{C.SCHEMA_USERNAME_PREFIX}landing'
        C.SHORT_LANDING_SCHEMA_NAME = f'{C.SCHEMA_USERNAME_PREFIX}landing'
        C.STAGING_SCHEMA_NAME = f'{C.CATALOG}.{C.SCHEMA_USERNAME_PREFIX}staging'
        C.LANDING_VOLUME_NAME = f'/Volumes/{C.CATALOG}/{C.SHORT_LANDING_SCHEMA_NAME}/'
        C.BRONZE_SCHEMA_NAME = f'{C.CATALOG}.{C.SCHEMA_USERNAME_PREFIX}bronze'
        C.VW_SCHEMA_NAME = f'{C.CATALOG}.{C.SCHEMA_USERNAME_PREFIX}vw'
        C.VALIDATED_SCHEMA_NAME = f'{C.CATALOG}.{C.SCHEMA_USERNAME_PREFIX}validated'
        C.PATH_TO_LOGS = f'/Workspace/Users/{C.CURRENT_USER_EMAIL}/MDP/.bundle/mdp_bundle/dev/files/logs'

        if C.ENVIRONMENT == 'dev':
            C.DEPLOY_TARGET = 'user_dev'

    else:
        C.SCHEMA_USERNAME_PREFIX = ""
        C.PATH_TO_CONFIGS = f'/Workspace/Shared/MDP/.bundle/mdp_bundle/dev/files/src/configs/'
        C.PATH_TO_NOTEBOOK_TESTS = f'/Workspace/Shared/MDP/.bundle/mdp_bundle/dev/files/src/testing/unit_tests/'
        C.AUDIT_TABLE_NAME = f"audit_table"
        C.DBT_DIR = f"/Workspace/Shared/MDP/.bundle/mdp_bundle/dev/files/src/"
        C.DBT_MODELS_DIR = f"/Workspace/Shared/MDP/.bundle/mdp_bundle/dev/files/src/models/"
        C.PATH_TO_PROFILES = f'/Workspace/Shared/MDP/.bundle/mdp_bundle/dev/files/dbt_profiles'
        C.DBT_SOURCES_YML_PATH = f"/Workspace/Shared/MDP/.bundle/mdp_bundle/dev/files/src/models/staging/sources.yml"
        C.STAGING_SCHEMA_NAME = f'{C.CATALOG}.staging'
        C.LANDING_SCHEMA_NAME = f'{C.CATALOG}.landing'
        C.LANDING_VOLUME_NAME = f'/Volumes/{C.CATALOG}/landing/'
        C.VW_SCHEMA_NAME = f'{C.CATALOG}.vw'
        C.BRONZE_SCHEMA_NAME = f'{C.CATALOG}.bronze'
        C.DEPLOY_TARGET = 'staging_dev'
        C.VALIDATED_SCHEMA_NAME = 'validated'
        C.PATH_TO_LOGS = f'/Workspace/Shared/MDP/.bundle/mdp_bundle/dev/files/logs'
        
        if C.ENVIRONMENT == 'dev':
            C.DEPLOY_TARGET = 'staging_dev'

    C.INBOUND_SCHEMA_NAME = 'inbound'

    C.PATH_TO_AUDIT_TABLE = f"{C.CATALOG}.default.{C.AUDIT_TABLE_NAME}"

    C.SECRET_SCOPE = ''
    if C.ENVIRONMENT == 'dev': 
        C.SECRET_SCOPE = 'kv-mdp-aw-w-dev-2'

    C.STR_TIMEZONE = "US/Pacific"
    C.TZ_TIMEZONE = timezone(C.STR_TIMEZONE)

    # Manually define the region name → numeric mapping (based on known values)
    C.REGION_MAPPING = {
        "westus": "11",
        "eastus2": "12",
        "centralus": "13",
        "northcentralus": "14",
        "southcentralus": "15",
        "westus2": "16",
        "westus3": "17",
        "eastus": "18",
        "northeurope": "19",
        "westeurope": "20",
        "southeastasia": "21",
        # Add more mappings if necessary
    }

    # Lock after setup
    C.lock()

class _ConstMeta(type):
    _locked = False
    def __setattr__(cls, key, value):
        if key == "_locked":
            super().__setattr__(key, value)
        elif cls._locked:
            raise ConstantLockedError(f"Constants are read-only. Cannot change {cls.__name__}.{key} to {repr(value)}")
        super().__setattr__(key, value)

    def lock(cls):
        cls._locked = True

    def unlock(cls):
        cls._locked = False

class Constants(metaclass=_ConstMeta):
    pass

