# Purpose: Maintain shared functions to be referenced by other notebooks

from _constants import Constants as C
from _globals import Globals as G
from pyspark.sql.utils import AnalysisException
import requests
import json
import yaml
from datetime import datetime, timedelta
import os
import ast
from pprint import pprint
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, max, to_timestamp, desc, lit, when, expr, current_timestamp, explode, min as min_sql, max as max_sql,monotonically_increasing_id, sha2, concat_ws, trim
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType, IntegerType, BooleanType, ArrayType, MapType
from pyspark.sql import Row, SparkSession
from urllib.parse import urlparse
import unittest
import time
from pyspark.sql.utils import AnalysisException
from delta.tables import DeltaTable
from pytz import timezone
import calendar
import pandas as pd
from io import StringIO
from pytz import timezone
import fnmatch
import shutil
import traceback
import re
from typing import Tuple, Optional
from unittest.mock import MagicMock, patch, mock_open
import subprocess
from concurrent.futures import ThreadPoolExecutor
import hashlib
try:
    # Try to import before installing - this decreases install time when rerunning notebooks
    from simple_salesforce import Salesforce
except:
    # Install all packages on one line - this makes install faster
    import subprocess; subprocess.check_call(['pip', 'install', 'simple_salesforce'])
    dbutils.library.restartPython()
from simple_salesforce import Salesforce

def get_source_systems_list_from_config(str_path='', str_env=''):
    """
    Retrieves a list of source systems configurations from a YAML file for a specified environment.
    
    Parameters:
        str_path (str): Path to directory containing 'source_systems.yml'. 
                       Defaults to global 'C.PATH_TO_CONFIGS' if not provided.
        str_env (str): Environment key to extract (e.g., 'dev', 'qa', 'prod').
                      Defaults to global 'C.ENVIRONMENT' if not provided.
    
    Returns:
        list: List of dictionaries containing source system configurations for the environment.
              Returns empty list if file not found or key missing.
              
    Raises:
        FileNotFoundError: If YAML file cannot be found
        KeyError: If expected key is missing in configuration
    """
    # Populate from globals if not provided
    if not str_path:
        str_path = C.PATH_TO_CONFIGS
    if not str_env:
        str_env = C.ENVIRONMENT
    
    try:
        with open(str_path + 'source_systems.yml', 'r') as file:
            dict_source_systems = yaml.safe_load(file)
        return dict_source_systems.get(str_env, [])
    
    except FileNotFoundError:
        print(f"File not found: {str_path + 'source_systems.yml'}")
        return []
    except KeyError as e:
        print(f"Missing expected key in configuration: {e}")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []
    
def get_token(str_system, dict_auth_params):
    """
    Retrieves an authentication token for a specified system using provided parameters.
    
    Parameters:
        str_system (str): Name of system (e.g., 'salesforce')
        dict_auth_params (dict): Authentication parameters including 'instance_url'
    
    Returns:
        dict: Token payload if successful, or error message if not
        
    Raises:
        requests.exceptions.HTTPError: For HTTP errors
        requests.exceptions.RequestException: For request errors
        KeyError: If expected key is missing in parameters
        json.JSONDecodeError: If JSON response cannot be decoded
    """
    try:
        match str_system:
            case "salesforce":
                dict_auth_creds = {
                    "grant_type": "client_credentials",
                    "client_id": G.dbutils.secrets.get(scope=C.SECRET_SCOPE, key=dict_auth_params["client_id"]),
                    "client_secret": G.dbutils.secrets.get(scope=C.SECRET_SCOPE, key=dict_auth_params["client_secret"])
                }

                str_auth_url = dict_auth_params["instance_url"] + "/services/oauth2/token"
                response = requests.post(str_auth_url, params=dict_auth_creds, headers={})
                response.raise_for_status()
                dict_token_payload = json.loads(response.text)
                return dict_token_payload
            case _:
                print(f"Unsupported system: {str_system}")
                return {"error": "Unsupported system"}

    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except requests.exceptions.RequestException as req_err:
        print(f"Request error occurred: {req_err}")
    except KeyError as e:
        print(f"Missing expected key in authentication parameters: {e}")
    except json.JSONDecodeError as json_err:
        print(f"Error decoding JSON response: {json_err}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    return {"error": "Failed to retrieve token"}

def get_workspace_url():
    try:
        # Get API URL (contains the region name)
        api_url = G.dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().get()

        # Extract region name dynamically
        parsed_url = urlparse(api_url)
        region_name = parsed_url.netloc.split(".")[0]  # Extracts "westus", "eastus2", etc.

        # Get the numeric region ID from the mapping
        region_number = C.REGION_MAPPING.get(region_name, "unknown")
        if region_number == "unknown":
            raise ValueError(f"Region '{region_name}' not found in C.REGION_MAPPING. Update mapping.")

        # Get instance ID (orgId)
        org_id = G.dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("orgId").get()

        # Construct valid workspace URL
        return f"https://adb-{org_id}.{region_number}.azuredatabricks.net"
    
    except Exception as e:
        print(f"Error retrieving workspace URL: {e}")
        return None  # Return None if something goes wrong
    
def normalize_volume_path(path: str) -> str:
    """
    Normalize a Databricks volume path to use forward slashes and proper '/Volumes' capitalization.

    Args:
        path (str): The original file path.

    Returns:
        str: The normalized path.
    
    Raises:
        ValueError: If the path is empty or not a string.
    """
    if not isinstance(path, str) or not path.strip():
        raise ValueError("Input path must be a non-empty string.")
    path = path.replace('\\', '/')
    if path.lower().startswith('/volumes'):
        path = '/Volumes' + path[8:]
    return path

def parse_volume_path(path: str):
    """
    Parse a normalized volume path and extract catalog, schema, and volume names.
    Validates that catalog, schema, and volume names are comprised of valid characters.

    Args:
        path (str): The normalized file path.

    Returns:
        Tuple[Optional[str], Optional[str], Optional[str]]: catalog, schema, volume if valid, else (None, None, None).
    """
    if not path.startswith('/Volumes/'):
        return None, None, None

    # Split the path into components
    parts = path.split('/')
    if len(parts) >= 5:  # Ensure we have enough parts: /Volumes/catalog/schema/volume
        catalog = parts[2]
        schema = parts[3]
        volume = parts[4]  # Optional volume

        pattern = r'^[a-zA-Z_][a-zA-Z0-9_-]*$'
        # Validate each part using is_valid_name
        if all(bool(re.match(pattern, part)) for part in [catalog, schema, volume] if part is not None):
            return catalog, schema, volume

    return None, None, None

def volume_exists(catalog: str, schema: str, volume: str) -> bool:
    """
    Check if a specific volume exists in the given catalog and schema.

    Args:
        catalog (str): The catalog name.
        schema (str): The schema name.
        volume (str): The volume name.

    Returns:
        bool: True if the volume exists, False otherwise.

    Raises:
        ValueError: If any argument is missing.
    """
    if not all([catalog, schema, volume]):
        raise ValueError("Catalog, schema, and volume must all be provided.")
    query = f"SHOW VOLUMES IN {catalog}.{schema}"
    try:
        df = G.spark.sql(query)
        volumes = [row['volume_name'] for row in df.collect()]
        return volume in volumes
    except Exception as e:
        if 'SCHEMA_NOT_FOUND' in str(e):
            return False
        if 'NO_SUCH_CATALOG_EXCEPTION' in str(e):
            return False
        else:
            raise RuntimeError(f"[volume_exists] Error executing query: {e}") from e

def create_volume(catalog: str, schema: str, volume: str) -> None:
    """
    Create a volume in the specified catalog and schema, if it does not already exist.

    Args:
        catalog (str): The catalog name.
        schema (str): The schema name.
        volume (str): The volume name.

    Raises:
        ValueError: If any argument is missing.
        Exception: If the SQL command fails.
    """
    if not all([catalog, schema, volume]):
        raise ValueError("Catalog, schema, and volume must all be provided.")
    query = f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.{volume}"
    try:
        G.spark.sql(query)
        print(f"[create_volume] Created volume: {catalog}.{schema}.{volume}")
    except Exception as e:
        raise RuntimeError(f"Failed to create volume {catalog}.{schema}.{volume}: {e}") from e

def ensure_volume_and_directory(destination_path: str) -> None:
    """
    Normalize the destination path, ensure the volume exists (creating it if necessary),
    and create the target directory.

    Args:
        destination_path (str): The original user-provided path.

    Raises:
        ValueError: If the path is invalid or volume parsing fails.
        Exception: If directory creation fails.
    """
    if not isinstance(destination_path, str) or not destination_path.strip():
        raise ValueError("Destination path must be a non-empty string.")
    norm_path = normalize_volume_path(destination_path)
    print(f"[ensure_volume_and_directory] Normalized path: {norm_path}")
    if norm_path.startswith('/Volumes/'):
        catalog, schema, volume = parse_volume_path(norm_path)
        if not all([catalog, schema, volume]):
            raise ValueError(f"Path '{norm_path}' is not a valid Databricks volume path.")
        try:
            if not volume_exists(catalog, schema, volume):
                print(f"[ensure_volume_and_directory] Volume '{catalog}.{schema}.{volume}' does not exist. Creating...")
                create_volume(catalog, schema, volume)
            else:
                print(f"[ensure_volume_and_directory] Volume '{catalog}.{schema}.{volume}' already exists.")
        except Exception as e:
            raise RuntimeError("Error ensuring volume existence.") from e
    dir_path = os.path.dirname(norm_path)
    try:
        os.makedirs(dir_path, exist_ok=True)
        print(f"[ensure_volume_and_directory] Directory ensured: {dir_path}")
    except Exception as e:
        raise RuntimeError(f"Failed to create directory '{dir_path}': {e}") from e

def create_audit_table():
    """
    Creates the 'audit_table' with a predefined schema in Delta format.
    
    The table includes columns for tracking batch processing metadata including:
    - Batch IDs and job status
    - Source system and target table information
    - Timing metrics
    - Record and column counts at each stage
    - Schema information
    
    Raises:
        Exception: If table creation fails
    """
    try:
        str_create_table_sql = f"""
        CREATE TABLE {C.PATH_TO_AUDIT_TABLE} (
            batch_id BIGINT GENERATED BY DEFAULT AS IDENTITY(START WITH 1 INCREMENT BY 1),
            job_id STRING,
            source_system_name STRING,
            target_table_name STRING,
            job_status STRING,
            acquisition_ready_datetime TIMESTAMP,
            job_start_time TIMESTAMP,
            job_end_time TIMESTAMP,
            job_duration STRING,
            flat_file_source_paths ARRAY<STRING>,
            landing_file_paths ARRAY<STRING>,
            data_schema ARRAY<MAP<STRING, STRING>>,
            task_step STRING,
            transaction_date_min TIMESTAMP,
            transaction_date_max TIMESTAMP,
            landing_record_count ARRAY<MAP<STRING, INT>>,
            staging_record_count BIGINT,
            silver_record_count BIGINT,
            landing_column_count ARRAY<MAP<STRING, INT>>,
            staging_column_count INT,
            silver_column_count INT,
            schema_difference ARRAY<MAP<STRING, BOOLEAN>>,
            validation_record_count STRING,
            changed_record_count STRING,
            attempt_number INT,
            workflow_job_run_url STRING,
            modified_timestamp TIMESTAMP NOT NULL,
            incremental_load_type STRING,
            batch_parameters STRING,
            source_checksum STRING, -- Checksum (hash) of the file or data in the source location
            landing_checksum STRING, -- Checksum of the file or data after being copied
            source_schema STRING, -- Schema of the source data
            landing_schema STRING, -- Schema of the landing data
            staging_schema STRING, -- Schema of the staging data
            validated_schema STRING, -- Schema of the validated data
            source_to_landing_schema_diff STRING, -- Differences between source and landing schemas
            landing_to_staging_schema_diff STRING, -- Differences between landing and staging schemas
            staging_to_validated_schema_diff STRING, -- Differences between staging and validated schemas
            source_unique_record_count BIGINT, -- Unique record count in the source
            landing_unique_record_count BIGINT, -- Unique record count in the landing
            validated_unique_record_count BIGINT, -- Unique record count in the validated data
            source_landing_consistency_validation_result STRING, -- Result of consistency validation
            consistency_status STRING, -- Overall status of consistency validation
            failed_validation_name STRING, -- Name of the failed validation step
            failed_validation_reason STRING, -- Reason for the failed validation
            validation_timestamp TIMESTAMP -- Timestamp of the validation

        )
        USING DELTA
        """
        
        G.spark.sql(str_create_table_sql)
        print(f"Table {C.PATH_TO_AUDIT_TABLE} created successfully.")
    
    except Exception as e:
        print(f"An error occurred while creating the table: {e}")
        raise

def drop_audit_table(str_audit_table=''):
    """
    Drops the audit table specified by the table name.

    Parameters:
    str_audit_table (str): The name of the audit table to drop.

    Returns:
    None
    """
    try:
        # Use the default path if none is provided
        if str_audit_table == '':
            str_audit_table = C.PATH_TO_AUDIT_TABLE
        # Execute the SQL command to drop the table
        G.spark.sql(f"DROP TABLE IF EXISTS {str_audit_table}")
        print(f"Audit table '{str_audit_table}' has been dropped (if it existed).")
    except Exception as e:
        # Handle any errors that occur during the process
        print(f"An error occurred while dropping the table '{str_audit_table}': {e}")

def insert_audit_entry(dict_batch_parameters, str_acquisition_ready_datetime):
    """
    Inserts an audit entry into the 'audit_table' table.
    
    Parameters:
        dict_batch_parameters (dict): Batch processing parameters including:
            - source_system_name
            - target_table_name
        str_acquisition_ready_datetime (str): Datetime when acquisition is ready (format: "%Y-%m-%d %H:%M:%S")
    
    Returns:
        None
        
    Raises:
        Exception: If insertion fails
    """
    try:
        dt_acquisition_ready_datetime = datetime.strptime(str_acquisition_ready_datetime, "%Y-%m-%d %H:%M:%S")
        dt_acquisition_ready_datetime = C.TZ_TIMEZONE.localize(dt_acquisition_ready_datetime)

        str_job_status = 'Ready' if str_acquisition_ready_datetime is None or dt_acquisition_ready_datetime < datetime.now(C.TZ_TIMEZONE) else 'Scheduled'

        schema = StructType([
            StructField("job_id", StringType(), True),
            StructField("source_system_name", StringType(), True),
            StructField("target_table_name", StringType(), True),
            StructField("job_status", StringType(), True),
            StructField("acquisition_ready_datetime", TimestampType(), True),
            StructField("job_start_time", TimestampType(), True),
            StructField("job_end_time", TimestampType(), True),
            StructField("job_duration", StringType(), True),
            StructField("flat_file_source_paths", ArrayType(StringType()), True),
            StructField("landing_file_paths", ArrayType(StringType()), True),
            StructField("data_schema", ArrayType(MapType(StringType(), StringType())), True),
            StructField("task_step", StringType(), True),
            StructField("transaction_date_min", TimestampType(), True),
            StructField("transaction_date_max", TimestampType(), True),
            StructField("landing_record_count", ArrayType(MapType(StringType(), IntegerType())), True),
            StructField("staging_record_count", LongType(), True),
            StructField("silver_record_count", LongType(), True),
            StructField("landing_column_count", ArrayType(MapType(StringType(), IntegerType())), True),
            StructField("staging_column_count", IntegerType(), True),
            StructField("silver_column_count", IntegerType(), True),
            StructField("schema_difference", ArrayType(MapType(StringType(), BooleanType())), True),
            StructField("validation_record_count", StringType(), True),
            StructField("changed_record_count", StringType(), True),
            StructField("attempt_number", IntegerType(), True),
            StructField("workflow_job_run_url", StringType(), True),
            StructField("modified_timestamp", TimestampType(), False),
            StructField("incremental_load_type", StringType(), True),
            StructField("batch_parameters", StringType(), True)
        ])
        
        list_data = [Row(
            job_id                      = None,
            source_system_name          = str(dict_batch_parameters['source_system_name']),
            target_table_name           = str(dict_batch_parameters['target_table_name']),
            job_status                  = str_job_status,
            acquisition_ready_datetime  = dt_acquisition_ready_datetime,
            job_start_time              = None,
            job_end_time                = None,
            job_duration                = None,
            flat_file_source_paths      = None,
            landing_file_paths          = None,
            data_schema                 = None,
            task_step                   = str_job_status,
            transaction_date_min        = None,
            transaction_date_max        = None,
            landing_record_count        = None,
            staging_record_count        = None,
            silver_record_count         = None,
            landing_column_count        = None,
            staging_column_count        = None,
            silver_column_count         = None,
            schema_difference           = None,
            validation_record_count     = None,
            changed_record_count        = None,
            attempt_number              = None,
            workflow_job_run_url        = None,
            modified_timestamp          = datetime.now(),
            incremental_load_type       = None,
            batch_parameters            = json.dumps(dict_batch_parameters)
            )]

        df_audit = G.spark.createDataFrame(list_data, schema=schema)
        df_audit.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(C.PATH_TO_AUDIT_TABLE)
        print(f"Successfully added audit entry for table {dict_batch_parameters['target_table_name']}.")
    
    except Exception as e:
        print(f"An unexpected error occurred during the audit entry process: {e}")
        raise

def remove_audit_entry(batch_id, str_path=''):
    """
    Removes an audit entry for a specified batch ID from the audit table.

    Parameters:
        batch_id (int): The ID of the batch to remove.
        str_path (str): The path to the audit table. If not provided, a default path is used.

    Raises:
        ValueError: If there is an error accessing the audit table or removing the entry.
    """
    try:
        # Use the default path if none is provided
        if str_path == '':
            str_path = C.PATH_TO_AUDIT_TABLE

        # Load the audit table
        df_audit_table = get_audit_table()

        # Filter out the entry with the specified batch_id
        df_filtered = df_audit_table.filter(df_audit_table.batch_id != batch_id)

        # Overwrite the table with the filtered DataFrame
        df_filtered.write.format("delta").mode("overwrite").saveAsTable(str_path)

        print(f"Successfully removed audit entry for batch_id {batch_id}.")

    except Exception as e:
        raise ValueError(f"Failed to remove audit entry for batch_id {batch_id}: {e}")

def read_csv(str_file_path, dict_ingest_parameters = {}):
    """
    Reads a CSV file into a Spark DataFrame.

    Parameters:
    str_file_path (str): The path to the CSV file.
    str_delimiter (str): The delimiter used in the CSV file.
    bool_header (bool): Whether the first row of the CSV file contains headers.

    Returns:
    DataFrame: A spark DataFrame containing the data from the CSV file.

    Raises:
    Exception: If there is an error reading the CSV file.
    """
    try:
        str_delimiter = dict_ingest_parameters.get('delimiter', '')
        bool_header = dict_ingest_parameters.get('has_header', '')

        # Default values if empty
        if str_delimiter == '':
            str_delimiter = '|'
        if bool_header == '':
            bool_header = True

        # Read the CSV file into a DataFrame
        df = G.spark.read.csv(str_file_path, header=bool_header, inferSchema=True, sep=str_delimiter, quote='"', escape='"', multiLine=True)
        return df
    except Exception as e:
        # Handle any exceptions that occur during reading
        print(f"An error occurred while reading the CSV file: {e}")
        return None
    
def read_txt(str_file_path, dict_ingest_parameters = {}, dict_file_acquisition_parameters = {}):
    """
    Reads a fixed-width TXT file into a Spark DataFrame based on provided configurations.

    Parameters:
    str_file_path (str): The path to the TXT file.
    dict_ingest_parameters (dict): Dictionary containing ingestion parameters such as:
        - fixed_width_field_table_name (str): The name of the table containing field configurations.
        - fixed_width_field_configs_file (str): The file containing field configurations.
        - date_field_from_file_name (bool): Whether to extract a date field from the file name.
    dict_file_acquisition_parameters (dict): Dictionary containing file acquisition parameters such as:
        - file_mask (str): The mask pattern used to identify the date or substring in the file name.

    Returns:
    DataFrame: A Spark DataFrame containing the data from the TXT file.

    Raises:
    Exception: If there is an error reading the TXT file.
    """
    try:
        str_fixed_width_fields_table_name = dict_ingest_parameters.get('fixed_width_field_table_name', '')
        str_fixed_width_field_configs_file = dict_ingest_parameters.get('fixed_width_field_configs_file', '')
        bool_date_field_from_file_name = dict_ingest_parameters.get('date_field_from_file_name', False)
        str_file_mask = dict_file_acquisition_parameters.get('file_mask', '')

        with open(C.PATH_TO_CONFIGS + str_fixed_width_field_configs_file, 'r') as file:
            dict_fixed_width_fields_configs = yaml.safe_load(file)
        dict_fixed_width_fields = dict_fixed_width_fields_configs[str_fixed_width_fields_table_name]

        initial_df = G.spark.read.text(str_file_path)

        parsed_df_fields = ''
        for field, data in dict_fixed_width_fields.items():
            parsed_df_fields += f"trim(initial_df.value.substr({data['start_index']},{data['size']})).alias('{field}'),"

        parsed_df_code = f'initial_df.select({parsed_df_fields})'

        if bool_date_field_from_file_name:
            str_date_value = extract_date_from_file_name(str_file_path, str_file_mask)
            parsed_df_code += f'.withColumn("extract_date", lit({str_date_value}))'
            
        print(parsed_df_code)
        
        df = eval(parsed_df_code)
        return df
    except Exception as e:
        # Handle any exceptions that occur during reading
        print(f"An error occurred while reading the TXT file: {e}")
        return None
    
def extract_date_from_file_name(landing_file_path, acquisition_file_mask):
    """
    Extracts a date or specific substring from a file name based on a given file mask.

    Parameters:
    landing_file_path (str): The path of the file from which to extract the date or substring.
    acquisition_file_mask (str): The mask pattern used to identify the date or substring in the file name. 
                                 The mask should use '*' as a wildcard for the date or substring.

    Returns:
    str: The extracted date or substring if the pattern matches, otherwise None.
    """
    
    landing_file_mask = os.path.splitext(acquisition_file_mask)[0] + "_batch_*" + os.path.splitext(acquisition_file_mask)[1]
    landing_file_name = landing_file_path.split(os.path.sep)[-1]

    # Escape special characters in the file mask except the '*'
    regex_pattern = re.escape(landing_file_mask).replace(r'\*', '(.*?)')
    
    # Match the actual file name against the pattern
    match = re.match(regex_pattern, landing_file_name)
    
    if match:
        # Return the first captured group that corresponds to the first wildcard position
        return match.group(1)
    else:
        # Return None if the pattern does not match
        return None
    
def get_dataframe_info(df_data):
    """
    Extract schema, record count, and column count from a PySpark DataFrame.
    
    Parameters:
        df_data (DataFrame): PySpark DataFrame to analyze
        
    Returns:
        dict: Dictionary containing:
            - str_schema: Simple schema string
            - str_readable_schema: Human-readable schema
            - int_record_count: Number of records
            - int_column_count: Number of columns
    """
    # Get schema as a string
    str_schema = df_data.schema.simpleString()
    
    # Get more readable schema format
    list_readable_schema = []
    for field in df_data.schema.fields:
        list_readable_schema.append(f"{field.name}: {field.dataType}")
    str_readable_schema = ", ".join(list_readable_schema)
    
    # Get record count
    int_record_count = df_data.count()
    
    # Get column count
    int_column_count = len(df_data.columns)
    
    return {
        "str_schema": str_schema,
        "str_readable_schema": str_readable_schema,
        "int_record_count": int_record_count,
        "int_column_count": int_column_count
    }

def get_audit_row_with_max_timestamp(str_table_name, str_path=''):
    """
    Retrieves the row with the maximum timestamp for a specified table name from the audit table.

    Parameters:
    str_table_name (str): The name of the table to filter by.
    str_path (str): The path to the audit table. If not provided, defaults to a global variable from constants file.

    Returns:
    Row: The row with the maximum timestamp for the specified table name, or None if an error occurs.

    Raises:
    Exception: If there is an error accessing the table or retrieving the data.
    """
    try:
        # Use the default path if none is provided
        if str_path == '':
            str_path = C.PATH_TO_AUDIT_TABLE

        # Load the audit table into a DataFrame
        df_audit_table = G.spark.table(str_path)

        # Filter and order to get the row with the maximum timestamp
        # TODO update complete to what finals state will be
        row_with_max_timestamp = df_audit_table.filter((col("target_table_name") == str_table_name) & 
                                                    (col("job_status") == "Complete")) \
                                            .orderBy(desc("modified_timestamp")) \
                                            .first()

        return row_with_max_timestamp
    except Exception as e:
        # Handle any exceptions that occur during processing
        print(f"An error occurred while retrieving the row with the max timestamp: {e}")
        return None
    
def get_audit_row_by_batch_id(batch_id, str_path=''):
    """
    Retrieves the row with the maximum timestamp for a specified table name from the audit table.

    Parameters:
    batch_id (int): The ID of the batch to filter by.
    str_path (str): The path to the audit table. If not provided, defaults to a global variable from constants file.

    Returns:
    Row: The row with the maximum timestamp for the specified table name, or None if an error occurs.

    Raises:
    Exception: If there is an error accessing the table or retrieving the data.
    """
    try:
        # Use the default path if none is provided
        if str_path == '':
            str_path = C.PATH_TO_AUDIT_TABLE

        # Load the audit table into a DataFrame
        df_audit_table = G.spark.table(str_path)

        # Filter and get row
        row = df_audit_table.filter((col("batch_id") == batch_id)).first()
        return row
    except Exception as e:
        # Handle any exceptions that occur during processing
        print(f"An error occurred while retrieving the row by batch_id: {e}")
        return None
    
def get_audit_table(str_path=''):
    """
    Retrieves a Spark DataFrame from the specified audit table path.
    Parameters:
        str_path (str): The path to the audit table. If not provided, a default path is used.
    Returns:
        DataFrame: A Spark DataFrame representing the audit table.
    Raises:
        ValueError: If the table cannot be found or accessed at the specified path.
    """
    # Use the default path if none is provided
    if str_path == '':
        str_path = C.PATH_TO_AUDIT_TABLE

    try:
        # Attempt to retrieve the table
        return G.spark.table(str_path)
    except Exception as e:
        # Raise a ValueError with a message including the original exception
        raise ValueError(f"Failed to retrieve the audit table from path '{str_path}': {e}")

def get_batch_parameters_by_batch_id(batch_id):
    """
    Retrieves the batch parameters for a specified batch ID from the audit table.
    Parameters:
        batch_id (int): The ID of the batch for which to retrieve parameters.
    Returns:
        str: The batch parameters in JSON format if the batch ID exists, otherwise None.
    Raises:
        ValueError: If there is an error accessing the audit table or retrieving the batch parameters.
    """
    try:
        # Access the audit table
        df_audit_table = G.spark.table(C.PATH_TO_AUDIT_TABLE)
        
        # Filter the DataFrame for the specified batch_id and select batch_parameters
        filtered_row = df_audit_table.filter(df_audit_table.batch_id == batch_id).select('batch_parameters').collect()
        
        # Extract the batch_parameters value if the row exists
        return json.loads(filtered_row[0]['batch_parameters'] if filtered_row else None)
    
    except Exception as e:
        # Raise a ValueError with a message including the original exception
        raise ValueError(f"Failed to retrieve batch parameters for batch_id {batch_id}: {e}")

def filter_file_watch_batches(list_batch_parameters):
    """
    Filter batch parameters for file source type and specific file watch parameter.
    
    Parameters:
    list_batch_parameters (list): List of batch parameter dictionaries
    file_watch (str): Specific file watch value to filter for
    
    Returns:
    list: Filtered list of batch parameters
    """
    # First, filter for file source type
    list_file_source_batches = [
        batch for batch in list_batch_parameters 
        if batch.get('source_system', {}).get('source_system_type') == 'file'
    ]
    
    # Then filter for specific file watch parameter
    list_file_watch_batches = [
        batch for batch in list_file_source_batches
        if batch.get('file_acquisition_parameters', {}).get('schedule_or_file_watch') == 'file_watch'
    ]
    
    return list_file_watch_batches

def get_file_list(acquisition_parameters):
    """
    Get list of (file_hash, file_name) from source folder location for given parameters. Note: Trailing slashes are stripped
    from the file_mask and from the files and folders at the file_pickup_folder_path, so files and directories are indistinguishable
    
    Parameters:
      acquisition_parameters: JSON -- dict of parameters for the batch
    
    Returns:
      list_file_paths: list of file_paths for all files found in a given target folder
      list_filenames: list of filenames for all files found in a given target folder
    """
    
    # create list to hold found files
    list_file_paths = []
    # create list to hold found filenames
    list_filenames = []

    # if source is volume
    if acquisition_parameters["source_type"] == "volume":
        # DBFS mount path
        file_path = f"""{acquisition_parameters["file_pickup_folder_path"]}"""
        db_source_files = G.dbutils.fs.ls(file_path)
        print("file path: ", file_path)
        print("db_source_files: ", db_source_files)
        print("file mask: ", acquisition_parameters["file_mask"])

        # pull list and filter by file_mask
        for file in db_source_files:
            # if it matches the file mask
            if fnmatch.fnmatch(file.name, acquisition_parameters["file_mask"]):
                # file name
                list_filenames.append(file.name)
                # get full path with filename
                list_file_paths.append(file.path)

    # else Raise error
    else:
        # raise Exception
        raise Exception("source_type value not valid: " + acquisition_parameters["source_type"])

    # return list of files to check
    return list_file_paths, list_filenames

def remove_finished_batches_from_file_list(list_file_paths):
    """
    Filters a list of file paths by removing paths that correspond to jobs that are active or finished based on the audit table.
 
    Parameters:
        list_file_paths (list of str): A list of file paths to be filtered.
 
    Returns:
        list of str: A list of file paths that do not exist in the audit table as finished or scheduled jobs.
    """
    # Load the audit table as a PySpark DataFrame
    df_audit_table = get_audit_table()

    # Filter the audit table to only include rows where job_status is 'In Progress' or 'Complete'
    filtered_audit_table = df_audit_table.filter(col("job_status").isin("In Progress", "Complete"))

    # Explode the flat_file_source_paths array into individual file paths
    exploded_paths_df = filtered_audit_table.select(explode("flat_file_source_paths").alias("file_path"))

    # Collect the distinct file paths from the audit table into a Python set
    existing_file_paths = set(exploded_paths_df.select("file_path").distinct().toPandas()["file_path"])

    # Filter out the file paths that exist in the audit table
    remaining_file_paths = [path for path in list_file_paths if path not in existing_file_paths]

    return remaining_file_paths

def merge_dicts(dict_table, dict_system):
    """
    Merge two dictionaries. The dict_table will override the values
    of dict_system for any overlapping keys.

    Parameters:
        dict_system (dict): The base dictionary to start with.
        dict_table (dict): The dictionary whose keys/values will override primary_dict.

    Returns:
        dict: A merged dictionary with dict_table values overriding dict_system.
    """
    # Copy the primary dictionary to avoid mutating the original
    dict_merged = dict_system.copy()
    
    # Override with secondary dictionary values
    for key, value in dict_table.items():
        dict_merged[key] = value
    
    return dict_merged

def package_parameters(list_source_tables, list_source_systems, list_schedules, dict_targets=None):
    """
    Merges source table information with corresponding source system data and target information.
 
    Parameters:
    - list_source_tables (list of dict): A list of dictionaries where each dictionary represents a source table.
      Each dictionary must contain a 'source_system' key indicating the name of the source system it belongs to.
    - list_source_systems (list of dict): A list of dictionaries where each dictionary represents a source system.
      Each dictionary must contain a 'source_system' key which is used to match with source tables.
    - dict_targets (dict): A dictionary containing target information to be included in each source table's data.
    - list_schedules (list of dict): A list of dictionaries containing schedule information to be included in each source table's data.
 
    Returns:
    - list of dict: A list of dictionaries where each dictionary represents a source table merged with its
      corresponding source system information and the target information. Each dictionary includes:
        - Original fields from the source table
        - 'source_system': A dictionary containing the source system's data
        - 'targets': The provided dictionary of targets
        - 'schedules': A filtered list of dicts of relevant schedules
    """
    if dict_targets is None:
        dict_targets = {
            'landing_volume': C.LANDING_VOLUME_NAME,
            'staging_schema': C.STAGING_SCHEMA_NAME,
            'bronze_schema': C.BRONZE_SCHEMA_NAME
        }
    
    # Create a lookup dictionary for source systems by their name
    dict_source_system = {system['source_system_name']: system for system in list_source_systems}
 
    # List to collect all parameter sets
    list_parameters = []
 
    # Process each source table
    for table in list_source_tables:
        # Get the source system using the source_system field in the table
        source_system_name = table['source_system_name']
        source_system_info = dict_source_system.get(source_system_name, {})
       
        # Collect schedule names from both sources
        table_schedule_names = table.get('schedule_names', []) or []
        system_schedule_names = source_system_info.get('schedule_names', []) or []
       
        # Combine schedule names without duplicates using a set
        schedule_names = set(table_schedule_names + system_schedule_names)
       
        # Filter the schedules based on the combined schedule names
        schedules = [schedule for schedule in list_schedules if schedule['schedule_name'] in schedule_names]
 
        # Merge file acquisition parameters
        dict_merged_file_acquisition_parameters = merge_dicts(
            dict_table = table.get('file_acquisition_parameters', {}),
            dict_system = source_system_info.get('file_acquisition_parameters', {})
        )

        # Merge file ingest parameters
        dict_merged_ingest_parameters = merge_dicts(
            dict_table = table.get('ingest_parameters', {}),
            dict_system = source_system_info.get('ingest_parameters', {})
        )

        # Merge salesforce acquisition parameters
        dict_merged_salesforce_acquisition_parameters = merge_dicts(
            dict_table = table.get('salesforce_acquisition_parameters', {}),
            dict_system = source_system_info.get('salesforce_acquisition_parameters', {})
        )

        # Remove the merged parameters from table dict
        # (copy the table because dict is mutable)
        table_copy = table.copy()
        if 'file_acquisition_parameters' in table_copy:
            del table_copy['file_acquisition_parameters']
        if 'ingest_parameters' in table_copy:
            del table_copy['ingest_parameters']
        if 'salesforce_acquisition_parameters' in table_copy:
            del table_copy['salesforce_acquisition_parameters']

        # Remove the merged parameters from source system dict
        # (copy the info because dict is mutable)
        source_system_info_copy = source_system_info.copy()
        if 'file_acquisition_parameters' in source_system_info_copy:
            del source_system_info_copy['file_acquisition_parameters']
        if 'ingest_parameters' in source_system_info_copy:
            del source_system_info_copy['ingest_parameters']
        if 'salesforce_acquisition_parameters' in source_system_info_copy:
            del source_system_info_copy['salesforce_acquisition_parameters']
        
        # Handle file-type source systems
        if source_system_info['source_system_type'] == 'file':
            # Create a single parameter set with a list of active file paths
            list_parameters.append({
                **table_copy,
                'source_system': source_system_info_copy,
                'targets': dict_targets,
                'schedules': schedules,
                'file_acquisition_parameters': dict_merged_file_acquisition_parameters,
                'ingest_parameters': dict_merged_ingest_parameters
            })
        elif table['source_system_name'] == 'salesforce':
            # Create a single parameter set with salesforce params
            list_parameters.append({
                **table_copy,
                'source_system': source_system_info_copy,
                'targets': dict_targets,
                'schedules': schedules,
                'salesforce_acquisition_parameters': dict_merged_salesforce_acquisition_parameters,
                'ingest_parameters': dict_merged_ingest_parameters
            })
        else:
            # Non-file source systems
            list_parameters.append({
                **table_copy,
                'source_system': source_system_info_copy,
                'targets': dict_targets,
                'schedules': schedules,
                'ingest_parameters': dict_merged_ingest_parameters
            })
 
    return list_parameters

def update_audit_entries_to_queued(list_batch_ids):
    """
    Updates the job_status column in the audit table to 'Queued' for the specified batch IDs.

    Parameters:
        list_batch_ids (list of str): A list of batch IDs for which the `job_status` 
                                      should be updated to 'Queued'.

    Returns:
        None
    """
    df_audit_table = get_audit_table()
    # Create the update condition
    updated_df = df_audit_table.withColumn(
        "job_status",
        when(col("batch_id").isin(list_batch_ids), lit("Queued"))
        .otherwise(col("job_status"))
    )
    # Write the updates back to the table
    updated_df.write.mode("overwrite").saveAsTable(C.PATH_TO_AUDIT_TABLE)

def update_audit_entry_job_start(batch_id, str_task_step='AcquireTable'):
    """
    Updates the audit entry for a specified batch ID with new job start details.

    Parameters:
        batch_id (int): The ID of the batch to update.
        str_task_step (str): The current step of the task.

    Raises:
        ValueError: If the update fails.
    """
    try:
        context = G.dbutils.notebook.entry_point.getDbutils().notebook().getContext() # Save Databricks context
        notebook_name = context.notebookPath().get().split("/")[-1] # Notebook Name
        job_id = context.jobId().get()  # Job ID
        # TODO Issue 724 https://dev.azure.com/AWFC/Data%20Platform/_workitems/edit/724
        try:
            job_run_id = context.tags().get("jobRunId").get() # Job Run ID
            job_run_id_lineage = context.tags().get("jobRunIdForLineage").get() # Parent Job Run ID
            job_id_lineage = context.tags().get("jobIdForLineage").get() # Parent Job ID
            run_id = context.tags().get("runId").get() # Task Run ID
            org_id = context.tags().get("orgId").get() # Org ID
            id_in_job = context.tags().get("idInJob").get() # Task Run ID for URL
        except Exception as e:
            print(f"Error accessing tags: {e}")
            # Fallback values
            job_run_id = ""
            job_run_id_lineage = ""
            job_id_lineage = ""
            run_id = ""
            org_id = ""
            id_in_job = ""    
 
        # Constructing URLs
        workspace_url = G.spark.conf.get('spark.databricks.workspaceUrl')
        #workspace_url = ''
        job_run_url = f"{workspace_url}/jobs/{job_id_lineage}/runs/{job_run_id_lineage}" if job_id_lineage and job_run_id_lineage else None
        task_run_url = f"{workspace_url}/jobs/{job_id}/runs/{id_in_job}" if job_id and id_in_job else None

        # Create a DataFrame with the new values to merge
        updates_df = G.spark.createDataFrame([{
            'batch_id': batch_id,
            'job_start_time': datetime.now(),
            'job_id': job_id,
            # 'workflow_job_run_url': job_run_url, TODO
            'task_step': str_task_step,
            'job_status': 'In Progress'
        }])

        # Load the Delta table
        delta_table = DeltaTable.forName(G.spark, C.PATH_TO_AUDIT_TABLE)

        # Perform the merge operation
        delta_table.alias("tgt").merge(
            updates_df.alias("src"),
            "tgt.batch_id = src.batch_id"
        ).whenMatchedUpdate(set={
            "job_start_time": expr("src.job_start_time"),
            "job_id": expr("src.job_id"),
            "task_step": expr("src.task_step"),
            "job_status": expr("src.job_status"),
            # "workflow_job_run_url": expr("src.workflow_job_run_url") TODO
        }).execute()

    except Exception as e:
        raise ValueError(f"Failed to update audit entry for batch_id {batch_id}: {e}")

def update_audit_entry_job_task(batch_id, str_task_step):
    """
    Updates the audit entry for a specified batch ID with new job start details.

    Parameters:
        batch_id (int): The ID of the batch to update.
        str_task_step (str): The current step of the task.

    Raises:
        ValueError: If the update fails.
    """
    try:
        # Create a DataFrame with the new values to merge
        updates_df = G.spark.createDataFrame([{
            'batch_id': batch_id,
            'task_step': str_task_step
        }])

        # Load the Delta table
        delta_table = DeltaTable.forName(G.spark, C.PATH_TO_AUDIT_TABLE)

        # Perform the merge operation
        delta_table.alias("tgt").merge(
            updates_df.alias("src"),
            "tgt.batch_id = src.batch_id"
        ).whenMatchedUpdate(set={
            "task_step": expr("src.task_step")
        }).execute()

    except Exception as e:
        raise ValueError(f"Failed to update audit entry for batch_id {batch_id}: {e}")

def update_audit_entry_job_after_acquisition(batch_id, list_landing_paths=None, dict_landing_to_source_paths=None, str_task_step='AcquisitionComplete'):
    """
    Updates the audit entry for a specified batch ID with new job start details.

    Parameters:
        batch_id (int): The ID of the batch to update.
        list_landing_paths (list of str): A list of landing file paths.
        dict_landing_to_source_paths (dict): A dictionary mapping landing file paths to their respective source file paths.
        str_task_step (str): The current step of the task.

    Raises:
        ValueError: If the update fails.
    """
    try:
        # Initialize metadata containers
        list_data_schema = []
        list_record_count = []
        list_column_count = []

        # Extract source paths if dict_landing_to_source_paths is provided
        flat_file_source_paths = None
        if dict_landing_to_source_paths:
            flat_file_source_paths = list(dict_landing_to_source_paths.values())
            list_landing_paths = list(dict_landing_to_source_paths.keys())

        # Process each landing path
        for str_landing_path in list_landing_paths:
            # Read the CSV file into a DataFrame
            df_landing = read_csv(str_landing_path)

            # Extract metadata from the DataFrame
            dict_metadata = get_dataframe_info(df_landing)

            # Extract the filename from the landing path
            str_filename = os.path.basename(str_landing_path)

            # Append metadata as maps to respective lists
            list_data_schema.append({str_landing_path: dict_metadata['str_readable_schema']})
            list_record_count.append({str_landing_path: dict_metadata['int_record_count']})
            list_column_count.append({str_landing_path: dict_metadata['int_column_count']})

        # Define the explicit schema
        schema = StructType([
            StructField("batch_id", IntegerType(), False),
            StructField("flat_file_source_paths", ArrayType(StringType()), True),
            StructField("landing_file_paths", ArrayType(StringType()), True),
            StructField("data_schema", ArrayType(MapType(StringType(), StringType())), True),
            StructField("landing_record_count", ArrayType(MapType(StringType(), IntegerType())), True),
            StructField("landing_column_count", ArrayType(MapType(StringType(), IntegerType())), True),
            StructField("task_step", StringType(), True)
        ])

        # Create a DataFrame with the new values to merge
        updates_df = G.spark.createDataFrame([{
            'batch_id': int(batch_id),
            'flat_file_source_paths': flat_file_source_paths,  # List of source paths or None
            'landing_file_paths': list_landing_paths,  # Array of landing paths
            'data_schema': list_data_schema,  # Array of maps: landing path -> schema
            'landing_record_count': list_record_count,  # Array of maps: landing path -> record count
            'landing_column_count': list_column_count,  # Array of maps: landing path -> column count
            'task_step': str_task_step
        }], schema = schema)

        # Load the Delta table
        delta_table = DeltaTable.forName(G.spark, C.PATH_TO_AUDIT_TABLE)

        # Perform the merge operation
        delta_table.alias("tgt").merge(
            updates_df.alias("src"),
            "tgt.batch_id = src.batch_id"
        ).whenMatchedUpdate(set={
            "flat_file_source_paths": expr("src.flat_file_source_paths"),
            "landing_file_paths": expr("src.landing_file_paths"),
            "data_schema": expr("src.data_schema"),
            "landing_record_count": expr("src.landing_record_count"),
            "landing_column_count": expr("src.landing_column_count"),
            "task_step": expr("src.task_step")
        }).execute()

    except Exception as e:
        raise ValueError(f"Failed to update audit entry for batch_id {batch_id}: {e}")

def read_csv_files(batch_id, list_file_paths, batch_parameters):
    """
    reads multiple CSV files into one and writes the combined file to the specified volume path.

    Args:
        list_file_paths (list): List of file paths to read.
        str_delimiter (str): The delimiter used in the CSV files (e.g., ',' or '|').
        bool_has_header (bool): Whether the CSV files have a header row.
        str_output_path (str): The volume path where the combined CSV file will be written.
        str_batch_id (str): The name to use for the combined CSV file (e.g., "batch_001").
        
    Returns:
        str: Full path of the written combined CSV file.
    """
   
    # Define the header option for reading
    str_header_option = "true" if batch_parameters['ingest_parameters']['has_header'] else "false"

    # Define delimiter
    str_delimiter = batch_parameters['ingest_parameters']['delimiter']

    # Define target file path
    str_target_file_path = f"{batch_parameters['targets']['landing_volume']}/{batch_parameters['source_system_name']}/batch_{batch_id}.csv"

    # Initialize an empty list to store DataFrames
    list_df_dataframes = []
    
    # Read each CSV file into a DataFrame and append to the list
    for str_file_path in list_file_paths:
        df_data = G.spark.read.format("csv") \
                            .option("header", str_header_option) \
                            .option("delimiter", str_delimiter) \
                            .load(str_file_path)
        list_df_dataframes.append(df_data)
    
    # Combine all DataFrames into one
    df_combined = list_df_dataframes[0]
    for df_data in list_df_dataframes[1:]:
        df_combined = df_combined.union(df_data)
    
    # Write the combined DataFrame to the output path
    df_combined.write.format("csv") \
                     .option("header", str_header_option) \
                     .option("delimiter", str_delimiter) \
                     .mode("overwrite") \
                     .save(str_output_file_path)
    
    return str_output_file_path

def get_min_max_timestamp(df, str_system_date_field):
    """
    Get the minimum and maximum values of the system_date_field column in a Spark DataFrame.
    Converts string date fields to timestamps.
 
    Parameters:
        df (dataframe): A Spark DataFrame containing the specified timestamp column.
        str_system_date_field (str): A string representing the name of the timestamp column in the DataFrame.
 
    Returns:
        tuple: A tuple containing the minimum and maximum values of the str_system_date_field column as timestamps,
               or (None, None) if an error occurs or the column does not exist.
    """
    try:
        print(df)
        print(str_system_date_field)
        # Check if the column exists in the DataFrame
        if str_system_date_field in df.columns:
            # First, get the min and max string values
            min_value = df.select(min_sql(str_system_date_field)).collect()[0][0]
            max_value = df.select(max_sql(str_system_date_field)).collect()[0][0]
            
            if min_value is not None and max_value is not None:
                # Create a temporary DataFrame with these values and convert to timestamp
                temp_df = df.sparkSession.createDataFrame([(min_value,), (max_value,)], [str_system_date_field])
                result_df = temp_df.withColumn("timestamp_col", to_timestamp(col(str_system_date_field)))
                
                # Extract the converted timestamps
                min_value_timestamp = result_df.collect()[0]["timestamp_col"]
                max_value_timestamp = result_df.collect()[1]["timestamp_col"]
                
                return min_value_timestamp, max_value_timestamp
            else:
                return None, None
        else:
            # Return (None, None) if the column is missing
            print(f"Column '{str_system_date_field}' does not exist in the DataFrame.")
            return None, None
    except Exception as e:
        # Log the error (optional) and return None for both min and max
        print(f"An error occurred: {e}")
        return None, None
    
def update_audit_entry_job_after_ingestion(batch_id, str_staging_catalog_path=None, str_system_date_field=None, str_task_step='IngestionComplete', str_job_status='Complete'):
    """
    Updates the audit entry for a specified batch ID with new job start details.

    Parameters:
        batch_id (int): The ID of the batch to update.
        ts_min_transaction_datetime (timestamp): Timestamp of min transaction datetime.
        ts_max_transaction_datetime (timestamp): Timestamp of max transaction datetime.
        str_task_step (str): The current step of the task.

    Raises:
        ValueError: If the update fails.
    """
    try:
        # Extract metadata from the DataFrame
        df_staging = G.spark.table(str_staging_catalog_path)
        ts_min, ts_max = get_min_max_timestamp(df_staging, str_system_date_field)
        dict_metadata = get_dataframe_info(df_staging)

        # Define the explicit schema
        schema = StructType([
            StructField("batch_id", IntegerType(), False),
            StructField("transaction_date_min", TimestampType(), True),
            StructField("transaction_date_max", TimestampType(), True),
            StructField("staging_record_count", IntegerType(), True),
            StructField("staging_column_count", IntegerType(), True),
            StructField("task_step", StringType(), True),
            StructField("job_status", StringType(), True)
        ])

        # Create a DataFrame with the new values to merge
        updates_df = G.spark.createDataFrame([{
            'batch_id': int(batch_id),
            'transaction_date_min': ts_min,
            'transaction_date_max': ts_max,
            'staging_record_count': dict_metadata['int_record_count'],
            'staging_column_count': dict_metadata['int_column_count'],
            'task_step': str_task_step,
            'job_status': str_job_status
        }], schema = schema)

        # Load the Delta table
        delta_table = DeltaTable.forName(G.spark, C.PATH_TO_AUDIT_TABLE)

        # Perform the merge operation
        delta_table.alias("tgt").merge(
            updates_df.alias("src"),
            "tgt.batch_id = src.batch_id"
        ).whenMatchedUpdate(set={
            "transaction_date_min": expr("src.transaction_date_min"),
            "transaction_date_max": expr("src.transaction_date_max"),
            "staging_record_count": expr("src.staging_record_count"),
            "staging_column_count": expr("src.staging_column_count"),
            "task_step": expr("src.task_step"),
            "job_status": expr("src.job_status")
        }).execute()

    except Exception as e:
        raise ValueError(f"Failed to update audit entry for batch_id {batch_id}: {e}")

def drop_testing_batches(str_path=''):
    """
    Removes records from the table where source_system_name is 'file_test_system' 
    or where source_system_name is 'salesforce' and target_table_name is 'AccountContactRelation'.

    Parameters:
        str_path (str): The path to the table. If not provided, a default path is used.

    Raises:
        ValueError: If there is an error accessing the table or removing the entries.
    """
    try:
        # Use the default path if none is provided
        if str_path == '':
            str_path = C.PATH_TO_AUDIT_TABLE

        # Load the table
        df_table = get_audit_table()

        # Filter out records where source_system_name is 'file_test_system'
        # or where source_system_name is 'salesforce' and target_table_name is 'AccountContactRelation'
        df_filtered = df_table.filter(
            ~((df_table.source_system_name == 'file_test_system') |
              ((df_table.source_system_name == 'salesforce') & 
               (df_table.target_table_name == 'AccountContactRelation')))
        )

        # Overwrite the table with the filtered DataFrame
        df_filtered.write.format("delta").mode("overwrite").saveAsTable(str_path)

        print("Successfully removed testing batches.")

    except Exception as e:
        # Check if the exception is related to the table not being found
        if "TABLE_OR_VIEW_NOT_FOUND" in str(e):
            print(f"The table '{str_path}' does not exist. No records were removed.")
            return
        # Raise other exceptions as usual
        raise ValueError(f"Failed to remove testing batches: {e}")

def validate_not_serverless_cluster():
    try:
        cluster_info = G.spark.conf.get("spark.databricks.clusterUsageTags.clusterAllTags")
    except AnalysisException as e:
        if "[CONFIG NOT AVAILABLE]" in str(e):
            raise Exception("Cluster must not be serverless") from e

def is_token_valid(token_data):
    """
    Validates if a token is still valid based on its expiration date.

    Parameters:
        token_data (dict): Dictionary containing 'token' and 'expiration_date'.

    Returns:
        bool: True if the token is valid, False otherwise.

    Raises:
        KeyError: If 'expiration_date' is missing in the token data.
        ValueError: If 'expiration_date' is not in a valid format.
    """
    try:
        # Ensure 'expiration_date' exists in the token data
        if "expiration_date" not in token_data:
            raise KeyError("'expiration_date' is missing in the token data.")

        # Parse the expiration date using the provided format and localize it
        expiration_date = datetime.strptime(token_data["expiration_date"], "%Y-%m-%d %H:%M:%S")
        expiration_date = C.TZ_TIMEZONE.localize(expiration_date)

        # Compare with the current time in the same timezone
        current_time = datetime.now(C.TZ_TIMEZONE)
        return current_time < expiration_date

    except KeyError as e:
        print(f"Validation error: {e}")
        return False
    except ValueError as e:
        print(f"Invalid date format for 'expiration_date': {e}")
        return False
    
def get_token_from_api_tokens(str_path='', file_name='api_token.yml', str_env='', str_system_name=''):
    """
    Retrieves the token and expiration date for a specific system from a YAML file.

    Parameters:
        str_path (str): Path to directory containing the YAML file.
                        Defaults to global 'C.PATH_TO_CONFIGS' if not provided.
        file_name (str): Name of the YAML file. Defaults to 'api_token.yml'.
        str_env (str): Environment key to extract (e.g., 'dev', 'qa', 'prod').
                       Defaults to global 'C.ENVIRONMENT' if not provided.
        str_system_name (str): Name of the system to extract the token for (e.g., 'salesforce', 'another_system').

    Returns:
        dict: Dictionary containing 'token' and 'expiration_date' for the specified system.
              Returns empty dictionary if system is not found.

    Raises:
        FileNotFoundError: If YAML file cannot be found.
        KeyError: If the specified system name is missing in the YAML file.
    """
    # Use global defaults if not provided
    if not str_path:
        str_path = C.PATH_TO_CONFIGS
    if not str_env:
        str_env = C.ENVIRONMENT

    try:
        # Load the YAML file
        with open(str_path + file_name, 'r') as file:
            dict_api_tokens = yaml.safe_load(file)
        
        # Check if the environment exists in the YAML file
        if str_env not in dict_api_tokens:
            raise KeyError(f"Environment '{str_env}' not found in {str_path + file_name}.")

        # Retrieve the token data for the specified system within the environment
        env_data = dict_api_tokens[str_env]
        if str_system_name in env_data:
            return env_data[str_system_name]
        else:
            raise KeyError(f"System '{str_system_name}' not found in environment '{str_env}'.")
    
    except FileNotFoundError:
        with open(str_path + file_name, 'w') as file:
            yaml.safe_dump({}, file)
        print(f"File '{str_path + file_name}' not found. Created a new empty file.")
        return {}
    except KeyError as e:
        raise e
    except Exception as e:
        print(f"Error reading {str_path + file_name}: {e}")
        return {}
    
def store_token_in_api_tokens(str_path='', file_name='api_token.yml', str_env='', str_system_name='', token_data={}, token_lifetime_seconds=3600):
    """
    Stores or updates the token and expiration date for a specific system in a YAML file.

    Parameters:
        str_path (str): Path to directory containing the YAML file.
                        Defaults to global 'C.PATH_TO_CONFIGS' if not provided.
        file_name (str): Name of the YAML file. Defaults to 'api_token.yml'.
        str_env (str): Environment key to update (e.g., 'dev', 'qa', 'prod').
                       Defaults to global 'C.ENVIRONMENT' if not provided.
        str_system_name (str): Name of the system to update (e.g., 'salesforce', 'another_system').
        token_data (dict): Dictionary containing 'token' to store.
        token_lifetime_seconds (int): Lifetime of the token in seconds (default: 3600 seconds).

    Raises:
        FileNotFoundError: If YAML file cannot be found.
        KeyError: If required parameters are missing.
        Exception: For any unexpected errors.
    """
    # Use global defaults if not provided
    token_file_data = {}
    if not str_path:
        str_path = C.PATH_TO_CONFIGS
    if not str_env:
        str_env = C.ENVIRONMENT

    try:
        # Load the existing YAML file
        try:
            with open(str_path + file_name, 'r') as file:
                dict_api_tokens = yaml.safe_load(file)
        except FileNotFoundError:
            # Create a new dictionary if the file does not exist
            dict_api_tokens = {}

        if not dict_api_tokens:
            dict_api_tokens = {}

        # Ensure the environment exists in the dictionary
        if str_env not in dict_api_tokens:
            dict_api_tokens[str_env] = {}

        # Calculate expiration date based on the current time and token lifetime
        expiration_date = (datetime.now(C.TZ_TIMEZONE) + timedelta(seconds=token_lifetime_seconds)).strftime("%Y-%m-%d %H:%M:%S")

        # Update the token data for the specified system
        token_file_data["instance_url"] = token_data["instance_url"]
        token_file_data["access_token"] = token_data["access_token"]
        token_file_data["expiration_date"] = expiration_date
        
        dict_api_tokens[str_env][str_system_name] = token_file_data

        # Save the updated dictionary back to the YAML file
        with open(str_path + file_name, 'w') as file:
            yaml.safe_dump(dict_api_tokens, file)

        print(f"Token for system '{str_system_name}' in environment '{str_env}' successfully stored.")
    
    except KeyError as e:
        raise KeyError(f"Missing required key: {e}")
    except Exception as e:
        print(f"Error storing token in {str_path + file_name}: {e}")
        raise

def get_source_tables_list_from_config(str_path=''):
    """
    Retrieves a list of source tables from configuration YAML files without applying any filters.

    Parameters:
    str_path (str): The path to the directory containing the configuration YAML files.
                    If not provided, defaults to a global variable 'C.PATH_TO_CONFIGS'.

    Returns:
    list: A list of dictionaries containing source table configurations.
    """
    # Populate constant
    if not str_path:
        str_path = C.PATH_TO_CONFIGS

    try:
        # Load YAML files
        with open(str_path + 'source_tables.yml', 'r') as file:
            list_source_tables = yaml.safe_load(file)

        # Return all source tables without filtering
        return list_source_tables
    
    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")
    except KeyError as e:
        print(f"Missing expected key in configuration: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")
    return []

def load_salesforce_objects_to_source_table_config(dict_salesforce_auth_params):
    """
    Loads Salesforce objects into the source table configuration, updating the existing configuration.

    Parameters:
    dict_salesforce_auth_params (dict): A dictionary containing authentication parameters for Salesforce.

    Returns:
    None
    """
    try:
        # Get all objects from Salesforce
        dict_sobjects = get_salesforce_objects(dict_salesforce_auth_params)

        # Reformat relevant fields from Salesforce objects into format of source_tables dict
        list_converted_source_tables_from_salesforce = convert_objects_dict_to_source_table_list(dict_sobjects)

        # Combine new tables from Salesforce with existing tables in source_tables.yml
        list_updated_source_tables = add_source_tables_to_config(list_converted_source_tables_from_salesforce)

        # Update source_tables.yml
        write_list_to_yml(list_updated_source_tables)

    except Exception as e:
        print(f"An unexpected error occurred during the load process: {e}")

def get_salesforce_objects(dict_auth_params):
    """
    Retrieves a list of Salesforce objects using the provided authentication parameters.

    Parameters:
    dict_auth_params (dict): A dictionary containing authentication parameters,
                             including 'instance_url' and 'token' with 'access_token'.

    Returns:
    dict: A dictionary containing the Salesforce objects payload if successful, or an error message if not.
    """
    try:
        # Construct the authorization header using the access token
        auth_header = {'Authorization': 'Bearer ' + dict_auth_params['token']['access_token']}
        
        # Make the GET request to the Salesforce API to retrieve sobjects
        response = requests.get(dict_auth_params['instance_url'] + '/services/data/v60.0/sobjects/', headers=auth_header)
        response.raise_for_status()  # Raise an error for bad responses

        # Parse the JSON response
        dict_sobject_payload = json.loads(response.text)
        return dict_sobject_payload['sobjects']
    
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except requests.exceptions.RequestException as req_err:
        print(f"Request error occurred: {req_err}")
    except KeyError as e:
        print(f"Missing expected key in authentication parameters: {e}")
    except json.JSONDecodeError as json_err:
        print(f"Error decoding JSON response: {json_err}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    return {"error": "Failed to retrieve Salesforce objects"}

def convert_objects_dict_to_source_table_list(list_sobjects, str_path = ''):
    """
    Converts a list of Salesforce objects into a list of source table dictionaries with only relevant fields.

    Parameters:
    list_sobjects (list): A list of dictionaries, each representing a Salesforce object.

    Returns:
    list: A list of dictionaries, each representing a source table configuration.
    """
    # Use default path if not provided
    if str_path == '':
        str_path = C.PATH_TO_CONFIGS
    
    with open(str_path + 'salesforce_object_opt_outs.yml', 'r') as file:
        list_salesforce_opt_out_tables = yaml.safe_load(file)

    list_source_tables = []
    try:
        # Iterate over each Salesforce object in the list
        for sobject in list_sobjects:
            # Exclude tables that are opted out
            if sobject['name'] not in list_salesforce_opt_out_tables:
                dict_sobject = {}
                dict_sobject['target_table_name'] = sobject['name']
                dict_sobject['source_system_name'] = 'salesforce'
                dict_sobject['salesforce_acquisition_parameters'] = {
                    'object_name': sobject['name']
                }
                dict_sobject['is_active'] = True
    
            list_source_tables.append(dict_sobject)
        return list_source_tables
    
    except KeyError as e:
        print(f"Missing expected key in Salesforce object: {e}")
    
def add_source_tables_to_config(list_tables_from_salesforce, str_path = ''):
    """
    Adds source tables to the configuration with tables from Salesforce.
    Only adds tables that don't already exist in the configuration.
 
    Parameters:
    list_tables_from_salesforce (list): A list of dictionaries, each representing a source table from Salesforce.
    str_path (str): The path to the directory containing the 'source_tables.yml' file.
                    If not provided, defaults to a global variable 'C.PATH_TO_CONFIGS'.
 
    Returns:
    list: An updated list of source table configurations.
    """
    # Use default path if not provided
    if str_path == '':
        str_path = C.PATH_TO_CONFIGS
 
    try:
        # Load existing source table config from YAML file
        with open(str_path + 'source_tables.yml', 'r') as file:
            dict_source_tables_yaml = yaml.safe_load(file)
       
        # Create a dictionary from existing source tables for easy lookup by name
        dict_source_tables = {}
        if dict_source_tables_yaml:
            dict_source_tables = {table['target_table_name']: table for table in dict_source_tables_yaml}
 
        # Iterate over all source tables
        for table in list_tables_from_salesforce:
            # Only add the table if it doesn't already exist
            if table['target_table_name'] not in dict_source_tables:
                dict_source_tables[table['target_table_name']] = table
 
        # Convert the dictionary back to a list
        updated_source_tables = list(dict_source_tables.values())
 
        return updated_source_tables
   
    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")
    except KeyError as e:
        print(f"Missing expected key in source tables: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    return []

def write_list_to_yml(list_to_write, str_path=''):
    """
    Writes a list of dictionaries to a YAML file.

    Parameters:
    list_to_write (list): The list of dictionaries to be written to the YAML file.
    str_path (str): The file path where the YAML file will be written. If not provided,
                    defaults to 'source_tables.yml' in the C.PATH_TO_CONFIGS directory.

    Returns:
    None
    """
    if not str_path:
        # Default to 'source_tables.yml' in the C.PATH_TO_CONFIGS directory if no path is provided
        str_path = C.PATH_TO_CONFIGS + 'source_tables.yml'
    
    try:
        # Try writing to the YAML file
        with open(str_path, 'w') as file:
            yaml.dump(list_to_write, file, default_flow_style=False)
        print(f'Wrote to path {str_path}')
    except Exception as e:
        # Handle any exceptions that occur during the file write
        print(f"Failed to write to path {str_path}: {e}")

def calculate_checksum(file_path):
    """
    Calculates the checksum (SHA-256) of a file by reading it into a Spark DataFrame and processing it.

    Parameters:
        file_path (str): Path to the file (local or DBFS).

    Returns:
        str: The checksum (SHA-256 hash) of the file content.

    Raises:
        ValueError: If the file type is unsupported or if the checksum calculation fails.
    """
    try:
        # Determine the file type based on the extension
        _, file_extension = os.path.splitext(file_path)
        file_extension = file_extension.lower()
        print(f"Processing file: {file_path}, Extension: {file_extension}")

        # Read the file into a DataFrame based on its format
        if file_extension == '.csv':
            print(f"Reading CSV file: {file_path}")
            df = G.spark.read.csv(file_path)

        elif file_extension == '.txt':
            print(f"Reading TXT file: {file_path}")
            df = G.spark.read.text(file_path)

        elif file_extension == '.parquet':
            print(f"Reading Parquet file: {file_path}")
            df = G.spark.read.parquet(file_path)

        else:
            raise ValueError(f"Unsupported file type: {file_extension}")

        # Concatenate all columns into a single string for each row
        concatenated_df = df.withColumn("row_string", concat_ws(",", *df.columns))

        # Calculate row-level checksums using SHA-256
        checksum_df = concatenated_df.withColumn("row_checksum", sha2(concat_ws(",", "row_string"), 256))

        # Aggregate all row checksums into a final checksum
        final_checksum = checksum_df.select(sha2(concat_ws(",", "row_checksum"), 256).alias("final_checksum")) \
                                    .collect()[0]["final_checksum"]

        return final_checksum

    except Exception as e:
        raise ValueError(f"Failed to calculate checksum for file: {file_path}. Error: {e}")

def update_checksum_property(batch_id, column_name, checksum_value):
    """
    Updates a specific checksum property in the audit table for a given batch ID.

    Parameters:
        batch_id (int): The ID of the batch to update.
        column_name (str): The name of the checksum column to update (e.g., "source_checksum", "landing_checksum").
        checksum_value (str): The checksum value to set for the specified column.

    Raises:
        ValueError: If the update fails or the column name is invalid.
    """
    try:
        # Validate the column name
        valid_columns = ["source_checksum", "landing_checksum"]  # Add more checksum-related columns if needed
        if column_name not in valid_columns:
            raise ValueError(f"Invalid column name '{column_name}'. Valid columns are: {', '.join(valid_columns)}")

        # Define the schema for the update
        schema = StructType([
            StructField("batch_id", IntegerType(), False),
            StructField(column_name, StringType(), True)  # Dynamically update the specified column
        ])

        # Create a DataFrame with the new checksum value
        updates_df = G.spark.createDataFrame([{
            "batch_id": int(batch_id),
            column_name: checksum_value
        }], schema=schema)

        # Load the Delta table
        delta_table = DeltaTable.forName(G.spark, C.PATH_TO_AUDIT_TABLE)

        # Perform the merge operation
        delta_table.alias("tgt").merge(
            updates_df.alias("src"),
            "tgt.batch_id = src.batch_id"
        ).whenMatchedUpdate(set={
            column_name: expr(f"src.{column_name}")  # Dynamically update the specified column
        }).execute()

    except Exception as e:
        raise ValueError(f"Failed to update {column_name} for batch_id {batch_id}: {e}")


def compare_checksums(source_checksum, destination_checksum):
    """
    Compares two checksums and returns whether they match.

    Parameters:
        source_checksum (str): The checksum of the source file.
        destination_checksum (str): The checksum of the destination file.

    Returns:
        bool: True if the checksums match, False otherwise.

    Raises:
        ValueError: If either checksum is invalid (e.g., None or empty).
    """
    if not source_checksum or not destination_checksum:
        raise ValueError("Both source_checksum and destination_checksum must be provided and non-empty.")

    # Return whether the checksums match
    return source_checksum == destination_checksum

def update_consistency_validation_result(batch_id, validation_result):
    """
    Updates the `source_landing_consistency_validation_result` field in the Delta table.

    Parameters:
        batch_id (int): The ID of the batch to update.
        validation_result (bool): The result of the checksum comparison (True if checksums match, False otherwise).

    Raises:
        ValueError: If the update fails.
    """
    try:
        # Define the schema for the update
        schema = StructType([
            StructField("batch_id", IntegerType(), False),
            StructField("source_landing_consistency_validation_result", StringType(), True)
        ])

        # Create a DataFrame with the new validation result
        updates_df = G.spark.createDataFrame([{
            "batch_id": int(batch_id),
            "source_landing_consistency_validation_result": validation_result
        }], schema=schema)

        # Load the Delta table
        delta_table = DeltaTable.forName(G.spark, C.PATH_TO_AUDIT_TABLE)

        # Perform the merge operation
        delta_table.alias("tgt").merge(
            updates_df.alias("src"),
            "tgt.batch_id = src.batch_id"
        ).whenMatchedUpdate(set={
            "source_landing_consistency_validation_result": expr("src.source_landing_consistency_validation_result")
        }).execute()

        print(f"Updated source_landing_consistency_validation_result for batch_id {batch_id} to {validation_result}")

    except Exception as e:
        raise ValueError(f"Failed to update consistency validation result for batch_id {batch_id}: {e}")

def update_yaml_property(str_path='', file_name='', property_path=None, property_value=None, exceptions=None, default_value=None):
    """
    Updates a specified property in a YAML file for all items, setting a specific value for exceptions
    and optionally a default value for the rest (only for 'is_active').

    Parameters:
    str_path (str): Path to the directory containing the YAML files. If empty, defaults to 'C.PATH_TO_CONFIGS'.
    file_name (str): Name of the YAML file to update (e.g., 'source_tables.yml' or 'source_systems.yml').
    property_path (list): A list of keys defining the path to the property to update (e.g., ['file_acquisition_parameters', 'schedule_or_file_watch']).
    property_value (any): The value to set for the property in the items listed in exceptions.
    exceptions (list): A list of items (e.g., target_table_name or source_system_name) that should receive the specified property_value.
    default_value (any): The default value to set for the property in the rest of the items (only applied to 'is_active').
    """
    # Use the default path if str_path is empty
    if not str_path:
        str_path = C.PATH_TO_CONFIGS

    # Ensure property_path and exceptions are not None
    if property_path is None or not isinstance(property_path, list):
        raise ValueError("property_path must be a list of keys defining the path to the property.")
    if exceptions is None:
        exceptions = []

    # Combine path and file name
    full_path = os.path.join(str_path, file_name)

    try:
        # Load the YAML file
        with open(full_path, 'r') as file:
            yaml_data = yaml.safe_load(file)

        # Iterate through each item and update the property based on exceptions
        for item in yaml_data:
            # Extract the identifier (e.g., target_table_name or source_system_name)
            identifier = item.get("target_table_name", "") or item.get("source_system_name", "")

            # Navigate to the property using the property_path
            current = item
            for key in property_path[:-1]:  # Traverse to the second-to-last key
                current = current.get(key, {})

            # Update the property value
            if identifier in exceptions:
                current[property_path[-1]] = property_value  # Set value for exceptions
            else:
                # Apply default_value only if the property_path points to 'is_active'
                if property_path[-1] == "is_active":
                    current[property_path[-1]] = default_value  # Set default value for 'is_active'
                else:
                    # Do not modify other properties for non-exceptions
                    continue

        # Save the updated YAML file
        with open(full_path, 'w') as file:
            yaml.dump(yaml_data, file)

        print(f"File {full_path} updated successfully.")

    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")
    except Exception as e:
        print(f"An error occurred while updating the file: {e}")
def get_tables_in_validated_schemas(validated_schema_prefix='',catalog_name=''):
    # TODO WRITE TEST
    if validated_schema_prefix == '':
        validated_schema_prefix = C.SCHEMA_USERNAME_PREFIX + 'validated'
    if catalog_name == '':
        catalog_name = C.CATALOG
    # Get all schemas (databases)
    G.spark.sql(f'USE CATALOG {catalog_name}')
    schemas = [row.name for row in G.spark.catalog.listDatabases()]
    # Filter schemas with the given prefix
    filtered_schemas = [schema for schema in schemas if schema.startswith(validated_schema_prefix)]
    print(f'filtered schemas: {filtered_schemas}')
    # For each schema, get all table names
    all_tables = []
    for schema in filtered_schemas:
        tables = [table.name for table in G.spark.catalog.listTables(schema)]
        all_tables.extend(tables)
    return all_tables

def delete_files_at_path(folder_path):
    # Find all files in folder
    try:
        files = G.dbutils.fs.ls(folder_path)
    except Exception as e:
        if "java.io.FileNotFoundException" in str(e):
            print(f"Folder '{folder_path}' does not exist. No files deleted.")
            return

    # Iterate through the files and delete each one
    for file in files:
        file_path = file.path
        G.dbutils.fs.rm(file_path, True)  # The second argument 'True' ensures recursive deletion if it's a directory

    print(f"All files in the folder '{folder_path}' have been deleted.")
