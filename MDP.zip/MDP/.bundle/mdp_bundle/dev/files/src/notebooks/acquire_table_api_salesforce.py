# Databricks notebook source
# Purpose: Acquire data from Salesforce and write to landing volume
# Called by: run_batch
# 1. Update audit table to indicate start of Salesforce acquisition
# 2. Retrieve data from Salesforce API based on batch parameters
# 3. Write data to landing volume specified in batch parameters
# 4. Update audit table after acquisition is complete

# COMMAND ----------

# MAGIC %run ./_shared

# COMMAND ----------

# DBTITLE 1,Get parameters from workflow
# batch_id maps to batch passed from forEach
batch_id = (dbutils.widgets.get("batch_id"))

# batch_parameters is pulled from audit table by batch_id
batch_parameters = get_batch_parameters_by_batch_id(batch_id)

# dict_targets is subset of targets from config yaml filtered to only active environment
str_landing_path = batch_parameters["targets"]["landing_volume"]

#source_systems is full list of source systems from config yaml
dict_source_system = batch_parameters["source_system"]

# run_id is run_id tied to notebook that called this
# run_id = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("jobRunIdForLineage").get()

# COMMAND ----------

def get_object_fields(str_sobject_name, str_instance_url, str_api_version, str_access_token):
    """
    Retrieve non-compound field names from a Salesforce object description.

    Parameters:
    str_sobject_name (str): The name of the Salesforce object (e.g., 'Account').
    str_instance_url (str): The base URL of the Salesforce instance.
    str_api_version (str): The Salesforce API version (e.g., 'v52.0').
    str_access_token (str): The access token for Salesforce API authentication.

    Returns:
    str: A comma-separated string of non-compound field names.
    """
    # Construct the authorization header for the request
    dict_auth_header = {'Authorization': 'Bearer ' + str_access_token}

    # Construct the URI for the describe call
    str_sobject_describe_uri = f'{str_instance_url}/services/data/{str_api_version}/sobjects/{str_sobject_name}/describe'

    print('uri: ' + str_sobject_describe_uri)
    print(dict_auth_header)

    try:
        # Make the request to get the object description
        response_sobject_describe = requests.get(str_sobject_describe_uri, headers=dict_auth_header)
        response_sobject_describe.raise_for_status()  # Raise an error for bad responses

        # Extract field names from the response
        set_fields = set([field['name'] for field in response_sobject_describe.json()['fields']])
        set_compound_fields = set(
            [field['compoundFieldName'] for field in response_sobject_describe.json()['fields'] if field['compoundFieldName'] != 'Name' and not field['nameField']]
        )
        list_non_compound_fields = list(set_fields - set_compound_fields)
        list_non_compound_fields.sort()

        return ','.join(list_non_compound_fields)
    
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except requests.exceptions.RequestException as req_err:
        print(f"Request exception occurred: {req_err}")
    except KeyError as key_err:
        print(f"Key error: {key_err}")
    except Exception as err:
        print(f"An unexpected error occurred: {err}")

    return ""

# COMMAND ----------

def construct_SOQL_query(str_object_fields, batch_parameters):
    
    # Get last ingest date from audit table
    row_max_timestamp = get_audit_row_with_max_timestamp(batch_parameters.get("target_table_name", ''))
    
    # Initialize variables
    dt_max_timestamp = None
    if row_max_timestamp is not None:
        dt_max_timestamp = row_max_timestamp['transaction_date_max']
    print("dt_max_timestamp value:", dt_max_timestamp)
    print("dt_max_timestamp type:", type(dt_max_timestamp))
    
    # Get current UTC time for processing start time
    dt_processing_start_time = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')

    # Construct base query
    str_base_query = f"SELECT {str_object_fields} FROM {batch_parameters['salesforce_acquisition_parameters']['object_name']}"
    str_base_query_filter = ''

    # Add filter for incremental loads only if we have a valid timestamp
    if (batch_parameters['salesforce_acquisition_parameters']['incremental_or_full'] == 'incremental' and 
            dt_max_timestamp is not None and 
            dt_max_timestamp not in ['None', '1900-01-01 00:00:00.000000']):
        print("before try: ", dt_max_timestamp)
        try:
            # Format the datetime object directly
            query_date = dt_max_timestamp.strftime('%Y-%m-%dT%H:%M:%SZ')
            str_base_query_filter = f" WHERE ({batch_parameters['ingest_parameters']['system_date_field']} > {query_date} AND {batch_parameters['ingest_parameters']['system_date_field']} <= {dt_processing_start_time})"
        except Exception as e:
            print("Error formatting dt_max_timestamp:", e)
            pass
 
    # Combine query and filter
    str_query = str_base_query + str_base_query_filter
    
    # Return query information
    dict_query = {
        'str_query': str_query,
        'dt_processing_start_time': dt_processing_start_time
    }
    print(str_query)
    return dict_query

# COMMAND ----------

def acquire_source_bulk_salesforce(batch_id, batch_parameters):

    str_source_system_name = batch_parameters.get("source_system_name", {})

    dict_token_payload = get_token_from_api_tokens(str_system_name=str_source_system_name)

    if not is_token_valid(dict_token_payload):
        dict_token_payload =  get_token(str_source_system_name, dict_source_system['auth_parameters'])
        store_token_in_api_tokens(str_system_name=str_source_system_name, token_data=dict_token_payload)

    sf = Salesforce(instance_url=dict_token_payload['instance_url'], session_id=dict_token_payload['access_token'], version='60.0')

    dict_acquisition_parameters = batch_parameters.get('salesforce_acquisition_parameters', {})
    str_api_version = dict_acquisition_parameters.get('api_version_number', 'v60.0')
    object_fields = get_object_fields(dict_acquisition_parameters['object_name'], dict_token_payload['instance_url'], str_api_version, dict_token_payload['access_token'])

    dict_query = construct_SOQL_query(object_fields, batch_parameters)
    str_query = dict_query['str_query']
    dt_processing_start_time = dict_query['dt_processing_start_time']
    f = f"sf.bulk2.{dict_acquisition_parameters['object_name']}.query(query='{str_query}', column_delimiter='PIPE')"
    results = eval(f)
    str_results = '\n'.join(results)
    

    str_volume_path = f"{str_landing_path}{str_source_system_name}/{batch_parameters['target_table_name']}/batch_{batch_id}.csv"

    # Check if the file already exists
    try:
        dbutils.fs.ls(str_volume_path)  # Check if the file exists
        logger.debug(f"File already exists at destination: {str_volume_path}. Skipping write.")
        return str_volume_path  # Return the path without overwriting
    except Exception:
        pass  # File does not exist, proceed with writing
    
    # Write data to the file on DBFS
    dbutils.fs.put(str_volume_path, str_results, overwrite=True)

    return str_volume_path

# COMMAND ----------

# Update audit entry to indicate start of notebook
update_audit_entry_job_task(batch_id, 'AcquireTableAPISalesforce')

# COMMAND ----------

# Acquire source
str_landing_path = acquire_source_bulk_salesforce(batch_id, batch_parameters)

# COMMAND ----------

update_audit_entry_job_after_acquisition(
    batch_id, list_landing_paths = [str_landing_path]
)