def setup_globals(spark, dbutils):
    """Setup constants in this function

    Changing any constants requires the state of the notebook to be cleared because Python imports are cached
    """
    G = Globals
    G.spark = spark
    G.dbutils = dbutils

class Globals():
    pass
