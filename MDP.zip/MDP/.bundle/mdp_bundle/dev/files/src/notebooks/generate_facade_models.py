# Databricks notebook source
# MAGIC %run ./_shared

# COMMAND ----------

def generate_dbt_models(source_to_silver, dbt_models_dir, write_to_disk=True):
    """
    Generates DBT models from the provided mapping DataFrame.
    
    Args:
        source_to_silver (pd.DataFrame): The mapping DataFrame.
        dbt_models_dir (str): Base directory for DBT models.
        write_to_disk (bool): If True, writes SQL files to disk. If False, prints to stdout.
    """
    dbt_model_base_path = os.path.join(dbt_models_dir, 'vw')
    if write_to_disk:
        os.makedirs(dbt_model_base_path, exist_ok=True)

    # Get list of exisiting tables in validated schemas to write facade models for
    table_names = get_tables_in_validated_schemas()
    print(table_names)

    for source_system, system_group in source_to_silver.groupby("source_system"):
        source_system_path = os.path.join(dbt_model_base_path, source_system.lower())
        if write_to_disk:
            os.makedirs(source_system_path, exist_ok=True)
        
        print(f"Processing source system: {source_system}")
        
        for facade_table, group in system_group.groupby("facade_name"):
            source_table = group["source_table_name"].iloc[0]
            if source_table.lower() in table_names:
                
                columns_sql = []
                for _, row in group.iterrows():
                    col_expr = row['source_expression'] if pd.notnull(row['source_expression']) else f"`{row['source_column_name']}`"
                    target_data_type = row['target_data_type']
                    cast_expr = f"CAST({col_expr} AS {target_data_type})"
                    columns_sql.append(f"    {cast_expr} AS `{row['target_column_name']}`")
                
                columns_block = ",\n".join(columns_sql)
                t_schema = f"""{{% set target_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'vw_{source_system.lower()}' %}}\n"""
                ref = f"{{{{ ref('{source_table}') }}}}"
                model_sql = f"""{t_schema}{{{{ config(materialized='view', schema='vw', tags = ['facade'])}}}}
                SELECT
                {columns_block}
                FROM {ref}
                """

                filename = f"{facade_table.lower()}.sql"
                if write_to_disk:
                    with open(os.path.join(source_system_path, filename), 'w') as f:
                        f.write(model_sql)
                    print(f"Generated Model for {source_system}/{facade_table} and wrote to {filename}")
                else:
                    print(f"Generated Model for {source_system}/{facade_table}:\n\n{model_sql}")
            else:
                print(f"Skipping {source_system}/{facade_table} because it doesn't exist in the validated schema")

# COMMAND ----------

# Load your mapping data
source_to_silver = pd.read_excel(f'{C.PATH_TO_CONFIGS}facade_mapping.xlsx')
# write_to_disk=False because not all sources have been ingested yet
generate_dbt_models(source_to_silver, C.DBT_MODELS_DIR)