# Databricks notebook source
# Purpose: Acquire data from flat file and write to landing volume
# Called by: run_batch
# 1. Update audit table to indicate start of file acquisition
# 2. Copy data from source location into landing volume
# 4. Update audit table after acquisition is complete

# COMMAND ----------

# MAGIC %run ./_shared

# COMMAND ----------

# DBTITLE 1,Get parameters from workflow
# batch_id maps to batch passed from forEach
batch_id = (dbutils.widgets.get("batch_id"))

# batch_parameters is pulled from audit table by batch_id
batch_parameters = get_batch_parameters_by_batch_id(batch_id)

# dict_targets is subset of targets from config yaml filtered to only active environment
str_landing_path = batch_parameters["targets"]["landing_volume"]

#source_systems is full list of source systems from config yaml
dict_source_system = batch_parameters["source_system"]

# run_id is run_id tied to notebook that called this
# run_id = dbutils.notebook.entry_point.getDbutils().notebook().getContext().tags().get("jobRunIdForLineage").get()

# COMMAND ----------

# Update audit entry to indicate start of notebook
update_audit_entry_job_task(batch_id, 'AcquireTableFile')

# COMMAND ----------

def process_and_copy_files(batch_parameters, batch_id):
    """
    Copies files from the `flat_file_source_paths` to the `landing_volume` and renames them to include the `batch_id`.

    If the `source_type` is "volume", it uses Databricks File System (DBFS) utilities.
    Otherwise, it uses standard Python file handling for local file paths.

    Parameters:
        batch_parameters (dict): A dictionary containing batch parameters, including file paths.
        batch_id (str): The batch ID to include in the renamed file.

    Returns:
        dict: A dictionary where keys are landing file paths and values are their respective source file paths.

    Raises:
        FileNotFoundError: If the source files do not exist.
        ValueError: If required parameters are missing in the batch_parameters.
    """
    # Dictionary to store the mapping of landing paths to source paths
    dict_landing_to_source_paths = {}

    try:
        # Extract necessary parameters
        file_acquisition_parameters = batch_parameters.get("file_acquisition_parameters", {})
        source_type = file_acquisition_parameters.get("source_type")
        str_landing_volume = batch_parameters.get("targets", {}).get("landing_volume")
        str_source_system_name = batch_parameters.get("source_system_name", '')
        str_target_table_name = batch_parameters.get("target_table_name", '')

        if not str_landing_volume:
            raise ValueError("Missing required parameters: flat_file_source_paths and/or str_landing_volume")

        list_file_paths, list_filenames = get_file_list(file_acquisition_parameters)
        list_active_file_paths = remove_finished_batches_from_file_list(list_file_paths)

        if not list_active_file_paths:
            return {}

        # Process each source file
        for index, flat_file_source_path in enumerate(list_active_file_paths, 1):
            # Extract the filename and extension
            filename = os.path.basename(flat_file_source_path)
            filename_without_ext, file_extension = os.path.splitext(filename)

            # Create new filename with batch ID
            new_file_name = f"{filename_without_ext}_batch_{batch_id}{file_extension}"
            logger.debug(f"New file name: {new_file_name}")

            # Construct the destination path in the landing volume
            destination_path = os.path.join(
                str_landing_volume,
                str_source_system_name,
                str_target_table_name,
                new_file_name
            )
            logger.debug(f"Destination path: {destination_path}")

            # Ensure the destination directory exists
            ensure_volume_and_directory(destination_path)

            print(f"Calculating source checksum for: {flat_file_source_path}")
            source_checksum = calculate_checksum(flat_file_source_path)

            print(f"Updating source checksum for batch_id {batch_id}")
            update_checksum_property(batch_id, "source_checksum", source_checksum)

            if source_type == "volume":
                # Use DBFS utilities for "volume" source type
                logger.debug(f"Using DBFS utilities for file operations on {flat_file_source_path}")

                # Check if the source file exists in DBFS
                try:
                    dbutils.fs.ls(flat_file_source_path)  # Will throw an exception if the file doesn't exist
                except Exception:
                    raise FileNotFoundError(f"Source file not found: {flat_file_source_path}")

                # Check if the destination file exists
                try:
                    dbutils.fs.ls(destination_path)
                    logger.debug(f"File already exists at destination: {destination_path}. Skipping copy.")
                    # Add the mapping of landing path to source path to the dictionary
                    dict_landing_to_source_paths[destination_path] = flat_file_source_path
                    continue
                except Exception:
                    pass  # Destination file does not exist, proceed with copy

                # Copy the file to the landing volume and rename it
                dbutils.fs.cp(flat_file_source_path, destination_path)
                logger.debug(f"File successfully copied and renamed to: {destination_path}")

            else:
                # Use standard Python file handling for local file paths
                logger.debug(f"Using local file system utilities for file operations on {flat_file_source_path}")

                # Check if the source file exists locally
                if not os.path.exists(flat_file_source_path):
                    raise FileNotFoundError(f"Source file not found: {flat_file_source_path}")

                # Check if the destination file exists
                if os.path.exists(destination_path):
                    logger.debug(f"File already exists at destination: {destination_path}. Skipping copy.")
                    # Add the mapping of landing path to source path to the dictionary
                    dict_landing_to_source_paths[destination_path] = flat_file_source_path
                    continue

                # Copy the file to the landing volume and rename it
                shutil.copy(flat_file_source_path, destination_path)
                logger.debug(f"File successfully copied and renamed to: {destination_path}")

            print(f"Calculating landing checksum for: {destination_path}")
            landing_checksum = calculate_checksum(destination_path)

            print(f"Updating landing checksum for batch_id {batch_id}")
            update_checksum_property(batch_id, "landing_checksum", landing_checksum)

            validation_result = compare_checksums(source_checksum, landing_checksum)

            update_consistency_validation_result(batch_id, validation_result)

            # Add the mapping of landing path to source path to the dictionary
            dict_landing_to_source_paths[destination_path] = flat_file_source_path

        return dict_landing_to_source_paths

    except Exception as e:
        raise ValueError(f"Failed to process and copy the files: {e}")

# COMMAND ----------

dict_landing_to_source_paths = process_and_copy_files(batch_parameters, batch_id)

# COMMAND ----------

# Pull metadata fields from landing
# df_source = read_csv_into_df(str_landing_path)
# dict_metadata = get_dataframe_info(df_source)
update_audit_entry_job_after_acquisition(
    batch_id,
    dict_landing_to_source_paths = dict_landing_to_source_paths
)