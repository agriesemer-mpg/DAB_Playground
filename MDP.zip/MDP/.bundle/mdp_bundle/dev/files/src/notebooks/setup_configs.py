# Databricks notebook source
# MAGIC %run ./_shared

# COMMAND ----------

# Generate list of source systems from config YAML files
list_source_systems = get_source_systems_list_from_config()

# COMMAND ----------

# Generate token for each API source
for system in list_source_systems:
    if system['source_system_type'] == 'api':
        system['auth_parameters']['token'] = get_token(system['source_system_name'], system['auth_parameters'])

# COMMAND ----------

# Update source_tables.yml to include new sources from Salesforce
for system in list_source_systems:
    if system['source_system_name'] == 'salesforce':
        dict_salesforce_auth_params = system['auth_parameters']

load_salesforce_objects_to_source_table_config(dict_salesforce_auth_params)

# COMMAND ----------


# Generate list of source tables for ingestion by filtering source_tables.yml through ingestion_source_inclusions.yml and ingestion_source_exclusions.yml
list_source_tables = get_source_tables_list_from_config()

# COMMAND ----------

# Delete all existing facade models
dbt_model_base_path = os.path.join(C.DBT_MODELS_DIR, 'vw')

delete_files_at_path(dbt_model_base_path)

# COMMAND ----------

def batch_update_sources_yml(list_batch_parameters, str_sources_yml_path=''):
    """
    Updates the sources.yml file to include multiple tables from a batch of parameters,
    making only one file update at the end.
    
    Parameters:
        list_batch_parameters (list): List of dictionaries containing data pipeline configuration
        str_sources_yml_path (str, optional): Path to the sources.yml file
        
    Returns:
        bool: True if the file was modified, False otherwise
    """
    # Track if any changes were made
    bool_file_modified = False
    
    # Set default str_sources_yml_path
    if str_sources_yml_path == '':
        str_sources_yml_path = C.DBT_SOURCES_YML_PATH
    
    # Default structure for a new sources.yml file
    dict_sources_data = {
        'version': 2,
        'sources': []
    }
    
    # Read existing file if it exists
    if os.path.exists(str_sources_yml_path):
        with open(str_sources_yml_path, 'r') as f:
            try:
                dict_sources_data = yaml.safe_load(f)
                if not dict_sources_data:  # Handle empty file case
                    dict_sources_data = {'version': 2, 'sources': []}
            except yaml.YAMLError as e:
                print(f"Error parsing sources.yml: {e}")
                return False
    
    # Process each set of parameters in the batch
    for params in list_batch_parameters:
        # Extract parameters from the dictionary
        str_source_system_name = params.get('source_system_name')
        str_target_table_name = params.get('target_table_name')
        
        # Skip if essential parameters are missing
        if not str_source_system_name or not str_target_table_name:
            print("Skipping entry with missing source system name or target table name")
            continue
        
        # Set default str_staging_schema
        str_staging_schema = C.SCHEMA_USERNAME_PREFIX + 'staging_' + str_source_system_name
        
        # Find the right source or create it
        bool_source_found = False
        for source in dict_sources_data.get('sources', []):
            if source.get('name') == str_staging_schema:
                bool_source_found = True
                
                # Check if table already exists in this source
                bool_table_exists = False
                for table in source.get('tables', []):
                    if table.get('name') == str_target_table_name:
                        bool_table_exists = True
                        break
                
                # Add table if it doesn't exist
                if not bool_table_exists:
                    if 'tables' not in source:
                        source['tables'] = []
                    source['tables'].append({'name': str_target_table_name})
                    print(f"Added table {str_target_table_name} to existing source {str_staging_schema}")
                    bool_file_modified = True
                    break
                else:
                    print(f"Table {str_target_table_name} already exists in source {str_staging_schema}")
                    # Continue processing other tables even if this one exists
        
        # If source doesn't exist, create it
        if not bool_source_found:
            new_source = {
                'name': str_staging_schema,
                'database': C.CATALOG,
                'schema': str_staging_schema,
                'tables': [{'name': str_target_table_name}]
            }
            dict_sources_data['sources'].append(new_source)
            print(f"Created new source {str_staging_schema} with table {str_target_table_name}")
            bool_file_modified = True
    
    # Write back to file only if modifications were made
    if bool_file_modified:
        with open(str_sources_yml_path, 'w') as f:
            yaml.dump(dict_sources_data, f, default_flow_style=False, sort_keys=False)
        
    return bool_file_modified


# COMMAND ----------

# Functon to update source.yml with source table list
batch_update_sources_yml(list_source_tables)