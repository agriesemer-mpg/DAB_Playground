# Databricks notebook source

# Purpose: Ingest table from landing into staging schema
# Called By: run_batch
# 1. Pull batch parameters
# 2. Create row hash using tracked column name list from config
# 3. Add metadata columns and append to existing staging table
# 4. Consolidate staging table into validated table using consolidation strategy
#   4a. Create dbt model/snapshot for table
#   4b. Update dbt sources.yml if net new table
#   4c. Build dbt command to consolidate table

# COMMAND ----------

# MAGIC %run ./_shared

# COMMAND ----------

def generate_dbt_model_content(str_target_table_name, str_source_system_name, str_consolidation_strategy, batch_id):
    if str_consolidation_strategy == 'merge_with_history':
        model_template = f"""
        {{% set source_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'staging_' ~ '{str_source_system_name}' %}}
        {{% set target_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'validated_' ~ '{str_source_system_name}' %}}
    
        {{{{ 
            merge_w_history_consolidation(source_schema, '{str_target_table_name}', target_schema)
        }}}}
        """
        return model_template
    
    elif str_consolidation_strategy in ['merge_without_history']:
        model_template = f"""
        {{% set source_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'staging_' ~ '{str_source_system_name}' %}}
        {{% set target_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'validated_' ~ '{str_source_system_name}' %}}
    
        {{{{ 
            merge_wo_history_consolidation(source_schema, '{str_target_table_name}', target_schema)
        }}}}
        """
        return model_template
    
    elif str_consolidation_strategy == 'append':
        model_template = f"""
        {{% set source_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'staging_' ~ '{str_source_system_name}' %}}
        {{% set target_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'validated_' ~ '{str_source_system_name}' %}}
    
        {{{{ 
            append_consolidation(source_schema, '{str_target_table_name}', target_schema)
        }}}}
        """
        return model_template
    
    elif str_consolidation_strategy == 'overwrite':
        model_template = f"""
        {{% set source_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'staging_' ~ '{str_source_system_name}' %}}
        {{% set target_schema = var("SCHEMA_USERNAME_PREFIX") ~ 'validated_' ~ '{str_source_system_name}' %}}
    
        {{{{ 
            overwrite_consolidation(source_schema, '{str_target_table_name}', target_schema)
        }}}}
        """
        return model_template
   
    return None

# COMMAND ----------

# batch_id maps to batch passed from forEach
batch_id = (dbutils.widgets.get("batch_id"))

# batch_parameters is pulled from audit table by batch_id
batch_parameters = get_batch_parameters_by_batch_id(batch_id)

# source_system is source system tied to batch
dict_source_system = batch_parameters.get('source_system', {})

# target table name is target table name tied to batch
str_target_table_name = batch_parameters.get('target_table_name', '')

# source_system_name is source_system_name tied to batch
str_source_system_name = batch_parameters.get('source_system_name', '')

# ingest_parameters is dict of params for ingestion
dict_ingest_parameters = batch_parameters.get('ingest_parameters', {})
str_system_date_field = dict_ingest_parameters.get('system_date_field', '')
str_consolidation_strategy = dict_ingest_parameters.get('consolidation_strategy', '')
list_track_changed_column_params = dict_ingest_parameters.get('track_changed_column_names', [])
system_date_field = dict_ingest_parameters.get('system_date_field', '')

# grab unique_id
unique_id_fields = dict_ingest_parameters.get('unique_id_fields', [])

# targets is dict of targets
dict_targets = batch_parameters.get('targets', {})

# define staging table path
str_staging_schema = dict_targets.get('staging_schema', '')
str_staging_catalog_path = str_staging_schema + "_" + str_source_system_name + "." + str_target_table_name
str_staging_schema_path = f"{str_staging_schema}_{str_source_system_name}"

# define the DBT models directory path
str_dbt_models_dir = f"{C.DBT_DIR}models/validated/{str_source_system_name}/"
str_dbt_snapshots_dir = f"{C.DBT_DIR}snapshots/validated/{str_source_system_name}/"

# COMMAND ----------

# Create Staging Schema
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {str_staging_schema_path}")

# COMMAND ----------

# Extract the volume_path from the most recent ingestion on the audit table
row_batch = get_audit_row_by_batch_id(batch_id)
list_landing_paths = row_batch["landing_file_paths"]

# COMMAND ----------

# Read the CSV from landing into a dataframe
list_landing_dfs = []
df_landing = None
list_landing_paths.sort()
for landing_path in list_landing_paths:
    _, str_file_extension = os.path.splitext(landing_path)
    print(str_file_extension)
    if str_file_extension.lower() == '.csv':
        # Read the CSV file into a DataFrame
        df_landing = read_csv(landing_path, dict_ingest_parameters)
    
    if str_file_extension.lower() == '.txt':
        dict_file_acquisition_parameters = batch_parameters.get('file_acquisition_parameters', {})
        df_landing = read_txt(landing_path, dict_ingest_parameters, dict_file_acquisition_parameters)

    # Add the _audit_landing_file_path column
    df_landing = df_landing.withColumn("_audit_landing_file_path", lit(landing_path))
    
    # Append the DataFrame to the list
    list_landing_dfs.append(df_landing)

# COMMAND ----------

# Write to staging table

# Check if the table exists
try:
    spark.sql(f"DESCRIBE TABLE {str_staging_catalog_path}")
    table_exists = True
except AnalysisException:
    table_exists = False

# Check if batch has already been processed
batch_already_processed = False
if table_exists:
    # Validate that batch_id is not already present
    existing = spark.sql(f"SELECT 1 FROM {str_staging_catalog_path} WHERE _audit_batch_id = '{batch_id}' LIMIT 1")
    if existing.count() > 0:
        batch_already_processed = True
        print(f"Batch ID {batch_id} already exists in {str_staging_catalog_path}. Skipping append.")

if not batch_already_processed:
    for df_landing in list_landing_dfs:
        # Pull all columns except for "_audit_landing_file_path"
        list_all_columns = [col for col in df_landing.columns if col != "_audit_landing_file_path"]
        
        # Identify change tracking columns
        list_change_tracking_columns = []
        if "include" in list_track_changed_column_params:
            # Use the specified columns to include
            list_change_tracking_columns = list_track_changed_column_params["include"]
        elif "exclude" in list_track_changed_column_params:
            # Get all columns except those in exclude list
            list_exclude_columns = list_track_changed_column_params["exclude"]
            list_change_tracking_columns = [col for col in list_all_columns if col not in list_exclude_columns]
        else:
            # Default to all columns if neither include nor exclude is specified
            list_change_tracking_columns = list_all_columns

        # Convert all columns to string type
        df_landing_stringified = df_landing.select([col(c).cast("string").alias(c) for c in df_landing.columns])

        print("Creating change tracked hash for columns:", list_change_tracking_columns)
        change_tracked_hash = sha2(concat_ws("|", *[col(c) for c in list_change_tracking_columns]), 256)

        print("Creating change tracked hash for columns:", list_change_tracking_columns)
        unique_record_hash = sha2(concat_ws("|", *[col(c) for c in unique_id_fields]), 256)
    
        # Add metadata columns
        df_landing_with_metadata_columns = df_landing_stringified \
            .withColumn("_audit_batch_id", lit(batch_id)) \
            .withColumn("_audit_ingestion_timestamp", current_timestamp()) \
            .withColumn("_audit_tracked_changes_hash", change_tracked_hash) \
            .withColumn("_audit_unique_record_hash", unique_record_hash) \
            .withColumn("_audit_validation_status", lit('')) \
            .withColumn("_audit_system_timestamp", col(system_date_field))
                

        if table_exists:
            # Append to the existing table
            df_landing_with_metadata_columns.write \
                .mode("append") \
                .insertInto(str_staging_catalog_path)
        else:
            # Table does not exist; create it
            table_exists = True
            df_landing_with_metadata_columns.write \
                .format("delta") \
                .mode("overwrite") \
                .option("delta.columnMapping.mode", "name") \
                .saveAsTable(str_staging_catalog_path)

# COMMAND ----------

# Create model files for each target table
model_content = generate_dbt_model_content(str_target_table_name, str_source_system_name, str_consolidation_strategy, batch_id)

if model_content:
    # Define file path and extension based on strategy
    file_extension = ".sql"
    
    # Ensure the directory exists
    os.makedirs(str_dbt_models_dir, exist_ok=True)
    str_dbt_model_file_path = f"{str_dbt_models_dir}{str_target_table_name}.sql"
    
    # Write model content to file
    with open(str_dbt_model_file_path, "w") as f:
        f.write(model_content)
    
    print(f"Generated DBT model file: {str_dbt_model_file_path}")

# COMMAND ----------

# # Read staging table
# df_staging = spark.read.table(str_staging_catalog_path)

# # Pull distinct landing file paths
# rows_landing_file_paths = df_staging.where(col("_audit_batch_id") == batch_id).select("_audit_landing_file_path").distinct().collect()
# list_landing_file_paths = []
# for row in rows_landing_file_paths:
#     list_landing_file_paths.append(row["_audit_landing_file_path"])

# # Create command for kicking off consolidation into validated schema
# list_consolidation_commands = []
# list_landing_file_paths.sort()
# # Define defaults for dbt variables
# vars_dict = {
#     'batch_id': batch_id,
#     'landing_file_path': '',
#     'SCHEMA_USERNAME_PREFIX': C.SCHEMA_USERNAME_PREFIX
# }
# for str_landing_file_path in list_landing_file_paths:
#     str_consolidation_command = ''
#     vars_dict['landing_file_path'] = str_landing_file_path
    
#     if str_consolidation_strategy == 'merge_with_history':
      
#         # Convert to YAML-compatible string
#         str_vars = json.dumps(vars_dict)

#         # Build the command
#         str_consolidation_command = (
#             f"snapshot --target {C.DEPLOY_TARGET} "
#             f'--select "{str_target_table_name}" '
#             f"--vars '{str_vars}'"
#         )
#         list_consolidation_commands.append(str_consolidation_command)

#     else:
#         # Convert to YAML-compatible string
#         str_vars = json.dumps(vars_dict)

#         # Build the command
#         str_consolidation_command = (
#             f"run --target {C.DEPLOY_TARGET} "
#             f'--select "{str_target_table_name}" '
#             f"--vars '{str_vars}'"
#         )
#         list_consolidation_commands.append(str_consolidation_command)

# dbutils.jobs.taskValues.set(key = "list_consolidation_commands", value = list_consolidation_commands)

# COMMAND ----------

update_audit_entry_job_after_ingestion(
    batch_id,
    str_staging_catalog_path=str_staging_catalog_path,
    str_system_date_field=str_system_date_field
)