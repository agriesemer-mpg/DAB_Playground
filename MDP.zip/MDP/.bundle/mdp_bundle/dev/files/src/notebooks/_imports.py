# Databricks notebook source
# DBTITLE 1,pip installs - MUST RUN FIRST
try:
    # Try to import before installing - this decreases install time when rerunning notebooks
    from simple_salesforce import Salesforce
except:
    # Install all packages on one line - this makes install faster
    import subprocess; subprocess.check_call(['pip', 'install', 'simple_salesforce'])
    dbutils.library.restartPython()

try:
    # Try to import before installing - this decreases install time when rerunning notebooks
    from loguru import logger
except:
    # Install all packages on one line - this makes install faster
    import subprocess; subprocess.check_call(['pip', 'install', 'loguru'])
    dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,package imports
from loguru import logger
from simple_salesforce import Salesforce
import requests
import json
import yaml
from datetime import datetime, timedelta
import os
import ast
from pprint import pprint
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_timestamp, desc, lit, when, expr, current_timestamp, explode, min as min_sql, max as max_sql,monotonically_increasing_id, sha2, concat_ws, trim
from pyspark.sql.types import StructType, StructField, StringType, TimestampType, LongType, IntegerType, BooleanType, ArrayType, MapType
from pyspark.sql import Row, SparkSession
from urllib.parse import urlparse
import unittest
import time
from pyspark.sql.utils import AnalysisException
from delta.tables import DeltaTable
from pytz import timezone
import calendar
import pandas as pd
from io import StringIO
from pytz import timezone
import fnmatch
import shutil
import traceback
import re
from typing import Tuple, Optional
from unittest.mock import MagicMock, patch, mock_open
import subprocess
from concurrent.futures import ThreadPoolExecutor
import hashlib

# COMMAND ----------

# DBTITLE 1,Add notebooks folder to syspath
def add_relative_notebooks_sys_path():
    import sys
    executing_notebook_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
    env_independent_path = executing_notebook_path.split("/dev/")[1].split("/")
    correct_path_from_env = "files/src/notebooks/"
    imported_files_path = f"{'../'*(len(env_independent_path)-1)}{correct_path_from_env}"
    if imported_files_path not in sys.path:
        sys.path.append(imported_files_path)

# COMMAND ----------

# DBTITLE 1,local package imports
add_relative_notebooks_sys_path()
from _constants import Constants as C, setup_constants
from _exceptions import *
from _functions import *
from _globals import Globals as G, setup_globals
setup_globals(spark, dbutils)
setup_constants(G.dbutils)

# COMMAND ----------

validate_not_serverless_cluster()