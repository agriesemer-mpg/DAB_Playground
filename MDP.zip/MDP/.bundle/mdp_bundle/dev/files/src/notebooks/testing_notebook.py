# Databricks notebook source
# MAGIC %run ./_shared

# COMMAND ----------

def execute_notebook(notebook_path):
    """
    Executes a Databricks notebook using dbutils.notebook.run.

    Parameters:
        notebook_path (str): Path to the Databricks notebook.

    Returns:
        str: Result message indicating success or failure.
    """
    try:
        # Run the notebook with dbutils.notebook.run
        result = dbutils.notebook.run(notebook_path, timeout_seconds=300)  # Adjust timeout as needed
        return f"SUCCESS: Notebook {notebook_path} executed successfully with result: {result}"
    except Exception as e:
        return f"ERROR: Notebook {notebook_path} failed with error: {e}"

def run_notebooks_in_parallel(folder, max_workers=4):
    """
    Executes all Databricks notebooks in the specified folder in parallel

    Parameters:
        folder (str): Path to the folder containing notebooks.
        max_workers (int): Number of threads to use for parallel execution.

    Returns:
        dict: Summary of results with counts of successes and failures.
    """

    # Get all notebooks in the folder
    notebooks = [os.path.join(folder, f) for f in os.listdir(folder)]

    if not notebooks:
        print("No notebooks found in the folder.")
        return {"success": 0, "error": 0}

    # Execute notebooks in parallel
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(execute_notebook, notebooks))

    success_count = 0
    error_count = 0
    for result in results:
        print(result + "\n")
        if "SUCCESS" in result:
            success_count += 1
        elif "ERROR" in result:
            error_count += 1

    return {"success": success_count, "error": error_count}


# Databricks-specific code for parameter handling
dbutils.widgets.text("folder_path", C.PATH_TO_NOTEBOOK_TESTS, "Folder Path")
dbutils.widgets.text("max_workers", "4", "Max Workers")

# Read parameters from widgets
folder_path = dbutils.widgets.get("folder_path")  # Defaults to str_path_to_notebook_tests if not overridden
max_workers = int(dbutils.widgets.get("max_workers"))

# Run notebooks and get summary
summary = run_notebooks_in_parallel(folder_path, max_workers)

if summary["error"] > 0:
    raise Exception(summary)
    

# Print summary to the console
print(f"Summary of notebook tests: {summary}")
